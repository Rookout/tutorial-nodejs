"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.InspectorDebug = void 0;

var _logger = require("../logger");

var _exceptions = require("../exceptions");

var _IgnoredNodeModules = require("./IgnoredNodeModules");

var _InspectorFrameNamespace = _interopRequireDefault(require("../processor/namespaces/InspectorFrameNamespace"));

var _InspectorStackNamespace = _interopRequireDefault(require("../processor/namespaces/InspectorStackNamespace"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const inspector = require('inspector');

const url = require('url');

const rook = require("../index");

class InspectorDebug {
  constructor(userLine, scriptLoaded, getScript) {
    if (InspectorDebug.isElectron()) {
      InspectorDebug.verifyInspectFlagEnabledUnderElectron();
    } else {
      // Setting the --inspect CLI flag means the inspector will be active, so we can't
      // run this verification in that case.
      InspectorDebug.verifyNoDebuggerConnected();
    }

    const self = this;
    this.getScriptCallback = getScript;
    this.positionsToBreakpoints = {};
    this.breakpointsToPositions = {};
    this.loadedScriptsCount = 0;
    this.maxLoadedScripts = parseInt(process.env.ROOKOUT_MAX_SCRIPTS) || 20000;
    this.session = new inspector.Session();

    try {
      this.session.connect();
    } catch (e) {
      throw new _exceptions.RookInspectorConnectFailed(e);
    }

    this.session.on('Debugger.scriptParsed', script => {
      if (self.session === null) {
        return;
      }

      try {
        self.loadedScriptsCount++;

        if (self.loadedScriptsCount > self.maxLoadedScripts && rook.savedOptions !== null) {
          _logger.logger.warn("An unreasonable number of scripts loaded - restarting");

          self.loadedScriptsCount = 0;
          rook.stop().then(() => rook.start().catch(() => _logger.logger.exception("Failed to restart"))).catch(() => _logger.logger.exception("Failed to restart"));
          return;
        }

        let scriptURL = script.params.url; // URLs instead of paths started in 10.12 which also introduced this
        // url.fileURLToPath. We assume we will not receive URLs before 10.12

        if (scriptURL.startsWith("file:") && url.fileURLToPath !== undefined) {
          scriptURL = url.fileURLToPath(scriptURL);
        }

        if ((0, _IgnoredNodeModules.isBlackListedModule)(scriptURL)) {
          return;
        }

        self.post('Debugger.getScriptSource', {
          scriptId: script.params.scriptId
        }, (err, scriptSource) => {
          if (err) {
            _logger.logger.exception("Failed to get script source", err);

            return;
          }

          try {
            scriptLoaded(script.params.scriptId, scriptURL, scriptSource.scriptSource);
          } catch (error) {
            _logger.logger.exception("Exception when processing script source callback", error);
          }
        });
      } catch (error) {
        _logger.logger.exception("Exception when processing script parse callback", error);
      }
    });
    this.session.on('Debugger.paused', message => {
      if (self.session === null) {
        return;
      }

      try {
        const pos = self.breakpointsToPositions[message.params.hitBreakpoints[0]];
        userLine(pos, new _InspectorFrameNamespace.default(self, message.params.callFrames[0]), new _InspectorStackNamespace.default(self, message.params.callFrames));
      } catch (error) {
        _logger.logger.exception(error);
      } finally {
        this.post("Debugger.resume");
      }
    });
    this.session.on('error', error => {
      try {
        _logger.logger.exception('InspectorDebugger error', error);
      } catch (e) {}
    });
    this.post('Debugger.enable');
    this.post('Debugger.setBreakpointsActive', {
      active: true
    });
  }

  static verifyNoDebuggerConnected() {
    // inspector.url doesn't exist in node.js v8.0.0 - it was added in v8.1.0
    // (although the docs would have you believe it's support in v8.x)
    if (inspector.url !== undefined && inspector.url() !== undefined) {
      throw new _exceptions.RookOtherDebuggerConnected();
    }
  } //NOTE:: if inspect is not specified under electron, inspector api will fail to load
  //NOTE:: its important that this function will happen here and not in the InspectorDebug
  //          since we actually want to fail if inspect is not specified


  static verifyInspectFlagEnabledUnderElectron() {
    let processArguments = process.argv.toString();

    if (!processArguments.includes('--inspect')) {
      throw new _exceptions.RookElectronInspectFlagNotSet();
    }
  }

  static isElectron() {
    return process.argv.toString().includes('electron');
  }

  setBreak(pos, aug) {
    let result = {};
    let scriptURL = pos.filename;

    if (url.pathToFileURL !== undefined) {
      scriptURL = url.pathToFileURL(scriptURL);
    }

    let key = 'aug-' + aug.augId;

    let info = process.__rookout_backchannel.create(key);

    info.aug = aug;
    this.post('Debugger.setBreakpointByUrl', {
      url: scriptURL,
      condition: `
                (() => {
                    let __aug = process.__rookout_backchannel.get('${key}').aug;
                    
                    if (__aug.condition !== undefined && __aug._scopeSample !== undefined) {
                        let __scopes = __aug._scopeSample;
                        let __frame_namespace = new process.__rookout_backchannel.ContainerNamespace({});
                        let __namespace = new process.__rookout_backchannel.ContainerNamespace({
                            frame: __frame_namespace
                        });
                        
                        for (let scope of __scopes) {
                            for (let obj_name in scope.object) {
                                __frame_namespace.writeAttribute(obj_name, 
                                new process.__rookout_backchannel.ObjectNamespace(eval(obj_name)));
                            }
                        }
                        
                        if (!__aug.condition.evaluate(__namespace)) {
                            return false;
                        }
                    }
                    
                    if (!__aug.checkRateLimit()) {
                        return false;
                    }

                    return true;
                })()
                `,
      lineNumber: pos.lineno - 1,
      columnNumber: pos.column + 1
    }, (error, response) => {
      result.error = error;
      result.response = response;
    });

    if (null != result.error) {
      throw new _exceptions.RookInspectorSetBreakpointFailed(result.error);
    }

    this.positionsToBreakpoints[pos.toKey()] = result.response.breakpointId;
    this.breakpointsToPositions[result.response.breakpointId] = pos;
  }

  async clearBreak(pos) {
    // If we have an object, hash it
    if (pos.toKey) {
      pos = pos.toKey();
    }

    const breakpointId = this.positionsToBreakpoints[pos];

    if (undefined === breakpointId) {
      return;
    }

    delete this.positionsToBreakpoints[pos];
    delete this.breakpointsToPositions[breakpointId];
    let result = {};
    await this.post('Debugger.removeBreakpoint', {
      breakpointId: breakpointId
    }, error => {
      result.error = error;
    });

    if (null != result.error) {
      _logger.logger.error("Failed to remove breakpoint", result.error);
    }
  }

  async clearAllBreaks() {
    let positions = Object.keys(this.positionsToBreakpoints);
    await Promise.all(positions.map(position => this.clearBreak(position)));
    this.positionsToBreakpoints = {};
    this.breakpointsToPositions = {};
  }

  post(message_id, params, cb) {
    return new Promise(resolve => {
      const myCb = (...args) => {
        if (cb !== undefined) {
          cb(...args);
        }

        resolve();
      };

      if (this.session === null) {
        if (cb !== undefined) {
          cb(new Error("No debug session"), null);
        }

        return;
      }

      this.session.post(message_id, params, myCb);
    });
  }

  getProperties(object, ownProperties = true) {
    let result = {};
    this.post('Runtime.getProperties', {
      objectId: object.objectId,
      ownProperties: ownProperties
    }, (error, value) => {
      if (error) {
        result.error = error;
      } else {
        result.value = value.result;
      }
    });

    if (result.error) {
      throw new RookInspectorFailedToGetObject(object);
    }

    return result.value;
  }

  getScript(scriptId) {
    return this.getScriptCallback(scriptId);
  }

  async close() {
    if (this.session) {
      await this.clearAllBreaks();
      await this.post('Debugger.setBreakpointsActive', {
        active: false
      });
      await this.post('Debugger.disable');
      this.session.disconnect();
      this.session = null;
    }
  }

  scripts() {
    return [];
  }

}

exports.InspectorDebug = InspectorDebug;
//# sourceMappingURL=InspectorDebug.js.map