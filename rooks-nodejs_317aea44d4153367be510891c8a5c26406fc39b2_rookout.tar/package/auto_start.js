"use strict";

(function () {
  let disable = process.env.ROOKOUT_DISABLE_AUTOSTART;

  if (disable !== undefined && disable !== '0') {
    return;
  }

  const rook = require('./index');

  module.exports = rook;
  rook.start();
})();
//# sourceMappingURL=auto_start.js.map