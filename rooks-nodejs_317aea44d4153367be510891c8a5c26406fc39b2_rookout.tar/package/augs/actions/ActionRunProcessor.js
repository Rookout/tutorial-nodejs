"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _ContainerNamespace = _interopRequireDefault(require("../../processor/namespaces/ContainerNamespace"));

var _V8FrameNamespace = _interopRequireDefault(require("../../processor/namespaces/V8FrameNamespace"));

var _JSUtilsNamespace = _interopRequireDefault(require("../../processor/namespaces/JSUtilsNamespace"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

class ActionRunProcessor {
  constructor(configuration, factory) {
    this.processor = factory.getProcessor(configuration['operations'], factory);

    if (configuration['post_operations'] && configuration['post_operations'].length > 0) {
      this.postProcessor = factory.get(configuration['post_operations'], factory);
    }
  }

  execute(augId, reportId, containerNamespace, output, userWarnings) {
    this.processor.process(containerNamespace, userWarnings);
    output.sendUserMessage(augId, reportId, containerNamespace.readAttribute('store'));

    if (this.postProcessor) {
      output.flushMessages();
      self.postProcessor(containerNamespace);
    }
  }

}

exports.default = ActionRunProcessor;
//# sourceMappingURL=ActionRunProcessor.js.map