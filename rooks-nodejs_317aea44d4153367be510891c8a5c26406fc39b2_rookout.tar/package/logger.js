"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.logger = void 0;

var _ContainerNamespace = _interopRequireDefault(require("./processor/namespaces/ContainerNamespace"));

var _JSObjectNamespace = _interopRequireDefault(require("./processor/namespaces/JSObjectNamespace"));

var _ListNamespace = _interopRequireDefault(require("./processor/namespaces/ListNamespace"));

var _utils = require("./utils");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const path = require('path');

const fs = require('fs');

const util = require('util');

const config = require('./config');

if (config.JSConfig.SOURCE_MAP_SUPPORT) {
  require('source-map-support/register');
}

const LOG_LEVELS = ["debug", "info", "warning", "error", "critical"];

class Logger {
  constructor() {
    if (process.argv.length > 1 && process.argv[1].endsWith('rooks/node/rook/node_modules/jest/bin/jest.js')) {
      config.LoggingConfiguration.LOG_TO_STDERR = true;
      config.LoggingConfiguration.LOG_LEVEL = "debug";
    }

    this.output = null;
    this.handlers = this.buildHandlers();
  }

  registerOutput(output) {
    this.output = output;
  }

  removeOutput(output) {
    this.output = null;
  }

  debug(message) {
    return this.log(message, arguments, "debug");
  }

  info(message) {
    return this.log(message, arguments, "info");
  }

  warn(message) {
    return this.log(message, arguments, "warning");
  }

  error(message) {
    return this.log(message, arguments, "error");
  }

  exception(message) {
    return this.log(message, arguments, "error");
  }

  log(message, rawArguments, level = "info") {
    try {
      let levelno = LOG_LEVELS.indexOf(level);

      if (-1 === levelno) {
        levelno = LOG_LEVELS.length;
      }

      if (levelno < this.verbosity) {
        return;
      }

      let formattedMessage = message;

      try {
        formattedMessage = util.format.apply(this, rawArguments); // Append error stacks to log

        for (let value of rawArguments) {
          if (value instanceof Error) {
            formattedMessage += value.stack;
          }
        }
      } catch (e) {}

      let caller = this.getCaller();
      let args = null;

      if (rawArguments.length > 1) {
        // Following this recommendation- http://code.fitness/post/2015/11/javascript-function-arguments-do-not-slice.html
        args = new Array(rawArguments.length - 1);

        for (let i = 1; i < rawArguments.length; ++i) {
          args[i - 1] = rawArguments[i];
        }
      }

      const record = {
        level: level,
        levelno: levelno,
        time: new Date(),
        filename: caller.filename,
        lineno: caller.lineno,
        text: formattedMessage,
        formattedMessage: formattedMessage,
        args: args
      };

      for (let handler of this.handlers) {
        handler(record);
      }
    } catch (e) {
      console.error("[Rookout] Unexpected error when writing to log:", e.message);
      console.error(e.stack);
    }
  }

  buildHandlers() {
    let configLevel = config.LoggingConfiguration.LOG_LEVEL;

    if ("warn" === configLevel.toLowerCase()) {
      configLevel = "warning";
    }

    this.verbosity = LOG_LEVELS.indexOf(configLevel.toLowerCase());
    let self = this;
    let handlers = [];

    const formatRecord = function (record) {
      return util.format('%s - %s@%d - %s - %s', record.time, record.filename, record.lineno, record.level, record.formattedMessage);
    };

    if (config.LoggingConfiguration.LOG_TO_STDERR) {
      handlers.push(record => {
        console.error(formatRecord(record));
      });
    }

    const baseLogFilePath = config.LoggingConfiguration.FILE_NAME;

    if (null != baseLogFilePath && "" !== baseLogFilePath) {
      // Calculate absolute log file path
      let absoluteFilePath = "";

      if (path.isAbsolute(baseLogFilePath)) {
        absoluteFilePath = baseLogFilePath;
      } else {
        if ('win32' === process.platform) {
          absoluteFilePath = path.join((0, _utils.getEnv)('USERPROFILE', '.'), baseLogFilePath);
        } else if (process.platform.includes('darwin')) {
          absoluteFilePath = path.join((0, _utils.getEnv)('HOME', '.'), baseLogFilePath);
        } else {
          absoluteFilePath = path.join('/var/log', baseLogFilePath);
        }
      }

      try {
        let path_dir = path.dirname(absoluteFilePath);

        if (!fs.existsSync(path_dir)) {
          fs.mkdirSync(path_dir);
        }

        let fd = fs.openSync(absoluteFilePath, 'a');
        handlers.push(record => {
          fs.writeSync(fd, formatRecord(record) + '\n');
        });
      } catch (e) {
        if (config.LoggingConfiguration.DEBUG) {
          console.error("[Rookout] Failed to open log file: %s", absoluteFilePath);
          console.error(e.message);
          console.error(e.stack || e);
        }
      }
    }

    handlers.push(record => {
      if (null != self.output) {
        let argsParameter = null;

        if (record.args) {
          // We convert args to a ListNamespace to ensure all objects are deeply dumped
          let args = record.args.map(arg => new _JSObjectNamespace.default(arg));
          argsParameter = new _ContainerNamespace.default({
            args: new _ListNamespace.default(args)
          });
        }

        self.output.sendLogMessage(record.levelno, record.time, record.filename, record.lineno, record.text, record.formattedMessage, argsParameter);
      }
    });
    return handlers;
  }

  getCaller() {
    let result = {
      filename: null,
      lineno: null
    };
    const oldPrepareStackTrace = Error.prepareStackTrace;

    try {
      Error.prepareStackTrace = (error, structuredStackTrace) => {
        for (let callSite of structuredStackTrace) {
          if (callSite.getFileName() !== __filename) {
            result.filename = callSite.getFileName();
            result.lineno = callSite.getLineno();
            break;
          }
        }
      };

      let fakeError = {};
      Error.captureStackTrace(fakeError);
    } catch (e) {}

    Error.prepareStackTrace = oldPrepareStackTrace;
    return result;
  }

}

let logger = new Logger();
exports.logger = logger;
//# sourceMappingURL=logger.js.map