"use strict";
/**
 * This file parses the command line and re-run the program with striped command line.
 * we will replace the 'node --nodeParams CircleCiOrbWrapperInternal.js' with 'node' including any additional flags passed to node.
 * this logic is very similar to babel-node
 */

const rook = require('rookout');

const path = require('path');

if (process.argv.length) {
  // slice all arguments up to the first filename since they're rookout args that we handle
  let args = process.argv.slice(2); // looking for the script argument - ignoring all node flags since they are already applied to this process

  let scriptIndex = undefined;
  let ignoreNext = false;
  args.some(function (arg, index) {
    if (ignoreNext) {
      return;
    }

    if (arg[0] !== "-") {
      if (scriptIndex === undefined) {
        scriptIndex = index;
      }

      ignoreNext = true;
    }
  });

  if (scriptIndex !== undefined) {
    args = args.slice(scriptIndex); // make the filename absolute

    const filename = args[0];

    if (!path.isAbsolute(filename)) {
      args[0] = path.resolve(filename);
    } // add back on node and concat the sliced args


    process.argv = ["node"].concat(args);
    process.execArgv.unshift(__filename);
    rook.start();

    let Module = require("module");

    Module.runMain();
  } else {
    console.log("Bad command line - could not find script to run");
    process.exit(1);
  }
}
//# sourceMappingURL=CircleCiOrbWrapperInternal.js.map