"use strict";

/**
 * This file was generated from canopy\ArithmeticPath.peg
 * See http://canopy.jcoglan.com/ for documentation.
 */
(function () {
  'use strict';

  var extend = function (destination, source) {
    if (!destination || !source) return destination;

    for (var key in source) {
      if (destination[key] !== source[key]) destination[key] = source[key];
    }

    return destination;
  };

  var formatError = function (input, offset, expected) {
    var lines = input.split(/\n/g),
        lineNo = 0,
        position = 0;

    while (position <= offset) {
      position += lines[lineNo].length + 1;
      lineNo += 1;
    }

    var message = 'Line ' + lineNo + ': expected ' + expected.join(', ') + '\n',
        line = lines[lineNo - 1];
    message += line + '\n';
    position -= line.length + 1;

    while (position < offset) {
      message += ' ';
      position += 1;
    }

    return message + '^';
  };

  var inherit = function (subclass, parent) {
    var chain = function () {};

    chain.prototype = parent.prototype;
    subclass.prototype = new chain();
    subclass.prototype.constructor = subclass;
  };

  var TreeNode = function (text, offset, elements) {
    this.text = text;
    this.offset = offset;
    this.elements = elements || [];
  };

  TreeNode.prototype.forEach = function (block, context) {
    for (var el = this.elements, i = 0, n = el.length; i < n; i++) {
      block.call(context, el[i], i, el);
    }
  };

  var TreeNode1 = function (text, offset, elements) {
    TreeNode.apply(this, arguments);
    this['atom'] = elements[0];
  };

  inherit(TreeNode1, TreeNode);

  var TreeNode2 = function (text, offset, elements) {
    TreeNode.apply(this, arguments);
    this['opt_'] = elements[0];
    this['atom'] = elements[1];
  };

  inherit(TreeNode2, TreeNode);

  var TreeNode3 = function (text, offset, elements) {
    TreeNode.apply(this, arguments);
    this['unicode_set'] = elements[0];
  };

  inherit(TreeNode3, TreeNode);

  var TreeNode4 = function (text, offset, elements) {
    TreeNode.apply(this, arguments);
    this['variable'] = elements[1];
  };

  inherit(TreeNode4, TreeNode);

  var TreeNode5 = function (text, offset, elements) {
    TreeNode.apply(this, arguments);
    this['unicode_set'] = elements[0];
  };

  inherit(TreeNode5, TreeNode);

  var TreeNode6 = function (text, offset, elements) {
    TreeNode.apply(this, arguments);
    this['unicode_set'] = elements[1];
  };

  inherit(TreeNode6, TreeNode);

  var TreeNode7 = function (text, offset, elements) {
    TreeNode.apply(this, arguments);
    this['__'] = elements[3];
  };

  inherit(TreeNode7, TreeNode);

  var TreeNode8 = function (text, offset, elements) {
    TreeNode.apply(this, arguments);
    this['__'] = elements[4];
    this['comp_expression'] = elements[2];
  };

  inherit(TreeNode8, TreeNode);

  var TreeNode9 = function (text, offset, elements) {
    TreeNode.apply(this, arguments);
    this['__'] = elements[4];
  };

  inherit(TreeNode9, TreeNode);

  var TreeNode10 = function (text, offset, elements) {
    TreeNode.apply(this, arguments);
    this['__'] = elements[4];
  };

  inherit(TreeNode10, TreeNode);

  var TreeNode11 = function (text, offset, elements) {
    TreeNode.apply(this, arguments);
    this['__'] = elements[6];
  };

  inherit(TreeNode11, TreeNode);

  var TreeNode12 = function (text, offset, elements) {
    TreeNode.apply(this, arguments);
    this['atom'] = elements[0];
    this['__'] = elements[1];
  };

  inherit(TreeNode12, TreeNode);

  var TreeNode13 = function (text, offset, elements) {
    TreeNode.apply(this, arguments);
    this['__'] = elements[3];
    this['atom'] = elements[2];
  };

  inherit(TreeNode13, TreeNode);

  var TreeNode14 = function (text, offset, elements) {
    TreeNode.apply(this, arguments);
    this['__'] = elements[4];
  };

  inherit(TreeNode14, TreeNode);

  var TreeNode15 = function (text, offset, elements) {
    TreeNode.apply(this, arguments);
    this['__'] = elements[3];
  };

  inherit(TreeNode15, TreeNode);

  var TreeNode16 = function (text, offset, elements) {
    TreeNode.apply(this, arguments);
    this['__'] = elements[5];
  };

  inherit(TreeNode16, TreeNode);

  var TreeNode17 = function (text, offset, elements) {
    TreeNode.apply(this, arguments);
    this['__'] = elements[2];
    this['data'] = elements[1];
  };

  inherit(TreeNode17, TreeNode);

  var TreeNode18 = function (text, offset, elements) {
    TreeNode.apply(this, arguments);
    this['__'] = elements[2];
    this['data'] = elements[1];
  };

  inherit(TreeNode18, TreeNode);

  var TreeNode19 = function (text, offset, elements) {
    TreeNode.apply(this, arguments);
    this['__'] = elements[2];
    this['data'] = elements[1];
  };

  inherit(TreeNode19, TreeNode);

  var TreeNode20 = function (text, offset, elements) {
    TreeNode.apply(this, arguments);
    this['__'] = elements[2];
    this['data'] = elements[1];
  };

  inherit(TreeNode20, TreeNode);
  var FAILURE = {};
  var Grammar = {
    _read_comp_expression: function () {
      var address0 = FAILURE,
          index0 = this._offset;
      this._cache._comp_expression = this._cache._comp_expression || {};
      var cached = this._cache._comp_expression[index0];

      if (cached) {
        this._offset = cached[1];
        return cached[0];
      }

      var index1 = this._offset,
          elements0 = new Array(2);
      var address1 = FAILURE;
      address1 = this._read_atom();

      if (address1 !== FAILURE) {
        elements0[0] = address1;
        var address2 = FAILURE;
        var remaining0 = 0,
            index2 = this._offset,
            elements1 = [],
            address3 = true;

        while (address3 !== FAILURE) {
          var index3 = this._offset,
              elements2 = new Array(2);
          var address4 = FAILURE;
          address4 = this._read_opt_();

          if (address4 !== FAILURE) {
            elements2[0] = address4;
            var address5 = FAILURE;
            address5 = this._read_atom();

            if (address5 !== FAILURE) {
              elements2[1] = address5;
            } else {
              elements2 = null;
              this._offset = index3;
            }
          } else {
            elements2 = null;
            this._offset = index3;
          }

          if (elements2 === null) {
            address3 = FAILURE;
          } else {
            address3 = new TreeNode2(this._input.substring(index3, this._offset), index3, elements2);
            this._offset = this._offset;
          }

          if (address3 !== FAILURE) {
            elements1.push(address3);
            --remaining0;
          }
        }

        if (remaining0 <= 0) {
          address2 = new TreeNode(this._input.substring(index2, this._offset), index2, elements1);
          this._offset = this._offset;
        } else {
          address2 = FAILURE;
        }

        if (address2 !== FAILURE) {
          elements0[1] = address2;
        } else {
          elements0 = null;
          this._offset = index1;
        }
      } else {
        elements0 = null;
        this._offset = index1;
      }

      if (elements0 === null) {
        address0 = FAILURE;
      } else {
        address0 = this._actions.make_comp_exp(this._input, index1, this._offset, elements0);
        this._offset = this._offset;
      }

      this._cache._comp_expression[index0] = [address0, this._offset];
      return address0;
    },
    _read_atom: function () {
      var address0 = FAILURE,
          index0 = this._offset;
      this._cache._atom = this._cache._atom || {};
      var cached = this._cache._atom[index0];

      if (cached) {
        this._offset = cached[1];
        return cached[0];
      }

      var index1 = this._offset;
      address0 = this._read_float_();

      if (address0 === FAILURE) {
        this._offset = index1;
        address0 = this._read_number();

        if (address0 === FAILURE) {
          this._offset = index1;
          address0 = this._read_string();

          if (address0 === FAILURE) {
            this._offset = index1;
            address0 = this._read_apostrophe_string();

            if (address0 === FAILURE) {
              this._offset = index1;
              address0 = this._read_list();

              if (address0 === FAILURE) {
                this._offset = index1;
                address0 = this._read_chr();

                if (address0 === FAILURE) {
                  this._offset = index1;
                  address0 = this._read_boolean_();

                  if (address0 === FAILURE) {
                    this._offset = index1;
                    address0 = this._read_null_();

                    if (address0 === FAILURE) {
                      this._offset = index1;
                      address0 = this._read_undefined_();

                      if (address0 === FAILURE) {
                        this._offset = index1;
                        address0 = this._read_comp_expression_ex();

                        if (address0 === FAILURE) {
                          this._offset = index1;
                          address0 = this._read_namespace();

                          if (address0 === FAILURE) {
                            this._offset = index1;
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }

      this._cache._atom[index0] = [address0, this._offset];
      return address0;
    },
    _read_unicode_set: function () {
      var address0 = FAILURE,
          index0 = this._offset;
      this._cache._unicode_set = this._cache._unicode_set || {};
      var cached = this._cache._unicode_set[index0];

      if (cached) {
        this._offset = cached[1];
        return cached[0];
      }

      var chunk0 = null;

      if (this._offset < this._inputSize) {
        chunk0 = this._input.substring(this._offset, this._offset + 1);
      }

      if (chunk0 !== null && /^[a-zA-Z_$]/.test(chunk0)) {
        address0 = new TreeNode(this._input.substring(this._offset, this._offset + 1), this._offset);
        this._offset = this._offset + 1;
      } else {
        address0 = FAILURE;

        if (this._offset > this._failure) {
          this._failure = this._offset;
          this._expected = [];
        }

        if (this._offset === this._failure) {
          this._expected.push('[a-zA-Z_$]');
        }
      }

      this._cache._unicode_set[index0] = [address0, this._offset];
      return address0;
    },
    _read_unicode_set_with_numbers: function () {
      var address0 = FAILURE,
          index0 = this._offset;
      this._cache._unicode_set_with_numbers = this._cache._unicode_set_with_numbers || {};
      var cached = this._cache._unicode_set_with_numbers[index0];

      if (cached) {
        this._offset = cached[1];
        return cached[0];
      }

      var chunk0 = null;

      if (this._offset < this._inputSize) {
        chunk0 = this._input.substring(this._offset, this._offset + 1);
      }

      if (chunk0 !== null && /^[a-zA-Z0-9_$]/.test(chunk0)) {
        address0 = new TreeNode(this._input.substring(this._offset, this._offset + 1), this._offset);
        this._offset = this._offset + 1;
      } else {
        address0 = FAILURE;

        if (this._offset > this._failure) {
          this._failure = this._offset;
          this._expected = [];
        }

        if (this._offset === this._failure) {
          this._expected.push('[a-zA-Z0-9_$]');
        }
      }

      this._cache._unicode_set_with_numbers[index0] = [address0, this._offset];
      return address0;
    },
    _read_variable: function () {
      var address0 = FAILURE,
          index0 = this._offset;
      this._cache._variable = this._cache._variable || {};
      var cached = this._cache._variable[index0];

      if (cached) {
        this._offset = cached[1];
        return cached[0];
      }

      var index1 = this._offset,
          elements0 = new Array(2);
      var address1 = FAILURE;
      address1 = this._read_unicode_set();

      if (address1 !== FAILURE) {
        elements0[0] = address1;
        var address2 = FAILURE;
        var remaining0 = 0,
            index2 = this._offset,
            elements1 = [],
            address3 = true;

        while (address3 !== FAILURE) {
          address3 = this._read_unicode_set_with_numbers();

          if (address3 !== FAILURE) {
            elements1.push(address3);
            --remaining0;
          }
        }

        if (remaining0 <= 0) {
          address2 = new TreeNode(this._input.substring(index2, this._offset), index2, elements1);
          this._offset = this._offset;
        } else {
          address2 = FAILURE;
        }

        if (address2 !== FAILURE) {
          elements0[1] = address2;
        } else {
          elements0 = null;
          this._offset = index1;
        }
      } else {
        elements0 = null;
        this._offset = index1;
      }

      if (elements0 === null) {
        address0 = FAILURE;
      } else {
        address0 = this._actions.make_attribute(this._input, index1, this._offset, elements0);
        this._offset = this._offset;
      }

      this._cache._variable[index0] = [address0, this._offset];
      return address0;
    },
    _read_variable_access: function () {
      var address0 = FAILURE,
          index0 = this._offset;
      this._cache._variable_access = this._cache._variable_access || {};
      var cached = this._cache._variable_access[index0];

      if (cached) {
        this._offset = cached[1];
        return cached[0];
      }

      var index1 = this._offset,
          elements0 = new Array(2);
      var address1 = FAILURE;
      var chunk0 = null;

      if (this._offset < this._inputSize) {
        chunk0 = this._input.substring(this._offset, this._offset + 1);
      }

      if (chunk0 === '.') {
        address1 = new TreeNode(this._input.substring(this._offset, this._offset + 1), this._offset);
        this._offset = this._offset + 1;
      } else {
        address1 = FAILURE;

        if (this._offset > this._failure) {
          this._failure = this._offset;
          this._expected = [];
        }

        if (this._offset === this._failure) {
          this._expected.push('"."');
        }
      }

      if (address1 !== FAILURE) {
        elements0[0] = address1;
        var address2 = FAILURE;
        address2 = this._read_variable();

        if (address2 !== FAILURE) {
          elements0[1] = address2;
        } else {
          elements0 = null;
          this._offset = index1;
        }
      } else {
        elements0 = null;
        this._offset = index1;
      }

      if (elements0 === null) {
        address0 = FAILURE;
      } else {
        address0 = this._actions.make_attribute_operation(this._input, index1, this._offset, elements0);
        this._offset = this._offset;
      }

      this._cache._variable_access[index0] = [address0, this._offset];
      return address0;
    },
    _read_map_access: function () {
      var address0 = FAILURE,
          index0 = this._offset;
      this._cache._map_access = this._cache._map_access || {};
      var cached = this._cache._map_access[index0];

      if (cached) {
        this._offset = cached[1];
        return cached[0];
      }

      var index1 = this._offset,
          elements0 = new Array(3);
      var address1 = FAILURE;
      var chunk0 = null;

      if (this._offset < this._inputSize) {
        chunk0 = this._input.substring(this._offset, this._offset + 1);
      }

      if (chunk0 === '[') {
        address1 = new TreeNode(this._input.substring(this._offset, this._offset + 1), this._offset);
        this._offset = this._offset + 1;
      } else {
        address1 = FAILURE;

        if (this._offset > this._failure) {
          this._failure = this._offset;
          this._expected = [];
        }

        if (this._offset === this._failure) {
          this._expected.push('"["');
        }
      }

      if (address1 !== FAILURE) {
        elements0[0] = address1;
        var address2 = FAILURE;
        var index2 = this._offset;
        address2 = this._read_chr();

        if (address2 === FAILURE) {
          this._offset = index2;
          address2 = this._read_string();

          if (address2 === FAILURE) {
            this._offset = index2;
            address2 = this._read_apostrophe_string();

            if (address2 === FAILURE) {
              this._offset = index2;
              address2 = this._read_number();

              if (address2 === FAILURE) {
                this._offset = index2;
              }
            }
          }
        }

        if (address2 !== FAILURE) {
          elements0[1] = address2;
          var address3 = FAILURE;
          var chunk1 = null;

          if (this._offset < this._inputSize) {
            chunk1 = this._input.substring(this._offset, this._offset + 1);
          }

          if (chunk1 === ']') {
            address3 = new TreeNode(this._input.substring(this._offset, this._offset + 1), this._offset);
            this._offset = this._offset + 1;
          } else {
            address3 = FAILURE;

            if (this._offset > this._failure) {
              this._failure = this._offset;
              this._expected = [];
            }

            if (this._offset === this._failure) {
              this._expected.push('"]"');
            }
          }

          if (address3 !== FAILURE) {
            elements0[2] = address3;
          } else {
            elements0 = null;
            this._offset = index1;
          }
        } else {
          elements0 = null;
          this._offset = index1;
        }
      } else {
        elements0 = null;
        this._offset = index1;
      }

      if (elements0 === null) {
        address0 = FAILURE;
      } else {
        address0 = this._actions.make_lookup_operation(this._input, index1, this._offset, elements0);
        this._offset = this._offset;
      }

      this._cache._map_access[index0] = [address0, this._offset];
      return address0;
    },
    _read_func_call: function () {
      var address0 = FAILURE,
          index0 = this._offset;
      this._cache._func_call = this._cache._func_call || {};
      var cached = this._cache._func_call[index0];

      if (cached) {
        this._offset = cached[1];
        return cached[0];
      }

      var index1 = this._offset,
          elements0 = new Array(5);
      var address1 = FAILURE;
      address1 = this._read_unicode_set();

      if (address1 !== FAILURE) {
        elements0[0] = address1;
        var address2 = FAILURE;
        var remaining0 = 0,
            index2 = this._offset,
            elements1 = [],
            address3 = true;

        while (address3 !== FAILURE) {
          address3 = this._read_unicode_set_with_numbers();

          if (address3 !== FAILURE) {
            elements1.push(address3);
            --remaining0;
          }
        }

        if (remaining0 <= 0) {
          address2 = new TreeNode(this._input.substring(index2, this._offset), index2, elements1);
          this._offset = this._offset;
        } else {
          address2 = FAILURE;
        }

        if (address2 !== FAILURE) {
          elements0[1] = address2;
          var address4 = FAILURE;
          var chunk0 = null;

          if (this._offset < this._inputSize) {
            chunk0 = this._input.substring(this._offset, this._offset + 1);
          }

          if (chunk0 === '(') {
            address4 = new TreeNode(this._input.substring(this._offset, this._offset + 1), this._offset);
            this._offset = this._offset + 1;
          } else {
            address4 = FAILURE;

            if (this._offset > this._failure) {
              this._failure = this._offset;
              this._expected = [];
            }

            if (this._offset === this._failure) {
              this._expected.push('"("');
            }
          }

          if (address4 !== FAILURE) {
            elements0[2] = address4;
            var address5 = FAILURE;
            var index3 = this._offset;
            address5 = this._read_atom();

            if (address5 === FAILURE) {
              address5 = new TreeNode(this._input.substring(index3, index3), index3);
              this._offset = index3;
            }

            if (address5 !== FAILURE) {
              elements0[3] = address5;
              var address6 = FAILURE;
              var chunk1 = null;

              if (this._offset < this._inputSize) {
                chunk1 = this._input.substring(this._offset, this._offset + 1);
              }

              if (chunk1 === ')') {
                address6 = new TreeNode(this._input.substring(this._offset, this._offset + 1), this._offset);
                this._offset = this._offset + 1;
              } else {
                address6 = FAILURE;

                if (this._offset > this._failure) {
                  this._failure = this._offset;
                  this._expected = [];
                }

                if (this._offset === this._failure) {
                  this._expected.push('")"');
                }
              }

              if (address6 !== FAILURE) {
                elements0[4] = address6;
              } else {
                elements0 = null;
                this._offset = index1;
              }
            } else {
              elements0 = null;
              this._offset = index1;
            }
          } else {
            elements0 = null;
            this._offset = index1;
          }
        } else {
          elements0 = null;
          this._offset = index1;
        }
      } else {
        elements0 = null;
        this._offset = index1;
      }

      if (elements0 === null) {
        address0 = FAILURE;
      } else {
        address0 = this._actions.make_function_operation(this._input, index1, this._offset, elements0);
        this._offset = this._offset;
      }

      this._cache._func_call[index0] = [address0, this._offset];
      return address0;
    },
    _read_func_call_access: function () {
      var address0 = FAILURE,
          index0 = this._offset;
      this._cache._func_call_access = this._cache._func_call_access || {};
      var cached = this._cache._func_call_access[index0];

      if (cached) {
        this._offset = cached[1];
        return cached[0];
      }

      var index1 = this._offset,
          elements0 = new Array(6);
      var address1 = FAILURE;
      var chunk0 = null;

      if (this._offset < this._inputSize) {
        chunk0 = this._input.substring(this._offset, this._offset + 1);
      }

      if (chunk0 === '.') {
        address1 = new TreeNode(this._input.substring(this._offset, this._offset + 1), this._offset);
        this._offset = this._offset + 1;
      } else {
        address1 = FAILURE;

        if (this._offset > this._failure) {
          this._failure = this._offset;
          this._expected = [];
        }

        if (this._offset === this._failure) {
          this._expected.push('"."');
        }
      }

      if (address1 !== FAILURE) {
        elements0[0] = address1;
        var address2 = FAILURE;
        address2 = this._read_unicode_set();

        if (address2 !== FAILURE) {
          elements0[1] = address2;
          var address3 = FAILURE;
          var remaining0 = 0,
              index2 = this._offset,
              elements1 = [],
              address4 = true;

          while (address4 !== FAILURE) {
            address4 = this._read_unicode_set_with_numbers();

            if (address4 !== FAILURE) {
              elements1.push(address4);
              --remaining0;
            }
          }

          if (remaining0 <= 0) {
            address3 = new TreeNode(this._input.substring(index2, this._offset), index2, elements1);
            this._offset = this._offset;
          } else {
            address3 = FAILURE;
          }

          if (address3 !== FAILURE) {
            elements0[2] = address3;
            var address5 = FAILURE;
            var chunk1 = null;

            if (this._offset < this._inputSize) {
              chunk1 = this._input.substring(this._offset, this._offset + 1);
            }

            if (chunk1 === '(') {
              address5 = new TreeNode(this._input.substring(this._offset, this._offset + 1), this._offset);
              this._offset = this._offset + 1;
            } else {
              address5 = FAILURE;

              if (this._offset > this._failure) {
                this._failure = this._offset;
                this._expected = [];
              }

              if (this._offset === this._failure) {
                this._expected.push('"("');
              }
            }

            if (address5 !== FAILURE) {
              elements0[3] = address5;
              var address6 = FAILURE;
              var index3 = this._offset;
              address6 = this._read_atom();

              if (address6 === FAILURE) {
                address6 = new TreeNode(this._input.substring(index3, index3), index3);
                this._offset = index3;
              }

              if (address6 !== FAILURE) {
                elements0[4] = address6;
                var address7 = FAILURE;
                var chunk2 = null;

                if (this._offset < this._inputSize) {
                  chunk2 = this._input.substring(this._offset, this._offset + 1);
                }

                if (chunk2 === ')') {
                  address7 = new TreeNode(this._input.substring(this._offset, this._offset + 1), this._offset);
                  this._offset = this._offset + 1;
                } else {
                  address7 = FAILURE;

                  if (this._offset > this._failure) {
                    this._failure = this._offset;
                    this._expected = [];
                  }

                  if (this._offset === this._failure) {
                    this._expected.push('")"');
                  }
                }

                if (address7 !== FAILURE) {
                  elements0[5] = address7;
                } else {
                  elements0 = null;
                  this._offset = index1;
                }
              } else {
                elements0 = null;
                this._offset = index1;
              }
            } else {
              elements0 = null;
              this._offset = index1;
            }
          } else {
            elements0 = null;
            this._offset = index1;
          }
        } else {
          elements0 = null;
          this._offset = index1;
        }
      } else {
        elements0 = null;
        this._offset = index1;
      }

      if (elements0 === null) {
        address0 = FAILURE;
      } else {
        address0 = this._actions.make_function_operation_access(this._input, index1, this._offset, elements0);
        this._offset = this._offset;
      }

      this._cache._func_call_access[index0] = [address0, this._offset];
      return address0;
    },
    _read_namespace: function () {
      var address0 = FAILURE,
          index0 = this._offset;
      this._cache._namespace = this._cache._namespace || {};
      var cached = this._cache._namespace[index0];

      if (cached) {
        this._offset = cached[1];
        return cached[0];
      }

      var index1 = this._offset,
          elements0 = new Array(4);
      var address1 = FAILURE;
      address1 = this._read___();

      if (address1 !== FAILURE) {
        elements0[0] = address1;
        var address2 = FAILURE;
        var index2 = this._offset;
        address2 = this._read_func_call();

        if (address2 === FAILURE) {
          this._offset = index2;
          address2 = this._read_variable();

          if (address2 === FAILURE) {
            this._offset = index2;
          }
        }

        if (address2 !== FAILURE) {
          elements0[1] = address2;
          var address3 = FAILURE;
          var remaining0 = 0,
              index3 = this._offset,
              elements1 = [],
              address4 = true;

          while (address4 !== FAILURE) {
            var index4 = this._offset;
            address4 = this._read_func_call_access();

            if (address4 === FAILURE) {
              this._offset = index4;
              address4 = this._read_map_access();

              if (address4 === FAILURE) {
                this._offset = index4;
                address4 = this._read_variable_access();

                if (address4 === FAILURE) {
                  this._offset = index4;
                }
              }
            }

            if (address4 !== FAILURE) {
              elements1.push(address4);
              --remaining0;
            }
          }

          if (remaining0 <= 0) {
            address3 = new TreeNode(this._input.substring(index3, this._offset), index3, elements1);
            this._offset = this._offset;
          } else {
            address3 = FAILURE;
          }

          if (address3 !== FAILURE) {
            elements0[2] = address3;
            var address5 = FAILURE;
            address5 = this._read___();

            if (address5 !== FAILURE) {
              elements0[3] = address5;
            } else {
              elements0 = null;
              this._offset = index1;
            }
          } else {
            elements0 = null;
            this._offset = index1;
          }
        } else {
          elements0 = null;
          this._offset = index1;
        }
      } else {
        elements0 = null;
        this._offset = index1;
      }

      if (elements0 === null) {
        address0 = FAILURE;
      } else {
        address0 = this._actions.make_and_execute_namespace_operation(this._input, index1, this._offset, elements0);
        this._offset = this._offset;
      }

      this._cache._namespace[index0] = [address0, this._offset];
      return address0;
    },
    _read_comp_expression_ex: function () {
      var address0 = FAILURE,
          index0 = this._offset;
      this._cache._comp_expression_ex = this._cache._comp_expression_ex || {};
      var cached = this._cache._comp_expression_ex[index0];

      if (cached) {
        this._offset = cached[1];
        return cached[0];
      }

      var index1 = this._offset,
          elements0 = new Array(5);
      var address1 = FAILURE;
      address1 = this._read___();

      if (address1 !== FAILURE) {
        elements0[0] = address1;
        var address2 = FAILURE;
        var chunk0 = null;

        if (this._offset < this._inputSize) {
          chunk0 = this._input.substring(this._offset, this._offset + 1);
        }

        if (chunk0 === '(') {
          address2 = new TreeNode(this._input.substring(this._offset, this._offset + 1), this._offset);
          this._offset = this._offset + 1;
        } else {
          address2 = FAILURE;

          if (this._offset > this._failure) {
            this._failure = this._offset;
            this._expected = [];
          }

          if (this._offset === this._failure) {
            this._expected.push('"("');
          }
        }

        if (address2 !== FAILURE) {
          elements0[1] = address2;
          var address3 = FAILURE;
          address3 = this._read_comp_expression();

          if (address3 !== FAILURE) {
            elements0[2] = address3;
            var address4 = FAILURE;
            var chunk1 = null;

            if (this._offset < this._inputSize) {
              chunk1 = this._input.substring(this._offset, this._offset + 1);
            }

            if (chunk1 === ')') {
              address4 = new TreeNode(this._input.substring(this._offset, this._offset + 1), this._offset);
              this._offset = this._offset + 1;
            } else {
              address4 = FAILURE;

              if (this._offset > this._failure) {
                this._failure = this._offset;
                this._expected = [];
              }

              if (this._offset === this._failure) {
                this._expected.push('")"');
              }
            }

            if (address4 !== FAILURE) {
              elements0[3] = address4;
              var address5 = FAILURE;
              address5 = this._read___();

              if (address5 !== FAILURE) {
                elements0[4] = address5;
              } else {
                elements0 = null;
                this._offset = index1;
              }
            } else {
              elements0 = null;
              this._offset = index1;
            }
          } else {
            elements0 = null;
            this._offset = index1;
          }
        } else {
          elements0 = null;
          this._offset = index1;
        }
      } else {
        elements0 = null;
        this._offset = index1;
      }

      if (elements0 === null) {
        address0 = FAILURE;
      } else {
        address0 = this._actions.make_comp_exp_ex(this._input, index1, this._offset, elements0);
        this._offset = this._offset;
      }

      this._cache._comp_expression_ex[index0] = [address0, this._offset];
      return address0;
    },
    _read_string: function () {
      var address0 = FAILURE,
          index0 = this._offset;
      this._cache._string = this._cache._string || {};
      var cached = this._cache._string[index0];

      if (cached) {
        this._offset = cached[1];
        return cached[0];
      }

      var index1 = this._offset,
          elements0 = new Array(5);
      var address1 = FAILURE;
      address1 = this._read___();

      if (address1 !== FAILURE) {
        elements0[0] = address1;
        var address2 = FAILURE;
        var chunk0 = null;

        if (this._offset < this._inputSize) {
          chunk0 = this._input.substring(this._offset, this._offset + 1);
        }

        if (chunk0 !== null && /^[\"]/.test(chunk0)) {
          address2 = new TreeNode(this._input.substring(this._offset, this._offset + 1), this._offset);
          this._offset = this._offset + 1;
        } else {
          address2 = FAILURE;

          if (this._offset > this._failure) {
            this._failure = this._offset;
            this._expected = [];
          }

          if (this._offset === this._failure) {
            this._expected.push('[\\"]');
          }
        }

        if (address2 !== FAILURE) {
          elements0[1] = address2;
          var address3 = FAILURE;
          var remaining0 = 0,
              index2 = this._offset,
              elements1 = [],
              address4 = true;

          while (address4 !== FAILURE) {
            var chunk1 = null;

            if (this._offset < this._inputSize) {
              chunk1 = this._input.substring(this._offset, this._offset + 1);
            }

            if (chunk1 !== null && /^[ !#-~]/.test(chunk1)) {
              address4 = new TreeNode(this._input.substring(this._offset, this._offset + 1), this._offset);
              this._offset = this._offset + 1;
            } else {
              address4 = FAILURE;

              if (this._offset > this._failure) {
                this._failure = this._offset;
                this._expected = [];
              }

              if (this._offset === this._failure) {
                this._expected.push('[ !#-~]');
              }
            }

            if (address4 !== FAILURE) {
              elements1.push(address4);
              --remaining0;
            }
          }

          if (remaining0 <= 0) {
            address3 = new TreeNode(this._input.substring(index2, this._offset), index2, elements1);
            this._offset = this._offset;
          } else {
            address3 = FAILURE;
          }

          if (address3 !== FAILURE) {
            elements0[2] = address3;
            var address5 = FAILURE;
            var chunk2 = null;

            if (this._offset < this._inputSize) {
              chunk2 = this._input.substring(this._offset, this._offset + 1);
            }

            if (chunk2 !== null && /^[\"]/.test(chunk2)) {
              address5 = new TreeNode(this._input.substring(this._offset, this._offset + 1), this._offset);
              this._offset = this._offset + 1;
            } else {
              address5 = FAILURE;

              if (this._offset > this._failure) {
                this._failure = this._offset;
                this._expected = [];
              }

              if (this._offset === this._failure) {
                this._expected.push('[\\"]');
              }
            }

            if (address5 !== FAILURE) {
              elements0[3] = address5;
              var address6 = FAILURE;
              address6 = this._read___();

              if (address6 !== FAILURE) {
                elements0[4] = address6;
              } else {
                elements0 = null;
                this._offset = index1;
              }
            } else {
              elements0 = null;
              this._offset = index1;
            }
          } else {
            elements0 = null;
            this._offset = index1;
          }
        } else {
          elements0 = null;
          this._offset = index1;
        }
      } else {
        elements0 = null;
        this._offset = index1;
      }

      if (elements0 === null) {
        address0 = FAILURE;
      } else {
        address0 = this._actions.make_string(this._input, index1, this._offset, elements0);
        this._offset = this._offset;
      }

      this._cache._string[index0] = [address0, this._offset];
      return address0;
    },
    _read_apostrophe_string: function () {
      var address0 = FAILURE,
          index0 = this._offset;
      this._cache._apostrophe_string = this._cache._apostrophe_string || {};
      var cached = this._cache._apostrophe_string[index0];

      if (cached) {
        this._offset = cached[1];
        return cached[0];
      }

      var index1 = this._offset,
          elements0 = new Array(5);
      var address1 = FAILURE;
      address1 = this._read___();

      if (address1 !== FAILURE) {
        elements0[0] = address1;
        var address2 = FAILURE;
        var chunk0 = null;

        if (this._offset < this._inputSize) {
          chunk0 = this._input.substring(this._offset, this._offset + 1);
        }

        if (chunk0 === '\'') {
          address2 = new TreeNode(this._input.substring(this._offset, this._offset + 1), this._offset);
          this._offset = this._offset + 1;
        } else {
          address2 = FAILURE;

          if (this._offset > this._failure) {
            this._failure = this._offset;
            this._expected = [];
          }

          if (this._offset === this._failure) {
            this._expected.push('"\'"');
          }
        }

        if (address2 !== FAILURE) {
          elements0[1] = address2;
          var address3 = FAILURE;
          var remaining0 = 0,
              index2 = this._offset,
              elements1 = [],
              address4 = true;

          while (address4 !== FAILURE) {
            var chunk1 = null;

            if (this._offset < this._inputSize) {
              chunk1 = this._input.substring(this._offset, this._offset + 1);
            }

            if (chunk1 !== null && /^[^']/.test(chunk1)) {
              address4 = new TreeNode(this._input.substring(this._offset, this._offset + 1), this._offset);
              this._offset = this._offset + 1;
            } else {
              address4 = FAILURE;

              if (this._offset > this._failure) {
                this._failure = this._offset;
                this._expected = [];
              }

              if (this._offset === this._failure) {
                this._expected.push('[^\']');
              }
            }

            if (address4 !== FAILURE) {
              elements1.push(address4);
              --remaining0;
            }
          }

          if (remaining0 <= 0) {
            address3 = new TreeNode(this._input.substring(index2, this._offset), index2, elements1);
            this._offset = this._offset;
          } else {
            address3 = FAILURE;
          }

          if (address3 !== FAILURE) {
            elements0[2] = address3;
            var address5 = FAILURE;
            var chunk2 = null;

            if (this._offset < this._inputSize) {
              chunk2 = this._input.substring(this._offset, this._offset + 1);
            }

            if (chunk2 === '\'') {
              address5 = new TreeNode(this._input.substring(this._offset, this._offset + 1), this._offset);
              this._offset = this._offset + 1;
            } else {
              address5 = FAILURE;

              if (this._offset > this._failure) {
                this._failure = this._offset;
                this._expected = [];
              }

              if (this._offset === this._failure) {
                this._expected.push('"\'"');
              }
            }

            if (address5 !== FAILURE) {
              elements0[3] = address5;
              var address6 = FAILURE;
              address6 = this._read___();

              if (address6 !== FAILURE) {
                elements0[4] = address6;
              } else {
                elements0 = null;
                this._offset = index1;
              }
            } else {
              elements0 = null;
              this._offset = index1;
            }
          } else {
            elements0 = null;
            this._offset = index1;
          }
        } else {
          elements0 = null;
          this._offset = index1;
        }
      } else {
        elements0 = null;
        this._offset = index1;
      }

      if (elements0 === null) {
        address0 = FAILURE;
      } else {
        address0 = this._actions.make_apostrophe_string(this._input, index1, this._offset, elements0);
        this._offset = this._offset;
      }

      this._cache._apostrophe_string[index0] = [address0, this._offset];
      return address0;
    },
    _read_list: function () {
      var address0 = FAILURE,
          index0 = this._offset;
      this._cache._list = this._cache._list || {};
      var cached = this._cache._list[index0];

      if (cached) {
        this._offset = cached[1];
        return cached[0];
      }

      var index1 = this._offset,
          elements0 = new Array(7);
      var address1 = FAILURE;
      address1 = this._read___();

      if (address1 !== FAILURE) {
        elements0[0] = address1;
        var address2 = FAILURE;
        var chunk0 = null;

        if (this._offset < this._inputSize) {
          chunk0 = this._input.substring(this._offset, this._offset + 1);
        }

        if (chunk0 === '[') {
          address2 = new TreeNode(this._input.substring(this._offset, this._offset + 1), this._offset);
          this._offset = this._offset + 1;
        } else {
          address2 = FAILURE;

          if (this._offset > this._failure) {
            this._failure = this._offset;
            this._expected = [];
          }

          if (this._offset === this._failure) {
            this._expected.push('"["');
          }
        }

        if (address2 !== FAILURE) {
          elements0[1] = address2;
          var address3 = FAILURE;
          address3 = this._read___();

          if (address3 !== FAILURE) {
            elements0[2] = address3;
            var address4 = FAILURE;
            var index2 = this._offset;
            var index3 = this._offset,
                elements1 = new Array(3);
            var address5 = FAILURE;
            address5 = this._read_atom();

            if (address5 !== FAILURE) {
              elements1[0] = address5;
              var address6 = FAILURE;
              address6 = this._read___();

              if (address6 !== FAILURE) {
                elements1[1] = address6;
                var address7 = FAILURE;
                var remaining0 = 0,
                    index4 = this._offset,
                    elements2 = [],
                    address8 = true;

                while (address8 !== FAILURE) {
                  var index5 = this._offset,
                      elements3 = new Array(4);
                  var address9 = FAILURE;
                  var chunk1 = null;

                  if (this._offset < this._inputSize) {
                    chunk1 = this._input.substring(this._offset, this._offset + 1);
                  }

                  if (chunk1 === ',') {
                    address9 = new TreeNode(this._input.substring(this._offset, this._offset + 1), this._offset);
                    this._offset = this._offset + 1;
                  } else {
                    address9 = FAILURE;

                    if (this._offset > this._failure) {
                      this._failure = this._offset;
                      this._expected = [];
                    }

                    if (this._offset === this._failure) {
                      this._expected.push('","');
                    }
                  }

                  if (address9 !== FAILURE) {
                    elements3[0] = address9;
                    var address10 = FAILURE;
                    address10 = this._read___();

                    if (address10 !== FAILURE) {
                      elements3[1] = address10;
                      var address11 = FAILURE;
                      address11 = this._read_atom();

                      if (address11 !== FAILURE) {
                        elements3[2] = address11;
                        var address12 = FAILURE;
                        address12 = this._read___();

                        if (address12 !== FAILURE) {
                          elements3[3] = address12;
                        } else {
                          elements3 = null;
                          this._offset = index5;
                        }
                      } else {
                        elements3 = null;
                        this._offset = index5;
                      }
                    } else {
                      elements3 = null;
                      this._offset = index5;
                    }
                  } else {
                    elements3 = null;
                    this._offset = index5;
                  }

                  if (elements3 === null) {
                    address8 = FAILURE;
                  } else {
                    address8 = new TreeNode13(this._input.substring(index5, this._offset), index5, elements3);
                    this._offset = this._offset;
                  }

                  if (address8 !== FAILURE) {
                    elements2.push(address8);
                    --remaining0;
                  }
                }

                if (remaining0 <= 0) {
                  address7 = new TreeNode(this._input.substring(index4, this._offset), index4, elements2);
                  this._offset = this._offset;
                } else {
                  address7 = FAILURE;
                }

                if (address7 !== FAILURE) {
                  elements1[2] = address7;
                } else {
                  elements1 = null;
                  this._offset = index3;
                }
              } else {
                elements1 = null;
                this._offset = index3;
              }
            } else {
              elements1 = null;
              this._offset = index3;
            }

            if (elements1 === null) {
              address4 = FAILURE;
            } else {
              address4 = new TreeNode12(this._input.substring(index3, this._offset), index3, elements1);
              this._offset = this._offset;
            }

            if (address4 === FAILURE) {
              address4 = new TreeNode(this._input.substring(index2, index2), index2);
              this._offset = index2;
            }

            if (address4 !== FAILURE) {
              elements0[3] = address4;
              var address13 = FAILURE;
              address13 = this._read___();

              if (address13 !== FAILURE) {
                elements0[4] = address13;
                var address14 = FAILURE;
                var chunk2 = null;

                if (this._offset < this._inputSize) {
                  chunk2 = this._input.substring(this._offset, this._offset + 1);
                }

                if (chunk2 === ']') {
                  address14 = new TreeNode(this._input.substring(this._offset, this._offset + 1), this._offset);
                  this._offset = this._offset + 1;
                } else {
                  address14 = FAILURE;

                  if (this._offset > this._failure) {
                    this._failure = this._offset;
                    this._expected = [];
                  }

                  if (this._offset === this._failure) {
                    this._expected.push('"]"');
                  }
                }

                if (address14 !== FAILURE) {
                  elements0[5] = address14;
                  var address15 = FAILURE;
                  address15 = this._read___();

                  if (address15 !== FAILURE) {
                    elements0[6] = address15;
                  } else {
                    elements0 = null;
                    this._offset = index1;
                  }
                } else {
                  elements0 = null;
                  this._offset = index1;
                }
              } else {
                elements0 = null;
                this._offset = index1;
              }
            } else {
              elements0 = null;
              this._offset = index1;
            }
          } else {
            elements0 = null;
            this._offset = index1;
          }
        } else {
          elements0 = null;
          this._offset = index1;
        }
      } else {
        elements0 = null;
        this._offset = index1;
      }

      if (elements0 === null) {
        address0 = FAILURE;
      } else {
        address0 = this._actions.make_list(this._input, index1, this._offset, elements0);
        this._offset = this._offset;
      }

      this._cache._list[index0] = [address0, this._offset];
      return address0;
    },
    _read_chr: function () {
      var address0 = FAILURE,
          index0 = this._offset;
      this._cache._chr = this._cache._chr || {};
      var cached = this._cache._chr[index0];

      if (cached) {
        this._offset = cached[1];
        return cached[0];
      }

      var index1 = this._offset,
          elements0 = new Array(5);
      var address1 = FAILURE;
      address1 = this._read___();

      if (address1 !== FAILURE) {
        elements0[0] = address1;
        var address2 = FAILURE;
        var chunk0 = null;

        if (this._offset < this._inputSize) {
          chunk0 = this._input.substring(this._offset, this._offset + 1);
        }

        if (chunk0 !== null && /^[']/.test(chunk0)) {
          address2 = new TreeNode(this._input.substring(this._offset, this._offset + 1), this._offset);
          this._offset = this._offset + 1;
        } else {
          address2 = FAILURE;

          if (this._offset > this._failure) {
            this._failure = this._offset;
            this._expected = [];
          }

          if (this._offset === this._failure) {
            this._expected.push('[\']');
          }
        }

        if (address2 !== FAILURE) {
          elements0[1] = address2;
          var address3 = FAILURE;
          var chunk1 = null;

          if (this._offset < this._inputSize) {
            chunk1 = this._input.substring(this._offset, this._offset + 1);
          }

          if (chunk1 !== null && /^[ !#-~]/.test(chunk1)) {
            address3 = new TreeNode(this._input.substring(this._offset, this._offset + 1), this._offset);
            this._offset = this._offset + 1;
          } else {
            address3 = FAILURE;

            if (this._offset > this._failure) {
              this._failure = this._offset;
              this._expected = [];
            }

            if (this._offset === this._failure) {
              this._expected.push('[ !#-~]');
            }
          }

          if (address3 !== FAILURE) {
            elements0[2] = address3;
            var address4 = FAILURE;
            var chunk2 = null;

            if (this._offset < this._inputSize) {
              chunk2 = this._input.substring(this._offset, this._offset + 1);
            }

            if (chunk2 !== null && /^[']/.test(chunk2)) {
              address4 = new TreeNode(this._input.substring(this._offset, this._offset + 1), this._offset);
              this._offset = this._offset + 1;
            } else {
              address4 = FAILURE;

              if (this._offset > this._failure) {
                this._failure = this._offset;
                this._expected = [];
              }

              if (this._offset === this._failure) {
                this._expected.push('[\']');
              }
            }

            if (address4 !== FAILURE) {
              elements0[3] = address4;
              var address5 = FAILURE;
              address5 = this._read___();

              if (address5 !== FAILURE) {
                elements0[4] = address5;
              } else {
                elements0 = null;
                this._offset = index1;
              }
            } else {
              elements0 = null;
              this._offset = index1;
            }
          } else {
            elements0 = null;
            this._offset = index1;
          }
        } else {
          elements0 = null;
          this._offset = index1;
        }
      } else {
        elements0 = null;
        this._offset = index1;
      }

      if (elements0 === null) {
        address0 = FAILURE;
      } else {
        address0 = this._actions.make_char(this._input, index1, this._offset, elements0);
        this._offset = this._offset;
      }

      this._cache._chr[index0] = [address0, this._offset];
      return address0;
    },
    _read_number: function () {
      var address0 = FAILURE,
          index0 = this._offset;
      this._cache._number = this._cache._number || {};
      var cached = this._cache._number[index0];

      if (cached) {
        this._offset = cached[1];
        return cached[0];
      }

      var index1 = this._offset,
          elements0 = new Array(4);
      var address1 = FAILURE;
      address1 = this._read___();

      if (address1 !== FAILURE) {
        elements0[0] = address1;
        var address2 = FAILURE;
        var index2 = this._offset;
        var chunk0 = null;

        if (this._offset < this._inputSize) {
          chunk0 = this._input.substring(this._offset, this._offset + 1);
        }

        if (chunk0 === '-') {
          address2 = new TreeNode(this._input.substring(this._offset, this._offset + 1), this._offset);
          this._offset = this._offset + 1;
        } else {
          address2 = FAILURE;

          if (this._offset > this._failure) {
            this._failure = this._offset;
            this._expected = [];
          }

          if (this._offset === this._failure) {
            this._expected.push('"-"');
          }
        }

        if (address2 === FAILURE) {
          address2 = new TreeNode(this._input.substring(index2, index2), index2);
          this._offset = index2;
        }

        if (address2 !== FAILURE) {
          elements0[1] = address2;
          var address3 = FAILURE;
          var remaining0 = 1,
              index3 = this._offset,
              elements1 = [],
              address4 = true;

          while (address4 !== FAILURE) {
            var chunk1 = null;

            if (this._offset < this._inputSize) {
              chunk1 = this._input.substring(this._offset, this._offset + 1);
            }

            if (chunk1 !== null && /^[0-9]/.test(chunk1)) {
              address4 = new TreeNode(this._input.substring(this._offset, this._offset + 1), this._offset);
              this._offset = this._offset + 1;
            } else {
              address4 = FAILURE;

              if (this._offset > this._failure) {
                this._failure = this._offset;
                this._expected = [];
              }

              if (this._offset === this._failure) {
                this._expected.push('[0-9]');
              }
            }

            if (address4 !== FAILURE) {
              elements1.push(address4);
              --remaining0;
            }
          }

          if (remaining0 <= 0) {
            address3 = new TreeNode(this._input.substring(index3, this._offset), index3, elements1);
            this._offset = this._offset;
          } else {
            address3 = FAILURE;
          }

          if (address3 !== FAILURE) {
            elements0[2] = address3;
            var address5 = FAILURE;
            address5 = this._read___();

            if (address5 !== FAILURE) {
              elements0[3] = address5;
            } else {
              elements0 = null;
              this._offset = index1;
            }
          } else {
            elements0 = null;
            this._offset = index1;
          }
        } else {
          elements0 = null;
          this._offset = index1;
        }
      } else {
        elements0 = null;
        this._offset = index1;
      }

      if (elements0 === null) {
        address0 = FAILURE;
      } else {
        address0 = this._actions.make_number(this._input, index1, this._offset, elements0);
        this._offset = this._offset;
      }

      this._cache._number[index0] = [address0, this._offset];
      return address0;
    },
    _read_float_: function () {
      var address0 = FAILURE,
          index0 = this._offset;
      this._cache._float_ = this._cache._float_ || {};
      var cached = this._cache._float_[index0];

      if (cached) {
        this._offset = cached[1];
        return cached[0];
      }

      var index1 = this._offset,
          elements0 = new Array(6);
      var address1 = FAILURE;
      address1 = this._read___();

      if (address1 !== FAILURE) {
        elements0[0] = address1;
        var address2 = FAILURE;
        var index2 = this._offset;
        var chunk0 = null;

        if (this._offset < this._inputSize) {
          chunk0 = this._input.substring(this._offset, this._offset + 1);
        }

        if (chunk0 === '-') {
          address2 = new TreeNode(this._input.substring(this._offset, this._offset + 1), this._offset);
          this._offset = this._offset + 1;
        } else {
          address2 = FAILURE;

          if (this._offset > this._failure) {
            this._failure = this._offset;
            this._expected = [];
          }

          if (this._offset === this._failure) {
            this._expected.push('"-"');
          }
        }

        if (address2 === FAILURE) {
          address2 = new TreeNode(this._input.substring(index2, index2), index2);
          this._offset = index2;
        }

        if (address2 !== FAILURE) {
          elements0[1] = address2;
          var address3 = FAILURE;
          var remaining0 = 1,
              index3 = this._offset,
              elements1 = [],
              address4 = true;

          while (address4 !== FAILURE) {
            var chunk1 = null;

            if (this._offset < this._inputSize) {
              chunk1 = this._input.substring(this._offset, this._offset + 1);
            }

            if (chunk1 !== null && /^[0-9]/.test(chunk1)) {
              address4 = new TreeNode(this._input.substring(this._offset, this._offset + 1), this._offset);
              this._offset = this._offset + 1;
            } else {
              address4 = FAILURE;

              if (this._offset > this._failure) {
                this._failure = this._offset;
                this._expected = [];
              }

              if (this._offset === this._failure) {
                this._expected.push('[0-9]');
              }
            }

            if (address4 !== FAILURE) {
              elements1.push(address4);
              --remaining0;
            }
          }

          if (remaining0 <= 0) {
            address3 = new TreeNode(this._input.substring(index3, this._offset), index3, elements1);
            this._offset = this._offset;
          } else {
            address3 = FAILURE;
          }

          if (address3 !== FAILURE) {
            elements0[2] = address3;
            var address5 = FAILURE;
            var chunk2 = null;

            if (this._offset < this._inputSize) {
              chunk2 = this._input.substring(this._offset, this._offset + 1);
            }

            if (chunk2 === '.') {
              address5 = new TreeNode(this._input.substring(this._offset, this._offset + 1), this._offset);
              this._offset = this._offset + 1;
            } else {
              address5 = FAILURE;

              if (this._offset > this._failure) {
                this._failure = this._offset;
                this._expected = [];
              }

              if (this._offset === this._failure) {
                this._expected.push('"."');
              }
            }

            if (address5 !== FAILURE) {
              elements0[3] = address5;
              var address6 = FAILURE;
              var remaining1 = 1,
                  index4 = this._offset,
                  elements2 = [],
                  address7 = true;

              while (address7 !== FAILURE) {
                var chunk3 = null;

                if (this._offset < this._inputSize) {
                  chunk3 = this._input.substring(this._offset, this._offset + 1);
                }

                if (chunk3 !== null && /^[0-9]/.test(chunk3)) {
                  address7 = new TreeNode(this._input.substring(this._offset, this._offset + 1), this._offset);
                  this._offset = this._offset + 1;
                } else {
                  address7 = FAILURE;

                  if (this._offset > this._failure) {
                    this._failure = this._offset;
                    this._expected = [];
                  }

                  if (this._offset === this._failure) {
                    this._expected.push('[0-9]');
                  }
                }

                if (address7 !== FAILURE) {
                  elements2.push(address7);
                  --remaining1;
                }
              }

              if (remaining1 <= 0) {
                address6 = new TreeNode(this._input.substring(index4, this._offset), index4, elements2);
                this._offset = this._offset;
              } else {
                address6 = FAILURE;
              }

              if (address6 !== FAILURE) {
                elements0[4] = address6;
                var address8 = FAILURE;
                address8 = this._read___();

                if (address8 !== FAILURE) {
                  elements0[5] = address8;
                } else {
                  elements0 = null;
                  this._offset = index1;
                }
              } else {
                elements0 = null;
                this._offset = index1;
              }
            } else {
              elements0 = null;
              this._offset = index1;
            }
          } else {
            elements0 = null;
            this._offset = index1;
          }
        } else {
          elements0 = null;
          this._offset = index1;
        }
      } else {
        elements0 = null;
        this._offset = index1;
      }

      if (elements0 === null) {
        address0 = FAILURE;
      } else {
        address0 = this._actions.make_float(this._input, index1, this._offset, elements0);
        this._offset = this._offset;
      }

      this._cache._float_[index0] = [address0, this._offset];
      return address0;
    },
    _read_boolean_: function () {
      var address0 = FAILURE,
          index0 = this._offset;
      this._cache._boolean_ = this._cache._boolean_ || {};
      var cached = this._cache._boolean_[index0];

      if (cached) {
        this._offset = cached[1];
        return cached[0];
      }

      var index1 = this._offset,
          elements0 = new Array(3);
      var address1 = FAILURE;
      address1 = this._read___();

      if (address1 !== FAILURE) {
        elements0[0] = address1;
        var address2 = FAILURE;
        var index2 = this._offset;
        var chunk0 = null;

        if (this._offset < this._inputSize) {
          chunk0 = this._input.substring(this._offset, this._offset + 4);
        }

        if (chunk0 === 'True') {
          address2 = new TreeNode(this._input.substring(this._offset, this._offset + 4), this._offset);
          this._offset = this._offset + 4;
        } else {
          address2 = FAILURE;

          if (this._offset > this._failure) {
            this._failure = this._offset;
            this._expected = [];
          }

          if (this._offset === this._failure) {
            this._expected.push('"True"');
          }
        }

        if (address2 === FAILURE) {
          this._offset = index2;
          var chunk1 = null;

          if (this._offset < this._inputSize) {
            chunk1 = this._input.substring(this._offset, this._offset + 4);
          }

          if (chunk1 === 'true') {
            address2 = new TreeNode(this._input.substring(this._offset, this._offset + 4), this._offset);
            this._offset = this._offset + 4;
          } else {
            address2 = FAILURE;

            if (this._offset > this._failure) {
              this._failure = this._offset;
              this._expected = [];
            }

            if (this._offset === this._failure) {
              this._expected.push('"true"');
            }
          }

          if (address2 === FAILURE) {
            this._offset = index2;
            var chunk2 = null;

            if (this._offset < this._inputSize) {
              chunk2 = this._input.substring(this._offset, this._offset + 5);
            }

            if (chunk2 === 'False') {
              address2 = new TreeNode(this._input.substring(this._offset, this._offset + 5), this._offset);
              this._offset = this._offset + 5;
            } else {
              address2 = FAILURE;

              if (this._offset > this._failure) {
                this._failure = this._offset;
                this._expected = [];
              }

              if (this._offset === this._failure) {
                this._expected.push('"False"');
              }
            }

            if (address2 === FAILURE) {
              this._offset = index2;
              var chunk3 = null;

              if (this._offset < this._inputSize) {
                chunk3 = this._input.substring(this._offset, this._offset + 5);
              }

              if (chunk3 === 'false') {
                address2 = new TreeNode(this._input.substring(this._offset, this._offset + 5), this._offset);
                this._offset = this._offset + 5;
              } else {
                address2 = FAILURE;

                if (this._offset > this._failure) {
                  this._failure = this._offset;
                  this._expected = [];
                }

                if (this._offset === this._failure) {
                  this._expected.push('"false"');
                }
              }

              if (address2 === FAILURE) {
                this._offset = index2;
              }
            }
          }
        }

        if (address2 !== FAILURE) {
          elements0[1] = address2;
          var address3 = FAILURE;
          address3 = this._read___();

          if (address3 !== FAILURE) {
            elements0[2] = address3;
          } else {
            elements0 = null;
            this._offset = index1;
          }
        } else {
          elements0 = null;
          this._offset = index1;
        }
      } else {
        elements0 = null;
        this._offset = index1;
      }

      if (elements0 === null) {
        address0 = FAILURE;
      } else {
        address0 = this._actions.make_bool(this._input, index1, this._offset, elements0);
        this._offset = this._offset;
      }

      this._cache._boolean_[index0] = [address0, this._offset];
      return address0;
    },
    _read_null_: function () {
      var address0 = FAILURE,
          index0 = this._offset;
      this._cache._null_ = this._cache._null_ || {};
      var cached = this._cache._null_[index0];

      if (cached) {
        this._offset = cached[1];
        return cached[0];
      }

      var index1 = this._offset,
          elements0 = new Array(3);
      var address1 = FAILURE;
      address1 = this._read___();

      if (address1 !== FAILURE) {
        elements0[0] = address1;
        var address2 = FAILURE;
        var index2 = this._offset;
        var chunk0 = null;

        if (this._offset < this._inputSize) {
          chunk0 = this._input.substring(this._offset, this._offset + 4);
        }

        if (chunk0 === 'None') {
          address2 = new TreeNode(this._input.substring(this._offset, this._offset + 4), this._offset);
          this._offset = this._offset + 4;
        } else {
          address2 = FAILURE;

          if (this._offset > this._failure) {
            this._failure = this._offset;
            this._expected = [];
          }

          if (this._offset === this._failure) {
            this._expected.push('"None"');
          }
        }

        if (address2 === FAILURE) {
          this._offset = index2;
          var chunk1 = null;

          if (this._offset < this._inputSize) {
            chunk1 = this._input.substring(this._offset, this._offset + 3);
          }

          if (chunk1 === 'nil') {
            address2 = new TreeNode(this._input.substring(this._offset, this._offset + 3), this._offset);
            this._offset = this._offset + 3;
          } else {
            address2 = FAILURE;

            if (this._offset > this._failure) {
              this._failure = this._offset;
              this._expected = [];
            }

            if (this._offset === this._failure) {
              this._expected.push('"nil"');
            }
          }

          if (address2 === FAILURE) {
            this._offset = index2;
            var chunk2 = null;

            if (this._offset < this._inputSize) {
              chunk2 = this._input.substring(this._offset, this._offset + 4);
            }

            if (chunk2 === 'null') {
              address2 = new TreeNode(this._input.substring(this._offset, this._offset + 4), this._offset);
              this._offset = this._offset + 4;
            } else {
              address2 = FAILURE;

              if (this._offset > this._failure) {
                this._failure = this._offset;
                this._expected = [];
              }

              if (this._offset === this._failure) {
                this._expected.push('"null"');
              }
            }

            if (address2 === FAILURE) {
              this._offset = index2;
            }
          }
        }

        if (address2 !== FAILURE) {
          elements0[1] = address2;
          var address3 = FAILURE;
          address3 = this._read___();

          if (address3 !== FAILURE) {
            elements0[2] = address3;
          } else {
            elements0 = null;
            this._offset = index1;
          }
        } else {
          elements0 = null;
          this._offset = index1;
        }
      } else {
        elements0 = null;
        this._offset = index1;
      }

      if (elements0 === null) {
        address0 = FAILURE;
      } else {
        address0 = this._actions.make_null(this._input, index1, this._offset, elements0);
        this._offset = this._offset;
      }

      this._cache._null_[index0] = [address0, this._offset];
      return address0;
    },
    _read_undefined_: function () {
      var address0 = FAILURE,
          index0 = this._offset;
      this._cache._undefined_ = this._cache._undefined_ || {};
      var cached = this._cache._undefined_[index0];

      if (cached) {
        this._offset = cached[1];
        return cached[0];
      }

      var index1 = this._offset,
          elements0 = new Array(3);
      var address1 = FAILURE;
      address1 = this._read___();

      if (address1 !== FAILURE) {
        elements0[0] = address1;
        var address2 = FAILURE;
        var chunk0 = null;

        if (this._offset < this._inputSize) {
          chunk0 = this._input.substring(this._offset, this._offset + 9);
        }

        if (chunk0 === 'undefined') {
          address2 = new TreeNode(this._input.substring(this._offset, this._offset + 9), this._offset);
          this._offset = this._offset + 9;
        } else {
          address2 = FAILURE;

          if (this._offset > this._failure) {
            this._failure = this._offset;
            this._expected = [];
          }

          if (this._offset === this._failure) {
            this._expected.push('"undefined"');
          }
        }

        if (address2 !== FAILURE) {
          elements0[1] = address2;
          var address3 = FAILURE;
          address3 = this._read___();

          if (address3 !== FAILURE) {
            elements0[2] = address3;
          } else {
            elements0 = null;
            this._offset = index1;
          }
        } else {
          elements0 = null;
          this._offset = index1;
        }
      } else {
        elements0 = null;
        this._offset = index1;
      }

      if (elements0 === null) {
        address0 = FAILURE;
      } else {
        address0 = this._actions.make_undefined(this._input, index1, this._offset, elements0);
        this._offset = this._offset;
      }

      this._cache._undefined_[index0] = [address0, this._offset];
      return address0;
    },
    _read_opt_: function () {
      var address0 = FAILURE,
          index0 = this._offset;
      this._cache._opt_ = this._cache._opt_ || {};
      var cached = this._cache._opt_[index0];

      if (cached) {
        this._offset = cached[1];
        return cached[0];
      }

      var index1 = this._offset,
          elements0 = new Array(3);
      var address1 = FAILURE;
      address1 = this._read___();

      if (address1 !== FAILURE) {
        elements0[0] = address1;
        var address2 = FAILURE;
        var index2 = this._offset;
        var chunk0 = null;

        if (this._offset < this._inputSize) {
          chunk0 = this._input.substring(this._offset, this._offset + 1);
        }

        if (chunk0 === '+') {
          address2 = new TreeNode(this._input.substring(this._offset, this._offset + 1), this._offset);
          this._offset = this._offset + 1;
        } else {
          address2 = FAILURE;

          if (this._offset > this._failure) {
            this._failure = this._offset;
            this._expected = [];
          }

          if (this._offset === this._failure) {
            this._expected.push('"+"');
          }
        }

        if (address2 === FAILURE) {
          this._offset = index2;
          var chunk1 = null;

          if (this._offset < this._inputSize) {
            chunk1 = this._input.substring(this._offset, this._offset + 1);
          }

          if (chunk1 === '-') {
            address2 = new TreeNode(this._input.substring(this._offset, this._offset + 1), this._offset);
            this._offset = this._offset + 1;
          } else {
            address2 = FAILURE;

            if (this._offset > this._failure) {
              this._failure = this._offset;
              this._expected = [];
            }

            if (this._offset === this._failure) {
              this._expected.push('"-"');
            }
          }

          if (address2 === FAILURE) {
            this._offset = index2;
            var chunk2 = null;

            if (this._offset < this._inputSize) {
              chunk2 = this._input.substring(this._offset, this._offset + 1);
            }

            if (chunk2 === '*') {
              address2 = new TreeNode(this._input.substring(this._offset, this._offset + 1), this._offset);
              this._offset = this._offset + 1;
            } else {
              address2 = FAILURE;

              if (this._offset > this._failure) {
                this._failure = this._offset;
                this._expected = [];
              }

              if (this._offset === this._failure) {
                this._expected.push('"*"');
              }
            }

            if (address2 === FAILURE) {
              this._offset = index2;
              var chunk3 = null;

              if (this._offset < this._inputSize) {
                chunk3 = this._input.substring(this._offset, this._offset + 1);
              }

              if (chunk3 === '/') {
                address2 = new TreeNode(this._input.substring(this._offset, this._offset + 1), this._offset);
                this._offset = this._offset + 1;
              } else {
                address2 = FAILURE;

                if (this._offset > this._failure) {
                  this._failure = this._offset;
                  this._expected = [];
                }

                if (this._offset === this._failure) {
                  this._expected.push('"/"');
                }
              }

              if (address2 === FAILURE) {
                this._offset = index2;
                var chunk4 = null;

                if (this._offset < this._inputSize) {
                  chunk4 = this._input.substring(this._offset, this._offset + 2);
                }

                if (chunk4 === '<=') {
                  address2 = new TreeNode(this._input.substring(this._offset, this._offset + 2), this._offset);
                  this._offset = this._offset + 2;
                } else {
                  address2 = FAILURE;

                  if (this._offset > this._failure) {
                    this._failure = this._offset;
                    this._expected = [];
                  }

                  if (this._offset === this._failure) {
                    this._expected.push('"<="');
                  }
                }

                if (address2 === FAILURE) {
                  this._offset = index2;
                  var chunk5 = null;

                  if (this._offset < this._inputSize) {
                    chunk5 = this._input.substring(this._offset, this._offset + 2);
                  }

                  if (chunk5 === '>=') {
                    address2 = new TreeNode(this._input.substring(this._offset, this._offset + 2), this._offset);
                    this._offset = this._offset + 2;
                  } else {
                    address2 = FAILURE;

                    if (this._offset > this._failure) {
                      this._failure = this._offset;
                      this._expected = [];
                    }

                    if (this._offset === this._failure) {
                      this._expected.push('">="');
                    }
                  }

                  if (address2 === FAILURE) {
                    this._offset = index2;
                    var chunk6 = null;

                    if (this._offset < this._inputSize) {
                      chunk6 = this._input.substring(this._offset, this._offset + 2);
                    }

                    if (chunk6 === '!=') {
                      address2 = new TreeNode(this._input.substring(this._offset, this._offset + 2), this._offset);
                      this._offset = this._offset + 2;
                    } else {
                      address2 = FAILURE;

                      if (this._offset > this._failure) {
                        this._failure = this._offset;
                        this._expected = [];
                      }

                      if (this._offset === this._failure) {
                        this._expected.push('"!="');
                      }
                    }

                    if (address2 === FAILURE) {
                      this._offset = index2;
                      var chunk7 = null;

                      if (this._offset < this._inputSize) {
                        chunk7 = this._input.substring(this._offset, this._offset + 2);
                      }

                      if (chunk7 === '==') {
                        address2 = new TreeNode(this._input.substring(this._offset, this._offset + 2), this._offset);
                        this._offset = this._offset + 2;
                      } else {
                        address2 = FAILURE;

                        if (this._offset > this._failure) {
                          this._failure = this._offset;
                          this._expected = [];
                        }

                        if (this._offset === this._failure) {
                          this._expected.push('"=="');
                        }
                      }

                      if (address2 === FAILURE) {
                        this._offset = index2;
                        var chunk8 = null;

                        if (this._offset < this._inputSize) {
                          chunk8 = this._input.substring(this._offset, this._offset + 1);
                        }

                        if (chunk8 === '=') {
                          address2 = new TreeNode(this._input.substring(this._offset, this._offset + 1), this._offset);
                          this._offset = this._offset + 1;
                        } else {
                          address2 = FAILURE;

                          if (this._offset > this._failure) {
                            this._failure = this._offset;
                            this._expected = [];
                          }

                          if (this._offset === this._failure) {
                            this._expected.push('"="');
                          }
                        }

                        if (address2 === FAILURE) {
                          this._offset = index2;
                          var chunk9 = null;

                          if (this._offset < this._inputSize) {
                            chunk9 = this._input.substring(this._offset, this._offset + 1);
                          }

                          if (chunk9 === '>') {
                            address2 = new TreeNode(this._input.substring(this._offset, this._offset + 1), this._offset);
                            this._offset = this._offset + 1;
                          } else {
                            address2 = FAILURE;

                            if (this._offset > this._failure) {
                              this._failure = this._offset;
                              this._expected = [];
                            }

                            if (this._offset === this._failure) {
                              this._expected.push('">"');
                            }
                          }

                          if (address2 === FAILURE) {
                            this._offset = index2;
                            var chunk10 = null;

                            if (this._offset < this._inputSize) {
                              chunk10 = this._input.substring(this._offset, this._offset + 1);
                            }

                            if (chunk10 === '<') {
                              address2 = new TreeNode(this._input.substring(this._offset, this._offset + 1), this._offset);
                              this._offset = this._offset + 1;
                            } else {
                              address2 = FAILURE;

                              if (this._offset > this._failure) {
                                this._failure = this._offset;
                                this._expected = [];
                              }

                              if (this._offset === this._failure) {
                                this._expected.push('"<"');
                              }
                            }

                            if (address2 === FAILURE) {
                              this._offset = index2;
                              var chunk11 = null;

                              if (this._offset < this._inputSize) {
                                chunk11 = this._input.substring(this._offset, this._offset + 2);
                              }

                              if (chunk11 === 'LT') {
                                address2 = new TreeNode(this._input.substring(this._offset, this._offset + 2), this._offset);
                                this._offset = this._offset + 2;
                              } else {
                                address2 = FAILURE;

                                if (this._offset > this._failure) {
                                  this._failure = this._offset;
                                  this._expected = [];
                                }

                                if (this._offset === this._failure) {
                                  this._expected.push('"LT"');
                                }
                              }

                              if (address2 === FAILURE) {
                                this._offset = index2;
                                var chunk12 = null;

                                if (this._offset < this._inputSize) {
                                  chunk12 = this._input.substring(this._offset, this._offset + 2);
                                }

                                if (chunk12 === 'GT') {
                                  address2 = new TreeNode(this._input.substring(this._offset, this._offset + 2), this._offset);
                                  this._offset = this._offset + 2;
                                } else {
                                  address2 = FAILURE;

                                  if (this._offset > this._failure) {
                                    this._failure = this._offset;
                                    this._expected = [];
                                  }

                                  if (this._offset === this._failure) {
                                    this._expected.push('"GT"');
                                  }
                                }

                                if (address2 === FAILURE) {
                                  this._offset = index2;
                                  var chunk13 = null;

                                  if (this._offset < this._inputSize) {
                                    chunk13 = this._input.substring(this._offset, this._offset + 2);
                                  }

                                  if (chunk13 === 'LE') {
                                    address2 = new TreeNode(this._input.substring(this._offset, this._offset + 2), this._offset);
                                    this._offset = this._offset + 2;
                                  } else {
                                    address2 = FAILURE;

                                    if (this._offset > this._failure) {
                                      this._failure = this._offset;
                                      this._expected = [];
                                    }

                                    if (this._offset === this._failure) {
                                      this._expected.push('"LE"');
                                    }
                                  }

                                  if (address2 === FAILURE) {
                                    this._offset = index2;
                                    var chunk14 = null;

                                    if (this._offset < this._inputSize) {
                                      chunk14 = this._input.substring(this._offset, this._offset + 2);
                                    }

                                    if (chunk14 === 'GE') {
                                      address2 = new TreeNode(this._input.substring(this._offset, this._offset + 2), this._offset);
                                      this._offset = this._offset + 2;
                                    } else {
                                      address2 = FAILURE;

                                      if (this._offset > this._failure) {
                                        this._failure = this._offset;
                                        this._expected = [];
                                      }

                                      if (this._offset === this._failure) {
                                        this._expected.push('"GE"');
                                      }
                                    }

                                    if (address2 === FAILURE) {
                                      this._offset = index2;
                                      var chunk15 = null;

                                      if (this._offset < this._inputSize) {
                                        chunk15 = this._input.substring(this._offset, this._offset + 2);
                                      }

                                      if (chunk15 === 'EQ') {
                                        address2 = new TreeNode(this._input.substring(this._offset, this._offset + 2), this._offset);
                                        this._offset = this._offset + 2;
                                      } else {
                                        address2 = FAILURE;

                                        if (this._offset > this._failure) {
                                          this._failure = this._offset;
                                          this._expected = [];
                                        }

                                        if (this._offset === this._failure) {
                                          this._expected.push('"EQ"');
                                        }
                                      }

                                      if (address2 === FAILURE) {
                                        this._offset = index2;
                                        var chunk16 = null;

                                        if (this._offset < this._inputSize) {
                                          chunk16 = this._input.substring(this._offset, this._offset + 2);
                                        }

                                        if (chunk16 === 'NE') {
                                          address2 = new TreeNode(this._input.substring(this._offset, this._offset + 2), this._offset);
                                          this._offset = this._offset + 2;
                                        } else {
                                          address2 = FAILURE;

                                          if (this._offset > this._failure) {
                                            this._failure = this._offset;
                                            this._expected = [];
                                          }

                                          if (this._offset === this._failure) {
                                            this._expected.push('"NE"');
                                          }
                                        }

                                        if (address2 === FAILURE) {
                                          this._offset = index2;
                                          var chunk17 = null;

                                          if (this._offset < this._inputSize) {
                                            chunk17 = this._input.substring(this._offset, this._offset + 2);
                                          }

                                          if (chunk17 === 'lt') {
                                            address2 = new TreeNode(this._input.substring(this._offset, this._offset + 2), this._offset);
                                            this._offset = this._offset + 2;
                                          } else {
                                            address2 = FAILURE;

                                            if (this._offset > this._failure) {
                                              this._failure = this._offset;
                                              this._expected = [];
                                            }

                                            if (this._offset === this._failure) {
                                              this._expected.push('"lt"');
                                            }
                                          }

                                          if (address2 === FAILURE) {
                                            this._offset = index2;
                                            var chunk18 = null;

                                            if (this._offset < this._inputSize) {
                                              chunk18 = this._input.substring(this._offset, this._offset + 2);
                                            }

                                            if (chunk18 === 'gt') {
                                              address2 = new TreeNode(this._input.substring(this._offset, this._offset + 2), this._offset);
                                              this._offset = this._offset + 2;
                                            } else {
                                              address2 = FAILURE;

                                              if (this._offset > this._failure) {
                                                this._failure = this._offset;
                                                this._expected = [];
                                              }

                                              if (this._offset === this._failure) {
                                                this._expected.push('"gt"');
                                              }
                                            }

                                            if (address2 === FAILURE) {
                                              this._offset = index2;
                                              var chunk19 = null;

                                              if (this._offset < this._inputSize) {
                                                chunk19 = this._input.substring(this._offset, this._offset + 2);
                                              }

                                              if (chunk19 === 'le') {
                                                address2 = new TreeNode(this._input.substring(this._offset, this._offset + 2), this._offset);
                                                this._offset = this._offset + 2;
                                              } else {
                                                address2 = FAILURE;

                                                if (this._offset > this._failure) {
                                                  this._failure = this._offset;
                                                  this._expected = [];
                                                }

                                                if (this._offset === this._failure) {
                                                  this._expected.push('"le"');
                                                }
                                              }

                                              if (address2 === FAILURE) {
                                                this._offset = index2;
                                                var chunk20 = null;

                                                if (this._offset < this._inputSize) {
                                                  chunk20 = this._input.substring(this._offset, this._offset + 2);
                                                }

                                                if (chunk20 === 'ge') {
                                                  address2 = new TreeNode(this._input.substring(this._offset, this._offset + 2), this._offset);
                                                  this._offset = this._offset + 2;
                                                } else {
                                                  address2 = FAILURE;

                                                  if (this._offset > this._failure) {
                                                    this._failure = this._offset;
                                                    this._expected = [];
                                                  }

                                                  if (this._offset === this._failure) {
                                                    this._expected.push('"ge"');
                                                  }
                                                }

                                                if (address2 === FAILURE) {
                                                  this._offset = index2;
                                                  var chunk21 = null;

                                                  if (this._offset < this._inputSize) {
                                                    chunk21 = this._input.substring(this._offset, this._offset + 2);
                                                  }

                                                  if (chunk21 === 'eq') {
                                                    address2 = new TreeNode(this._input.substring(this._offset, this._offset + 2), this._offset);
                                                    this._offset = this._offset + 2;
                                                  } else {
                                                    address2 = FAILURE;

                                                    if (this._offset > this._failure) {
                                                      this._failure = this._offset;
                                                      this._expected = [];
                                                    }

                                                    if (this._offset === this._failure) {
                                                      this._expected.push('"eq"');
                                                    }
                                                  }

                                                  if (address2 === FAILURE) {
                                                    this._offset = index2;
                                                    var chunk22 = null;

                                                    if (this._offset < this._inputSize) {
                                                      chunk22 = this._input.substring(this._offset, this._offset + 2);
                                                    }

                                                    if (chunk22 === 'ne') {
                                                      address2 = new TreeNode(this._input.substring(this._offset, this._offset + 2), this._offset);
                                                      this._offset = this._offset + 2;
                                                    } else {
                                                      address2 = FAILURE;

                                                      if (this._offset > this._failure) {
                                                        this._failure = this._offset;
                                                        this._expected = [];
                                                      }

                                                      if (this._offset === this._failure) {
                                                        this._expected.push('"ne"');
                                                      }
                                                    }

                                                    if (address2 === FAILURE) {
                                                      this._offset = index2;
                                                      var chunk23 = null;

                                                      if (this._offset < this._inputSize) {
                                                        chunk23 = this._input.substring(this._offset, this._offset + 2);
                                                      }

                                                      if (chunk23 === 'in') {
                                                        address2 = new TreeNode(this._input.substring(this._offset, this._offset + 2), this._offset);
                                                        this._offset = this._offset + 2;
                                                      } else {
                                                        address2 = FAILURE;

                                                        if (this._offset > this._failure) {
                                                          this._failure = this._offset;
                                                          this._expected = [];
                                                        }

                                                        if (this._offset === this._failure) {
                                                          this._expected.push('"in"');
                                                        }
                                                      }

                                                      if (address2 === FAILURE) {
                                                        this._offset = index2;
                                                        var chunk24 = null;

                                                        if (this._offset < this._inputSize) {
                                                          chunk24 = this._input.substring(this._offset, this._offset + 2);
                                                        }

                                                        if (chunk24 === 'IN') {
                                                          address2 = new TreeNode(this._input.substring(this._offset, this._offset + 2), this._offset);
                                                          this._offset = this._offset + 2;
                                                        } else {
                                                          address2 = FAILURE;

                                                          if (this._offset > this._failure) {
                                                            this._failure = this._offset;
                                                            this._expected = [];
                                                          }

                                                          if (this._offset === this._failure) {
                                                            this._expected.push('"IN"');
                                                          }
                                                        }

                                                        if (address2 === FAILURE) {
                                                          this._offset = index2;
                                                          var chunk25 = null;

                                                          if (this._offset < this._inputSize) {
                                                            chunk25 = this._input.substring(this._offset, this._offset + 2);
                                                          }

                                                          if (chunk25 === 'or') {
                                                            address2 = new TreeNode(this._input.substring(this._offset, this._offset + 2), this._offset);
                                                            this._offset = this._offset + 2;
                                                          } else {
                                                            address2 = FAILURE;

                                                            if (this._offset > this._failure) {
                                                              this._failure = this._offset;
                                                              this._expected = [];
                                                            }

                                                            if (this._offset === this._failure) {
                                                              this._expected.push('"or"');
                                                            }
                                                          }

                                                          if (address2 === FAILURE) {
                                                            this._offset = index2;
                                                            var chunk26 = null;

                                                            if (this._offset < this._inputSize) {
                                                              chunk26 = this._input.substring(this._offset, this._offset + 2);
                                                            }

                                                            if (chunk26 === 'OR') {
                                                              address2 = new TreeNode(this._input.substring(this._offset, this._offset + 2), this._offset);
                                                              this._offset = this._offset + 2;
                                                            } else {
                                                              address2 = FAILURE;

                                                              if (this._offset > this._failure) {
                                                                this._failure = this._offset;
                                                                this._expected = [];
                                                              }

                                                              if (this._offset === this._failure) {
                                                                this._expected.push('"OR"');
                                                              }
                                                            }

                                                            if (address2 === FAILURE) {
                                                              this._offset = index2;
                                                              var chunk27 = null;

                                                              if (this._offset < this._inputSize) {
                                                                chunk27 = this._input.substring(this._offset, this._offset + 2);
                                                              }

                                                              if (chunk27 === '||') {
                                                                address2 = new TreeNode(this._input.substring(this._offset, this._offset + 2), this._offset);
                                                                this._offset = this._offset + 2;
                                                              } else {
                                                                address2 = FAILURE;

                                                                if (this._offset > this._failure) {
                                                                  this._failure = this._offset;
                                                                  this._expected = [];
                                                                }

                                                                if (this._offset === this._failure) {
                                                                  this._expected.push('"||"');
                                                                }
                                                              }

                                                              if (address2 === FAILURE) {
                                                                this._offset = index2;
                                                                var chunk28 = null;

                                                                if (this._offset < this._inputSize) {
                                                                  chunk28 = this._input.substring(this._offset, this._offset + 3);
                                                                }

                                                                if (chunk28 === 'and') {
                                                                  address2 = new TreeNode(this._input.substring(this._offset, this._offset + 3), this._offset);
                                                                  this._offset = this._offset + 3;
                                                                } else {
                                                                  address2 = FAILURE;

                                                                  if (this._offset > this._failure) {
                                                                    this._failure = this._offset;
                                                                    this._expected = [];
                                                                  }

                                                                  if (this._offset === this._failure) {
                                                                    this._expected.push('"and"');
                                                                  }
                                                                }

                                                                if (address2 === FAILURE) {
                                                                  this._offset = index2;
                                                                  var chunk29 = null;

                                                                  if (this._offset < this._inputSize) {
                                                                    chunk29 = this._input.substring(this._offset, this._offset + 3);
                                                                  }

                                                                  if (chunk29 === 'AND') {
                                                                    address2 = new TreeNode(this._input.substring(this._offset, this._offset + 3), this._offset);
                                                                    this._offset = this._offset + 3;
                                                                  } else {
                                                                    address2 = FAILURE;

                                                                    if (this._offset > this._failure) {
                                                                      this._failure = this._offset;
                                                                      this._expected = [];
                                                                    }

                                                                    if (this._offset === this._failure) {
                                                                      this._expected.push('"AND"');
                                                                    }
                                                                  }

                                                                  if (address2 === FAILURE) {
                                                                    this._offset = index2;
                                                                    var chunk30 = null;

                                                                    if (this._offset < this._inputSize) {
                                                                      chunk30 = this._input.substring(this._offset, this._offset + 2);
                                                                    }

                                                                    if (chunk30 === '&&') {
                                                                      address2 = new TreeNode(this._input.substring(this._offset, this._offset + 2), this._offset);
                                                                      this._offset = this._offset + 2;
                                                                    } else {
                                                                      address2 = FAILURE;

                                                                      if (this._offset > this._failure) {
                                                                        this._failure = this._offset;
                                                                        this._expected = [];
                                                                      }

                                                                      if (this._offset === this._failure) {
                                                                        this._expected.push('"&&"');
                                                                      }
                                                                    }

                                                                    if (address2 === FAILURE) {
                                                                      this._offset = index2;
                                                                    }
                                                                  }
                                                                }
                                                              }
                                                            }
                                                          }
                                                        }
                                                      }
                                                    }
                                                  }
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }

        if (address2 !== FAILURE) {
          elements0[1] = address2;
          var address3 = FAILURE;
          address3 = this._read___();

          if (address3 !== FAILURE) {
            elements0[2] = address3;
          } else {
            elements0 = null;
            this._offset = index1;
          }
        } else {
          elements0 = null;
          this._offset = index1;
        }
      } else {
        elements0 = null;
        this._offset = index1;
      }

      if (elements0 === null) {
        address0 = FAILURE;
      } else {
        address0 = this._actions.make_opt(this._input, index1, this._offset, elements0);
        this._offset = this._offset;
      }

      this._cache._opt_[index0] = [address0, this._offset];
      return address0;
    },
    _read___: function () {
      var address0 = FAILURE,
          index0 = this._offset;
      this._cache.___ = this._cache.___ || {};
      var cached = this._cache.___[index0];

      if (cached) {
        this._offset = cached[1];
        return cached[0];
      }

      var remaining0 = 0,
          index1 = this._offset,
          elements0 = [],
          address1 = true;

      while (address1 !== FAILURE) {
        var chunk0 = null;

        if (this._offset < this._inputSize) {
          chunk0 = this._input.substring(this._offset, this._offset + 1);
        }

        if (chunk0 !== null && /^[\s]/.test(chunk0)) {
          address1 = new TreeNode(this._input.substring(this._offset, this._offset + 1), this._offset);
          this._offset = this._offset + 1;
        } else {
          address1 = FAILURE;

          if (this._offset > this._failure) {
            this._failure = this._offset;
            this._expected = [];
          }

          if (this._offset === this._failure) {
            this._expected.push('[\\s]');
          }
        }

        if (address1 !== FAILURE) {
          elements0.push(address1);
          --remaining0;
        }
      }

      if (remaining0 <= 0) {
        address0 = new TreeNode(this._input.substring(index1, this._offset), index1, elements0);
        this._offset = this._offset;
      } else {
        address0 = FAILURE;
      }

      this._cache.___[index0] = [address0, this._offset];
      return address0;
    }
  };

  var Parser = function (input, actions, types) {
    this._input = input;
    this._inputSize = input.length;
    this._actions = actions;
    this._types = types;
    this._offset = 0;
    this._cache = {};
    this._failure = 0;
    this._expected = [];
  };

  Parser.prototype.parse = function () {
    var tree = this._read_comp_expression();

    if (tree !== FAILURE && this._offset === this._inputSize) {
      return tree;
    }

    if (this._expected.length === 0) {
      this._failure = this._offset;

      this._expected.push('<EOF>');
    }

    this.constructor.lastError = {
      offset: this._offset,
      expected: this._expected
    };
    throw new SyntaxError(formatError(this._input, this._failure, this._expected));
  };

  var parse = function (input, options) {
    options = options || {};
    var parser = new Parser(input, options.actions, options.types);
    return parser.parse();
  };

  extend(Parser.prototype, Grammar);
  var exported = {
    Grammar: Grammar,
    Parser: Parser,
    parse: parse
  };

  if (typeof require === 'function' && typeof exports === 'object') {
    extend(exports, exported);
  } else {
    var namespace = typeof this !== 'undefined' ? this : window;
    namespace.Maps = exported;
  }
})();
//# sourceMappingURL=ArithmeticPathInternal.js.map