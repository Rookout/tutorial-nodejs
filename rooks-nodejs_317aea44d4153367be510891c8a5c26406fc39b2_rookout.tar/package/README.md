# Node Rookout

[Rookout](https://rookout.github.io/tutorials/node/) is a Node.js package that supports
on the fly debugging and data extraction from Node.js applications
in production.

Installation:

```javascript
require('rookout/auto_start')
```