'use strict';

exports.rookout = require('./index');

exports.start = (options = {}) => {
  options.log_file = "";
  exports.rookout.start(options);
};

exports.wrap = originalFunction => {
  return args => {
    const result = originalFunction(args);

    if (undefined !== result.then) {
      return new Promise((resolve, reject) => {
        result.then(value => {
          exports.rookout.flush();
          resolve(value);
        });

        if (undefined !== result.catch) {
          result.catch(err => {
            exports.rookout.flush();
            reject(err);
          });
        }
      });
    } else {
      exports.rookout.flush();
      return result;
    }
  };
};
//# sourceMappingURL=openwhisk.js.map