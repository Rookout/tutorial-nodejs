"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _Namespace = _interopRequireDefault(require("./Namespace"));

var _JSObjectNamespace = _interopRequireDefault(require("./JSObjectNamespace"));

var _exceptions = require("../../exceptions");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

class ContainerNamespace extends _Namespace.default {
  constructor(dict = null) {
    super();

    if (dict === null) {
      this.namespaces = {};
    } else {
      this.namespaces = dict;
    }
  }

  callMethod(name, args) {
    switch (name) {
      case "size":
        return new _JSObjectNamespace.default(Object.keys(this.namespaces).length);

      default:
        return super.callMethod(name, args);
    }
  }

  readAttribute(name) {
    if (this.namespaces[name] === undefined) {
      throw new _exceptions.RookAttributeNotFound(name);
    }

    return this.namespaces[name];
  }

  writeAttribute(name, value) {
    this.namespaces[name] = value;
  }

}

exports.default = ContainerNamespace;
//# sourceMappingURL=ContainerNamespace.js.map