"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _Aug = _interopRequireDefault(require("./Aug"));

var _ActionRunProcessor = _interopRequireDefault(require("./actions/ActionRunProcessor"));

var _LocationFileLine = _interopRequireDefault(require("./locations/LocationFileLine"));

var _ProcessorFactory = _interopRequireDefault(require("../processor/ProcessorFactory"));

var _Condition = _interopRequireDefault(require("./conditions/Condition"));

var _exceptions = require("../exceptions");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const config = require('../config');

class AugFactory {
  constructor(output) {
    this.output = output;
    this.processorFactory = new _ProcessorFactory.default();
  }

  getAug(configuration) {
    const augId = configuration["id"];

    if (!(typeof augId === 'string' || augId instanceof String)) {
      throw new _exceptions.RookAugInvalidKey('id', configuration);
    }

    const jsonLocation = configuration["location"];

    if (null == jsonLocation) {
      throw new _exceptions.RookAugInvalidKey('location', configuration);
    }

    const location = this.getLocation(jsonLocation);
    const jsonAction = configuration["action"];

    if (null == jsonAction) {
      throw new _exceptions.RookAugInvalidKey('action', configuration);
    }

    const action = new _ActionRunProcessor.default(jsonAction, this.processorFactory);
    let condition;
    const conditionConfiguration = configuration['conditional'];

    if (null != conditionConfiguration) {
      condition = new _Condition.default(conditionConfiguration);
    }

    const maxAugTime = configuration.maxAugTime === 0 ? 0 : configuration.maxAugTime || config.InstrumentationConfig.MAX_AUG_TIME;
    let limitsSpec = configuration['rateLimit'];
    let limits = [];

    if (limitsSpec !== undefined && limitsSpec.includes('/')) {
      let limitMatches = limitsSpec.match(/^(\d+)\/(\d+)$/);

      if (limitMatches !== null) {
        limits = [limitMatches[1], limitMatches[2]];
      }
    }

    if (limits.length === 0) {
      limits.push(500, 5000);
    }

    return new _Aug.default(augId, location, action, condition, this.output, maxAugTime, limits);
  }

  getLocation(jsonLocation) {
    // FUTURE - add support for log_handler location
    switch (jsonLocation.name) {
      case "file_line":
        return new _LocationFileLine.default(jsonLocation, this.processorFactory);

      default:
        throw new _exceptions.RookUnsupportedLocation(jsonLocation.name);
    }
  }

}

exports.default = AugFactory;
//# sourceMappingURL=AugFactory.js.map