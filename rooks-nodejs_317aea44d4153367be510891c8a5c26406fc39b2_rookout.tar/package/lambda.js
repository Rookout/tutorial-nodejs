'use strict';

class RookoutLambdaWrapper {
  constructor(rookout, originalThis, originalFunction, originalEvent, originalContext, originalCallback) {
    this.rookout = rookout;
    this.rookout.notifyLambdaActive(originalContext);
    this.originalThis = originalThis;
    this.originalFunction = originalFunction;
    this.originalEvent = originalEvent;
    this.originalContext = originalContext;
    this.originalCallback = originalCallback;
    this.callbackCalled = false;
    this.originalFunctionReturnedPromise = false; // The constructor is called _after_ `rookout.start`, but imported _before_ `rookout.start` --
    // importing the logger in this file means it'll be initialized too early.

    this.logger = require("./logger").logger;
    this.context = Object.assign({}, this.originalContext, {
      done: (error, result) => {
        this.flush(() => {
          this.originalContext.done(error, result);
        });
      },
      fail: error => {
        this.flush(() => {
          this.originalContext.fail(error);
        });
      },
      succeed: result => {
        this.flush(() => {
          this.originalContext.succeed(result);
        });
      }
    });
  }

  callback(err, result) {
    this.boundCallback = this.originalCallback.bind(this.originalThis, err, result);
    this.callbackCalled = true;
    this.flush(() => {
      if (!this.originalFunctionReturnedPromise) {
        this.boundCallback();
      }

      this.rookout.notifyLambdaInactive(this.context);
    });
  }

  invoke() {
    let result = this.originalFunction.call(this.originalThis, this.originalEvent, this.context, this.callback.bind(this));
    const self = this;

    if (result !== undefined && result.then !== undefined) {
      this.originalFunctionReturnedPromise = true;
      return new Promise((resolve, reject) => {
        result.then(value => {
          self.flush(() => {
            // The user might have returned a Promise/used an async function *and* called the callback.
            if (this.callbackCalled) {
              self.logger.debug("Calling AWS callback from invoke promise resolve handler");
              this.boundCallback();
            }

            self.logger.debug("Resolving with result: %s", value);
            this.rookout.notifyLambdaInactive(this.context);
            resolve(value);
          });
        }).catch(err => {
          self.flush(() => {
            // The user might have returned a Promise/used an async function *and* called the callback.
            if (this.callbackCalled) {
              self.logger.debug("Calling AWS callback from invoke promise reject handler");
              this.boundCallback();
            }

            this.rookout.notifyLambdaInactive(this.context);
            reject(err);
          });
        });
      });
    } else {
      this.flush();
      return result;
    }
  }

  flush(callback) {
    if (this.rookout) {
      let flushPromise = new Promise(resolve => {
        this.rookout.flush(() => resolve());
      }).catch(() => {});
      Promise.race([flushPromise, this.timeoutResolver(5000)]).then(() => {
        if (callback) {
          callback();
        }
      }).catch(() => {});
    }
  }

  timeoutResolver(timeout) {
    return new Promise(resolve => {
      setTimeout(() => {
        resolve();
      }, timeout).unref();
    });
  }

}

let invokeAndChain = (wrapper, resolve, reject) => {
  try {
    let invoke_result = wrapper.invoke();

    if (invoke_result !== undefined && invoke_result.then !== undefined) {
      invoke_result.then(value => resolve(value)).catch(err => {
        reject(err);
      });
    } else {// intentionally empty - we must not resolve the promise so that the lambda only ends after timeout
      // or when the callback is called
    }
  } catch (err) {
    reject(err);
  }
};

exports.wrap = (originalFunction, options = {}) => {
  if (!process.env.LAMBDA_TASK_ROOT) {
    return originalFunction;
  }

  const rook = require('.'); // An already-resolved Promise


  let startRook = Promise.resolve();

  if (!rook.startAttempted) {
    options.log_file = options.log_file || "";
    options.lambda_safe_start = true;
    startRook = rook.start(options);
  }

  return (event, context, callback) => {
    let wrapper = new RookoutLambdaWrapper(rook, void 0, originalFunction, event, context, callback);
    return new Promise((resolve, reject) => {
      startRook.then(() => invokeAndChain(wrapper, resolve, reject)).catch(() => invokeAndChain(wrapper, resolve, reject));
    });
  };
};
//# sourceMappingURL=lambda.js.map