"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _NamespaceSerializer = _interopRequireDefault(require("../processor/NamespaceSerializer"));

var _logger = require("../logger");

var _TokenBucket = _interopRequireDefault(require("./TokenBucket"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const config = require("../config");

const messages_pb = require("../protobuf/messages_pb");

const variant_pb = require("../protobuf/variant_pb");

const timestamp_pb = require("google-protobuf/google/protobuf/timestamp_pb"); // Maps logger.js:LOG_LEVELS to the LogMessage enum


const LOG_LEVELS = {
  0: messages_pb.LogMessage.LogLevel.DEBUG,
  1: messages_pb.LogMessage.LogLevel.INFO,
  2: messages_pb.LogMessage.LogLevel.WARNING,
  3: messages_pb.LogMessage.LogLevel.ERROR,
  4: messages_pb.LogMessage.LogLevel.FATAL
};

class OutputWs {
  constructor(id) {
    this.id = id;
    this._agentCom = null;
    this._ruleStatusUpdatesBucket = new _TokenBucket.default(config.OutputWsConfiguration.MAX_STATUS_UPDATES, config.OutputWsConfiguration.BUCKET_REFRESH_RATE, () => _logger.logger.error("Limit reached, dropping status updates"));
    this._userMessageBucket = new _TokenBucket.default(config.OutputWsConfiguration.MAX_AUG_MESSAGES, config.OutputWsConfiguration.BUCKET_REFRESH_RATE, () => _logger.logger.error("Limit reached, dropping aug report messages"));
    this._logMessageBucket = new _TokenBucket.default(config.OutputWsConfiguration.MAX_LOG_ITEMS, config.OutputWsConfiguration.BUCKET_REFRESH_RATE, () => this._internalSendLogMessage(3, __filename, 0, "Limit reached, dropping log messages", "Limit reached, dropping log messages"));

    _logger.logger.registerOutput(this);
  }

  setAgentCom(agentCom) {
    this._agentCom = agentCom;
  }

  flushMessages(callback) {
    let msgsFlushedPromise = this._agentCom.flushMessages();

    msgsFlushedPromise.then(callback).catch(callback);
  }

  sendRuleStatus(ruleId, active, error) {
    if (!this._agentCom) {
      return;
    }

    this._ruleStatusUpdatesBucket.doIfAvailable(() => {
      let ruleStatusMessage = new messages_pb.RuleStatusMessage();
      ruleStatusMessage.setAgentId(this.id);
      ruleStatusMessage.setRuleId(ruleId);
      ruleStatusMessage.setActive(active);

      if (error) {
        ruleStatusMessage.setError(OutputWs._convertError(error.dumps()));
      }

      this._agentCom.add(ruleStatusMessage);
    });
  }

  static _convertError(error) {
    let new_err = new variant_pb.Error();
    new_err.setMessage(error.getMessage());
    new_err.setType(error.getType());
    new_err.setParameters(error.getParameters());
    new_err.setExc(error.getExc());
    new_err.setTraceback(error.getTraceback());
    return new_err;
  }

  sendUserMessage(augId, messageId, args) {
    if (!this._agentCom) {
      return;
    }

    this._userMessageBucket.doIfAvailable(() => {
      let msg = new messages_pb.AugReportMessage();
      msg.setAgentId(this.id);
      msg.setAugId(augId);
      msg.setReportId(messageId);

      if (args) {
        msg.setArguments(new _NamespaceSerializer.default().dumps(args));
      }

      this._agentCom.add(msg);
    });
  }

  sendLogMessage(level, time, filename, lineno, text, formattedMessage, args) {
    if (!this._agentCom) {
      return;
    }

    this._logMessageBucket.doIfAvailable(() => this._internalSendLogMessage(level, filename, lineno, text, formattedMessage, args));
  }

  _internalSendLogMessage(level, filename, lineno, text, formattedMessage, args) {
    if (!this._agentCom) {
      return;
    }

    let msg = new messages_pb.LogMessage();
    let date = new timestamp_pb.Timestamp();
    date.fromDate(new Date());
    msg.setTimestamp(date);
    let logLevel = LOG_LEVELS[level];

    if (logLevel === undefined) {
      logLevel = messages_pb.LogMessage.LogLevel.WARNING;
    }

    msg.setAgentId(this.id);
    msg.setLevel(logLevel);
    msg.setFilename(filename);
    msg.setLine(lineno);
    msg.setText(text);
    msg.setFormattedMessage(formattedMessage);

    if (args) {
      msg.setLegacyArguments(new _NamespaceSerializer.default().dumps(args));
    }

    this._agentCom.add(msg);
  }

  sendWarning(ruleId, error) {
    this.sendRuleStatus(ruleId, "Warning", error);
  }

}

exports.default = OutputWs;
//# sourceMappingURL=OutputWs.js.map