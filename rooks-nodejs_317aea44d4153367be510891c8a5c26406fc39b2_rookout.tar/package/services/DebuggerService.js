"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.DebuggerService = void 0;

var _RookError = _interopRequireDefault(require("../processor/RookError"));

var _utils = require("../utils");

var _ScriptWrapper = _interopRequireDefault(require("./ScriptWrapper"));

var _exceptions = require("../exceptions");

var _logger = require("../logger");

var _sourceMapUtil = require("./source-map-util");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const assert = require('assert');

const path = require('path');

const config = require('../config');

const fs = require('fs');

const CryptoJS = require('crypto-js');

const SHA256 = require('crypto-js/sha256');

// Note: this is a bit of a heck that is used by V8Debug as well
class Pos {
  constructor(filename, lineno, column) {
    this.filename = filename;
    this.lineno = lineno;
    this.column = column;
  }

  toKey() {
    return this.filename + "@" + this.lineno + "@" + this.column;
  }

}

class ScriptNotifier {
  constructor() {
    this.debug = null;
    this.pendingNotifications = {};
    this.scripts = {};
  }

  setDebug(debug) {
    this.debug = debug;
    this.loadScripts();
  }

  getAllMatchInfoByFilename(fileName, includeExternals = false) {
    fileName = (0, _utils.canonizeFileName)(fileName);
    let matchesInfos = [];

    for (let scriptId of Object.keys(this.scripts)) {
      const script = this.scripts[scriptId];
      const matchInfo = script.getMatchInfo(fileName, includeExternals);

      if (null !== matchInfo) {
        matchesInfos.push(matchInfo);
      }
    }

    return matchesInfos;
  }

  getScriptObjectById(scriptId) {
    if (this.scripts.hasOwnProperty(scriptId)) {
      return this.scripts[scriptId];
    } else {
      return null;
    }
  }

  getFileContentFromMap(script) {
    try {
      let fileContent = null;

      if (script.sourceFiles === null || script.sourceFiles === undefined) {
        return null;
      }

      for (let sourceFile of script.sourceFiles) {
        fileContent = sourceFile.rawSource;
        break;
      }

      if (fileContent === null || fileContent === undefined) {
        return null;
      }

      return fileContent;
    } catch (e) {
      return null;
    }
  }

  registerNotification(aug, fileName, fileHash, includeExternals, callback, removed) {
    fileName = (0, _utils.canonizeFileName)(fileName);
    this.pendingNotifications[aug.augId] = {
      aug: aug,
      fileName: fileName,
      includeExternals: includeExternals,
      execute: callback,
      removed: removed,
      fileHash: fileHash
    };
    const matchInfos = this.getAllMatchInfoByFilename(fileName, includeExternals);

    for (let matchInfo of matchInfos) {
      callback(matchInfo);
    }

    if (matchInfos.length === 0) {
      let filename = path.basename(fileName);

      for (let scriptId of Object.keys(this.scripts)) {
        const script = this.scripts[scriptId];
        let originalFilename = "";

        for (let sourceFile of script.sourceFiles) {
          // Replacing all ../ and ./ since the BE needs absolute path to the suggestion
          originalFilename = sourceFile.normalizedPath.split("../").join("").split("./").join("").split("..\\").join("").split(".\\").join("");
          break;
        }

        let isJsFile = script.filename.endsWith('js') && (originalFilename === "" || originalFilename.endsWith('js'));

        if (path.basename(script.filename) === filename || path.basename(originalFilename) === filename) {
          let fileContent;
          let suggestedFileName = originalFilename;

          try {
            // Try and fetch the content from the map file.
            fileContent = this.getFileContentFromMap(script);

            if (fileContent === null) {
              if (isJsFile) {
                // If its a js file - try to read from disk
                fileContent = fs.readFileSync(script.filename, 'utf8');
                suggestedFileName = script.filename;
              } else {
                continue;
              }
            }
          } catch (e) {
            continue;
          }

          fileContent = fileContent.replace(/(?:\r\n|\r|\n)/g, "\n");
          const currentFileHash = SHA256(fileContent).toString(CryptoJS.enc.Hex);

          if (fileHash === currentFileHash) {
            aug.sendWarning(new _RookError.default(new _exceptions.RookSourceFilePathSuggestion(fileName, suggestedFileName)));
            break;
          }
        }
      }
    }
  }

  loadScripts() {
    for (let script of this.debug.scripts()) {
      this.addScript(script.scriptId, script.filename, script.source);
    }
  }

  addScript(scriptId, filename, source) {
    if (null == filename || this.scripts.hasOwnProperty(scriptId)) {
      return;
    }

    const scriptWrapper = new _ScriptWrapper.default(scriptId, filename, source);

    for (let augId of Object.keys(this.pendingNotifications)) {
      let notification = this.pendingNotifications[augId];
      const matchInfo = scriptWrapper.getMatchInfo(notification.fileName, notification.includeExternals);

      if (null !== matchInfo) {
        notification.execute(matchInfo);
      } else {
        if (path.basename(filename) === path.basename(notification.fileName)) {
          let fileContent = source.replace(/(?:\r\n|\r|\n)/g, "\n");
          const currentFileHash = SHA256(fileContent).toString(CryptoJS.enc.Hex);

          if (notification.fileHash === currentFileHash) {
            notification.aug.sendWarning(new _RookError.default(new _exceptions.RookSourceFilePathSuggestion(notification.fileName, filename)));
          }
        }
      }
    }

    this.scripts[scriptId] = scriptWrapper;
  }

  removeAug(augId) {
    let notification = this.pendingNotifications[augId];

    if (undefined !== notification) {
      notification.removed();
      delete this.pendingNotifications[augId];
    }
  }

  clearAugs() {
    let augIds = Object.keys(this.pendingNotifications);

    for (let augId of augIds) {
      this.removeAug(augId);
    }

    this.pendingNotifications = {};
  }

}

class AugHolder {
  constructor(debug) {
    this.debug = debug;
    this.breakpoints = {};
    this.positions = {};
  }

  executeAugs(pos, frame, stack) {
    let augs = this.breakpoints[pos.toKey()];

    if (null == augs) {
      _logger.logger.error("Aug not found! %s@%d", pos.filename, pos.lineno);
    } else {
      for (let aug of augs) {
        aug.execute(frame, stack, {});
      }
    }
  }

  addAug(filename, lineno, column, aug) {
    _logger.logger.info("Setting breakpoint at %s:%s:%s", filename, lineno, column);

    let pos = new Pos((0, _utils.canonizeFileName)(filename), lineno, column);

    if (this.breakpoints.hasOwnProperty(pos.toKey())) {
      this.breakpoints[pos.toKey()].push(aug);
    } else {
      this.debug.setBreak(pos, aug);
      this.breakpoints[pos.toKey()] = [aug];
    }

    this.positions[aug.augId] = pos;
    aug.setActive();
  }

  removeAug(augId) {
    if (!this.positions.hasOwnProperty(augId)) {
      return;
    } // Get current augs in position


    let pos = this.positions[augId];
    let currentAugs = this.breakpoints[pos.toKey()]; // Divide augs into delete and keep

    let augsToKeep = [];
    let augsToDelete = [];

    for (let aug of currentAugs) {
      if (aug.augId === augId) {
        augsToDelete.push(aug);
      } else {
        augsToKeep.push(aug);
      }
    } // Update list


    if (augsToKeep.length > 0) {
      this.breakpoints[pos.toKey()] = augsToKeep;
    } else {
      this.debug.clearBreak(pos);
      delete this.breakpoints[pos.toKey()];
    } // Update status


    for (let aug of augsToDelete) {
      aug.setRemoved();
    } // Remove from position list


    delete this.positions[augId];
  }

  async clearAugs() {
    let augIds = Object.keys(this.positions);

    for (let augId of augIds) {
      this.removeAug(augId);
    }

    this.breakpoints = {};
    this.positions = {};
    await this.debug.clearAllBreaks();
  }

}

class DebuggerService {
  constructor() {
    this.debug = null;
    this.augHolder = null;
    this.scriptNotifier = null;
  }

  async close() {
    this.clearAugs();

    if (null !== this.debug) {
      const debug = this.debug;
      this.debug = null;
      await debug.close();
    }
  }

  addAug(filename, matchInfo, lineno, column, aug) {
    this.start(); // Note- this is a hack used to simplify testing, script should never be null in production

    if (null === matchInfo) {
      matchInfo = this.scriptNotifier.getAllMatchInfoByFilename(filename)[0];
      assert.notEqual(matchInfo, undefined, "Script not found");
    }

    if (matchInfo.inSourceMap) {
      // Normalizing the filename using the source-map normalize function to avoid filename mismatch
      const pos = matchInfo.script.getGeneratedPosition((0, _sourceMapUtil.normalize)(matchInfo.filename), lineno, column);
      lineno = pos.line;
      column = pos.column;
    }

    this.augHolder.addAug(matchInfo.script.filename, lineno, column, aug);
  }

  registerNotification(augId, fileName, fileHash, includeExternals, callback, removed) {
    this.start();
    this.scriptNotifier.registerNotification(augId, fileName, fileHash, includeExternals, callback, removed);
  }

  removeAug(augId) {
    if (null !== this.augHolder) {
      this.augHolder.removeAug(augId);
    }

    if (null !== this.scriptNotifier) {
      this.scriptNotifier.removeAug(augId);
    }
  }

  async clearAugs() {
    if (null !== this.augHolder) {
      await this.augHolder.clearAugs();
    }

    if (null !== this.scriptNotifier) {
      this.scriptNotifier.clearAugs();
    }
  }

  start() {
    if (null === this.debug) {
      const self = this;
      this.scriptNotifier = new ScriptNotifier();
      this.debug = this.getDebugger();
      this.augHolder = new AugHolder(this.debug);
      this.scriptNotifier.setDebug(this.debug);
    }
  }

  getDebugger() {
    const self = this;

    function user_line(pos, frame, stack) {
      self.augHolder.executeAugs(pos, frame, stack);
    }

    function scriptLoaded(scriptId, filename, source) {
      self.scriptNotifier.addScript(scriptId, filename, source);
    }

    function getScript(scriptId) {
      return self.scriptNotifier.getScriptObjectById(scriptId);
    }

    const engine = DebuggerService.selectEngine();

    switch (engine) {
      case "inspector":
        const InspectorDebug = require('./InspectorDebug');

        return new InspectorDebug.InspectorDebug(user_line, scriptLoaded, getScript);

      default:
        throw new _exceptions.RookUnsupportedEngineSelection(engine);
    }
  }

  static selectEngine() {
    let engine = config.InstrumentationConfig.ENGINE;

    if (!engine || engine === "auto") {
      const versions = process.version.split('.');
      const major = parseInt(versions[0].substr(1));

      if (major < 8) {
        throw new _exceptions.RookUnsupportedNodeVersion(process.version);
      }

      return "inspector";
    } else {
      return engine;
    }
  }

}

exports.DebuggerService = DebuggerService;
//# sourceMappingURL=DebuggerService.js.map