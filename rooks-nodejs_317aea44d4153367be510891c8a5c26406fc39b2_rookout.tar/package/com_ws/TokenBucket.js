"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

class TokenBucket {
  constructor(limit, intervalSeconds, doOnceWhenExhausted) {
    this._remaining = limit;
    this._initialValue = limit;
    this._lastReset = Date.now();
    this._intervalSeconds = intervalSeconds;
    this._doOnceWhenExhausted = doOnceWhenExhausted;
    this._doOnceWhenExhaustedPerformed = false;
  }

  _isExhausted() {
    if (Date.now() - this._lastReset >= this._intervalSeconds * 1000) {
      this._lastReset = Date.now();
      this._remaining = this._initialValue;
      this._doOnceWhenExhaustedPerformed = false;
    }

    return this._remaining < 0;
  }

  doIfAvailable(func) {
    this._remaining -= 1;

    if (this._isExhausted()) {
      if (this._doOnceWhenExhausted && this._doOnceWhenExhaustedPerformed === false) {
        this._doOnceWhenExhaustedPerformed = true;

        this._doOnceWhenExhausted();
      }

      return;
    }

    func();
  }

}

exports.default = TokenBucket;
//# sourceMappingURL=TokenBucket.js.map