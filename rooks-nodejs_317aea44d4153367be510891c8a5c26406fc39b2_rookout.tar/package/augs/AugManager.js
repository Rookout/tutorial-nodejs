"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _AugFactory = _interopRequireDefault(require("./AugFactory"));

var _RookError = _interopRequireDefault(require("../processor/RookError"));

var _logger = require("../logger");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

class AugManager {
  constructor(triggerServices, output) {
    this.triggerServices = triggerServices;
    this.output = output;
    this.factory = new _AugFactory.default(this.output);
    this.augIds = new Set();
  }

  initializeAugs(augs) {
    let leftovers = new Set(this.augIds);

    for (let aug of augs) {
      let augId = aug.id;

      if (augId === undefined) {
        continue;
      }

      if (leftovers.has(augId)) {
        leftovers.delete(augId);
        continue;
      }

      this.addAug(aug);
    }

    for (let leftoverId of leftovers) {
      this.removeAug(leftoverId);
    }
  }

  addAug(config) {
    let aug = null;

    try {
      aug = this.factory.getAug(config);
    } catch (e) {
      const message = "Failed to parse aug";

      _logger.logger.exception(message, e);

      let augId = null;

      try {
        augId = config['id'];
      } catch (e2) {
        return;
      }

      this.output.sendRuleStatus(augId, "Error", new _RookError.default(e, message));
      return;
    }

    if (this.augIds.has(aug.augId)) {
      _logger.logger.debug('Aug already set - %s', aug.augId);

      return;
    }

    _logger.logger.debug("Adding aug-\t%s", aug.augId);

    aug.addAug(this.triggerServices);
    this.augIds.add(aug.augId);
  }

  removeAug(augId) {
    _logger.logger.debug("Removing aug-\t%s", augId);

    this.triggerServices.removeAug(augId);
    this.augIds.delete(augId);
  }

  clearAugs() {
    _logger.logger.debug("Clearing all augs");

    for (let augId of Array.from(this.augIds)) {
      this.removeAug(augId);
    }

    this.triggerServices.clearAugs();
  }

}

exports.default = AugManager;
//# sourceMappingURL=AugManager.js.map