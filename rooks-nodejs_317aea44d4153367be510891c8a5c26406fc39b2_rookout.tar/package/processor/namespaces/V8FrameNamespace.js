"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _Namespace = _interopRequireDefault(require("./Namespace"));

var _JSObjectNamespace = _interopRequireDefault(require("./JSObjectNamespace"));

var _exceptions = require("../../exceptions");

var _ContainerNamespace = _interopRequireDefault(require("./ContainerNamespace"));

var _logger = require("../../logger");

var _V8StackNamespace = require("./V8StackNamespace");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

class V8FrameNamespace extends _Namespace.default {
  constructor(debug, frame) {
    super();
    this.debug = debug;
    this.frame = frame;
    this.position = null;
  }

  readAttribute(name) {
    for (let i = 0; i < this.frame.scopeCount(); ++i) {
      const valueObject = this.frame.scope(i).scopeObject().value();

      if (valueObject.hasOwnProperty(name)) {
        return new _JSObjectNamespace.default(valueObject[name]);
      }
    }

    throw new _exceptions.RookAttributeNotFound(name);
  }

  callMethod(name, args) {
    switch (name) {
      case "filename":
      case "module":
        return this.filename();

      case "line":
        return this.line();

      case "function":
      case "method":
        return this.function();

      case "locals":
        return this.locals(args);

      case "dump":
        return this.dump(args);

      default:
        return super.callMethod(name, args);
    }
  }

  filename() {
    return new _JSObjectNamespace.default(this.getPosition().filename);
  }

  module() {
    return this.filename();
  }

  line() {
    return new _JSObjectNamespace.default(this.getPosition().line);
  }

  function() {
    return new _JSObjectNamespace.default(this.getPosition().function);
  }

  locals(args) {
    let result = {};
    let depth = null;

    if (null != args && '' !== args) {
      depth = parseInt(args);
    } // We iterate from the top down to get all scopes in the correct order, skipping the top scope (Global/Injected)


    for (let i = this.frame.scopeCount() - 2; i >= 0; --i) {
      let scope = this.frame.scope(i).scopeObject().value(); // Skip global scope

      if (undefined !== scope['__filename']) {
        continue;
      }

      for (let name of Object.keys(scope)) {
        result[name] = new _JSObjectNamespace.default(scope[name]);

        if (null != depth) {
          result[name].dumpConfig.maxDepth = depth;
        }
      }
    }

    return new _ContainerNamespace.default(result);
  }

  dump(args) {
    return new _ContainerNamespace.default({
      locals: this.locals(args),
      module: this.module(),
      filename: this.filename(),
      line: this.line(),
      function: this.function()
    });
  }

  getPosition() {
    if (null !== this.position) {
      return this.position;
    }

    const sourceLocation = this.frame.sourceLocation();
    this.rawPosition = {
      filename: sourceLocation.script.name,
      line: sourceLocation.line + 1,
      column: sourceLocation.column,
      function: this.frame.func().name()
    };
    const script = this.debug.getScript(sourceLocation.script.id);

    if (null !== script && null !== script.mapConsumer) {
      const originalPosition = script.getOriginalPosition(this.rawPosition.line, this.rawPosition.column);

      if (null != originalPosition) {
        this.position = {
          filename: originalPosition.source,
          line: originalPosition.line,
          column: originalPosition.column,
          function: this.rawPosition.function
        };
      }
    } // If we have been unable to get original position, just use raw position


    if (null == this.position) {
      this.position = this.rawPosition;
    }

    return this.position;
  }

}

exports.default = V8FrameNamespace;
//# sourceMappingURL=V8FrameNamespace.js.map