"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

const exceptions = require('../../exceptions');

class Namespace {
  constructor(methods) {}

  callMethod(name, args) {
    throw new exceptions.RookMethodNotFound(typeof this, name);
  }

  readAttribute(name) {
    throw new exceptions.RookAttributeNotFound(name);
  }

  writeAttribute(name, value) {
    throw new exceptions.RookWriteAttributeNotSupported(typeof this, name);
  }

  readKey(key) {
    throw new exceptions.RookKeyNotFound(key);
  }

}

exports.default = Namespace;
//# sourceMappingURL=Namespace.js.map