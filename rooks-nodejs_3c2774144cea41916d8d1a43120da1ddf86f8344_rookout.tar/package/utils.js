"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getEnv = getEnv;
exports.canonizeFileName = canonizeFileName;
exports.emptyCallack = emptyCallack;
exports.getProcessTimeInMillisWithDecimal = getProcessTimeInMillisWithDecimal;
exports.StringUtils = void 0;

const path = require('path');

const process = require('process');

class StringUtils {
  static trim(string) {
    return string.replace(/^\s+|\s+$/g, '');
  }

  /***
   * Strip a string on both ends from specific chars
   * @param string
   * @param chars
   */
  static strip(string, chars) {
    const charsArray = [];

    for (let char of chars) {
      switch (char) {
        case "}":
        case "{":
        case "]":
        case "[":
          charsArray.push("\\" + char);
          break;

        default:
          charsArray.push(char);
      }
    }

    const re = RegExp(`^[${charsArray.join("")}]+|[${charsArray.join("")}]+$`, "g");
    return string.replace(re, '');
  }

}

exports.StringUtils = StringUtils;

function getEnv(envName, defaultValue) {
  return process.env[envName] || defaultValue;
}

function canonizeFileName(filename) {
  return path.normalize(filename.replace(/[\\\/]/g, '/'));
}

function emptyCallack() {}

function getProcessTimeInMillisWithDecimal() {
  // process.hrtime() gives a tuple (seconds, nanoseconds) -> we convert to milliseconds with decimal
  const hrTime = process.hrtime();
  return hrTime[0] * 1000 + hrTime[1] / 1e6;
}
//# sourceMappingURL=utils.js.map