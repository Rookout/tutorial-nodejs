"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _Namespace = _interopRequireDefault(require("./Namespace"));

var _JSObjectNamespace = _interopRequireDefault(require("./JSObjectNamespace"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

class NoopNamespace extends _Namespace.default {
  constructor() {
    super();
  }

  callMethod(name, args) {
    return new _JSObjectNamespace.default(null);
  }

  readAttribute(name) {
    return new _JSObjectNamespace.default(null);
  }

  readKey(key) {
    return new _JSObjectNamespace.default(null);
  }

}

exports.default = NoopNamespace;
//# sourceMappingURL=NoopNamespace.js.map