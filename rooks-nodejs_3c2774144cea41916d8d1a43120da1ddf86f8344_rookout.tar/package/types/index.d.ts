export class Rook {
    start(options?: rookoutOptions): Promise<Rook>;
    startSync(timeout?: number, options?: rookoutOptions): void;
    stop(): void;
    flush(cb?: () => void): void;
}

export declare interface rookoutOptions {
    token?: string,
    labels?: Map<string, string>,
    tags?: string[],
    host?: string,
    port?: string,
    debug?: boolean,
    throw_errors?: boolean,
    log_file?: string,
    log_level?: string,
    log_to_stderr?: boolean,
    git_commit?: string,
    git_origin?: string,
}

export declare function start(options?: rookoutOptions): Promise<Rook>;

export declare function startSync(timeout?: number, options?: rookoutOptions): void;

export declare function stop(): void;

export declare function flush(cb?: () => void): void;
