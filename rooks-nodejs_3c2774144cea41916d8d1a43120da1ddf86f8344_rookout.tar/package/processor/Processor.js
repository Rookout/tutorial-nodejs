'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _logger = require("../logger");

class Processor {
  constructor(configuration, processorFactory) {
    this.operations = [];

    for (let operation of configuration) {
      this.operations.push(processorFactory.getOperation(operation));
    }
  }

  process(namespace, userWarnings) {
    for (let operation of this.operations) {
      try {
        operation.execute(namespace, userWarnings);
      } catch (e) {
        _logger.logger.exception(e);
      }
    }
  }

}

exports.default = Processor;
//# sourceMappingURL=Processor.js.map