"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _RookError = _interopRequireDefault(require("../processor/RookError"));

var _exceptions = require("../exceptions");

var _logger = require("../logger");

var _UserWarnings = _interopRequireDefault(require("../UserWarnings"));

var _ContainerNamespace = _interopRequireDefault(require("../processor/namespaces/ContainerNamespace"));

var _JSUtilsNamespace = _interopRequireDefault(require("../processor/namespaces/JSUtilsNamespace"));

var _RateLimiter = _interopRequireDefault(require("./RateLimiter"));

var _DebuggerBackchannel = _interopRequireDefault(require("../services/DebuggerBackchannel"));

var _JSObjectNamespace = _interopRequireDefault(require("../processor/namespaces/JSObjectNamespace"));

var _NoopNamespace = _interopRequireDefault(require("../processor/namespaces/NoopNamespace"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const uuid4 = require("uuid/v4");

process.__rookout_backchannel = new _DebuggerBackchannel.default();
process.__rookout_backchannel.ContainerNamespace = _ContainerNamespace.default;
process.__rookout_backchannel.ObjectNamespace = _JSObjectNamespace.default;

class Aug {
  constructor(augId, location, action, condition, output, maxAugTime, limits) {
    this.augId = augId;
    this.location = location;
    this.action = action;
    this.output = output;
    this.status = null;
    this.maxAugTime = maxAugTime;
    this.enabled = true;
    this.condition = condition;
    this._warningCache = new Map();
    this._logCache = new Map();
    this._scopeSample = undefined;

    if (limits !== undefined && limits.length > 0) {
      this.rateLimiter = new _RateLimiter.default(limits[0], limits[1]);
    } else {
      this.rateLimiter = new _RateLimiter.default();
    }
  }

  addAug(triggerServices) {
    try {
      this.location.addAug(triggerServices, this);
    } catch (e) {
      const message = "Exception when adding aug";

      _logger.logger.exception(message, e);

      this.setError(new _RookError.default(e, message));
    }
  }

  execute(frame, stack) {
    if (!this.enabled) {
      return;
    }

    try {
      let startTime = Date.now();
      let namespace = new _ContainerNamespace.default({
        'frame': frame,
        'stack': stack,
        'store': new _ContainerNamespace.default({}),
        'temp': new _ContainerNamespace.default({}),
        'utils': new _JSUtilsNamespace.default({}),
        'trace': new _NoopNamespace.default()
      });

      if (this.condition !== undefined && this._scopeSample === undefined) {
        // this is the first time this aug is executed
        this._scopeSample = frame.populateScopes(); // The first time the aug is executed, the condition
        // is not evaluated in the Inspector, so we evaluate
        // it here instead.

        if (!this.condition.evaluate(namespace)) {
          return;
        }
      }

      const msgId = uuid4().replace(/\-/g, "");

      _logger.logger.info("Executing aug-\t%s (msg ID %s)", this.augId, msgId);

      this.action.execute(this.augId, msgId, namespace, this.output, new _UserWarnings.default(this));
      let duration = Date.now() - startTime;
      this.rateLimiter.record(startTime, duration);

      if (this.maxAugTime > 0 && duration > this.maxAugTime) {
        this.enabled = false;
        throw new _exceptions.RookRuleMaxExecutionTimeReached();
      }
    } catch (e) {
      const message = "Exception while processing Aug";
      let rookError = new _RookError.default(e, message);

      if (!this.shouldSilenceLog(rookError, this._logCache)) {
        _logger.logger.exception(message, e);
      }

      this.setError(rookError);
    }
  }

  setActive() {
    this.sendRuleStatus("Active");
  }

  setPending() {
    this.sendRuleStatus("Pending");
  }

  setRemoved() {
    this.sendRuleStatus("Deleted");
  }

  setError(error) {
    this.sendRuleStatus("Error", error);
  }

  setUnknown(error) {
    this.sendRuleStatus("Unknown", error);
  }

  sendWarning(error) {
    if (this.shouldSilenceLog(error, this._warningCache)) {
      return;
    }

    _logger.logger.warn(error.message);

    this.output.sendWarning(this.augId, error);
  }

  sendRuleStatus(status, error = null) {
    if (this.status === status) {
      return;
    }

    _logger.logger.info("Updating rule status for %s to %s", this.augId, status);

    this.status = status;
    this.output.sendRuleStatus(this.augId, status, error);
  }

  shouldSilenceLog(error, logCache) {
    if (logCache.has(error.message) || logCache.size >= 10) {
      return true;
    }

    logCache.set(error.message, true);
    return false;
  }

  checkRateLimit() {
    try {
      let rateLimitKey = this.rateLimiter.allow(Date.now());

      if (rateLimitKey === null) {
        this.sendWarning(new _RookError.default(new _exceptions.RookRuleRateLimited()));
        return false;
      } else {
        return true;
      }
    } catch (e) {
      return false;
    }
  }

}

exports.default = Aug;
//# sourceMappingURL=Aug.js.map