"use strict";

const Rook = require('./interface');

module.exports = new Rook();
//# sourceMappingURL=index.js.map