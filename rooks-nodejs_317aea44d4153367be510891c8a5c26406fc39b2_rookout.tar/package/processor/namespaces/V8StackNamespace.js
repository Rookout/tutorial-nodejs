"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.DEFAULT_FRAMES_LIMIT = exports.DEFAULT_TRACEBACK_LIMIT = void 0;

var _V8FrameNamespace = _interopRequireDefault(require("./V8FrameNamespace"));

var _ContainerNamespace = _interopRequireDefault(require("./ContainerNamespace"));

var _ListNamespace = _interopRequireDefault(require("./ListNamespace"));

var _Namespace = _interopRequireDefault(require("./Namespace"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const DEFAULT_TRACEBACK_LIMIT = 1000;
exports.DEFAULT_TRACEBACK_LIMIT = DEFAULT_TRACEBACK_LIMIT;
const DEFAULT_FRAMES_LIMIT = 100;
exports.DEFAULT_FRAMES_LIMIT = DEFAULT_FRAMES_LIMIT;

class V8StackNamespace extends _Namespace.default {
  constructor(debug, state) {
    super();
    this.debug = debug;
    this.state = state;
  }

  readKey(key) {
    return new _V8FrameNamespace.default(this.debug, this.state.frame(parseInt(key)));
  }

  callMethod(name, args) {
    switch (name) {
      case "traceback":
        return this.traceback(args);

      case "frames":
        return this.frames(args);

      default:
        return super.callMethod(name, args);
    }
  }

  traceback(args) {
    // Decide on dump depth
    let depth = DEFAULT_TRACEBACK_LIMIT;

    if (null != args && '' !== args) {
      depth = parseInt(args);
    }

    if (depth > this.state.frameCount()) {
      depth = this.state.frameCount();
    }

    let result = [];

    for (let i = 0; i < depth; ++i) {
      let frame = new _V8FrameNamespace.default(this.debug, this.state.frame(i));
      result.push(new _ContainerNamespace.default({
        module: frame.module(),
        filename: frame.filename(),
        line: frame.line(),
        function: frame.function()
      }));
    }

    return new _ListNamespace.default(result);
  }

  frames(args) {
    // Decide on dump depth
    let depth = DEFAULT_FRAMES_LIMIT;

    if (null != args && '' !== args) {
      depth = parseInt(args);
    }

    if (depth > this.state.frameCount()) {
      depth = this.state.frameCount();
    }

    let result = [];

    for (let i = 0; i < depth; ++i) {
      let frame = new _V8FrameNamespace.default(this.debug, this.state.frame(i));
      result.push(frame.callMethod('dump'));
    }

    return new _ListNamespace.default(result);
  }

}

exports.default = V8StackNamespace;
//# sourceMappingURL=V8StackNamespace.js.map