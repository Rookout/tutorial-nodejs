'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

class DebuggerBackchannel {
  constructor() {
    this._store = new Map();
    this._index = 0;
  }

  add() {
    this._index++;

    this._store.set(this._index, {});

    return this._index;
  }

  create(key) {
    if (this._store.get(key) === undefined) {
      this._store.set(key, {});
    }

    return this._store.get(key);
  }

  get(index) {
    return this._store.get(index);
  }

  delete(index) {
    this._store.delete(index);
  }

  clear() {
    this._store.clear();
  }

}

exports.default = DebuggerBackchannel;
//# sourceMappingURL=DebuggerBackchannel.js.map