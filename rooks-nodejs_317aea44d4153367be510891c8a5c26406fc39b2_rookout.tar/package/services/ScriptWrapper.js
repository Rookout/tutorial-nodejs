"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _logger = require("../logger");

var _sourceMapResolve = require("source-map-resolve");

var _sourceMap = require("source-map");

var _utils = require("../utils");

var _exceptions = require("../exceptions");

const fs = require('fs');

const path = require('path');

class ScriptWrapper {
  constructor(id, filename, source) {
    this.id = id;
    this.sourceFiles = [];
    this.filename = filename;
    this.normalizedFilename = (0, _utils.canonizeFileName)(filename);
    this.rawSource = source;
    this.mapConsumer = null;
    this.loadMap(source);
  }

  loadMap(source) {
    if (!this.filename || !source) {
      return;
    }

    let mapData = null;

    try {
      mapData = (0, _sourceMapResolve.resolveSourceMapSync)(source, this.filename, fs.readFileSync);
    } catch (e) {
      _logger.logger.debug("Unable to find source map", this.filename, e.message);
    }

    if (!mapData || !mapData.map) {
      return;
    }

    const mapObject = mapData.map;
    this.mapConsumer = new _sourceMap.SourceMapConsumer(mapObject);

    for (let sourceFile of mapObject.sources) {
      this.sourceFiles.push({
        normalizedPath: (0, _utils.canonizeFileName)(sourceFile),
        rawPath: sourceFile,
        rawSource: this.mapConsumer.sourceContentFor(sourceFile, true)
      });
    }
  }

  getMatchInfo(filename, includeExternals) {
    // Exclude NodeJS core libs
    if (!path.isAbsolute(this.filename)) {
      return null;
    }

    if (this.filename.includes('/node_modules/') && !includeExternals) {
      return null;
    }

    filename = (0, _utils.canonizeFileName)(filename);

    for (let sourceFile of this.sourceFiles) {
      if (this.arePathsConverging(sourceFile.normalizedPath, filename)) {
        // If we are dealing with a transpiled file, we prefer getting the source from disk
        // Otherwise, we have to stick with the source map, even if it's of lower accuracy
        let rawContents = null;
        const sourceFilePath = path.join(path.dirname(this.filename), sourceFile.normalizedPath);
        const adjacentSourceFile = path.join(path.dirname(this.filename), path.basename(sourceFile.normalizedPath));

        if (this.arePathsConverging(sourceFile.normalizedPath, filename) && fs.existsSync(sourceFilePath)) {
          rawContents = this.getRawFileContents(sourceFilePath);
        } else if (this.arePathsConverging(filename, sourceFile.normalizedPath) && adjacentSourceFile !== this.filename && fs.existsSync(adjacentSourceFile)) {
          rawContents = this.getRawFileContents(adjacentSourceFile);
        } else {
          rawContents = sourceFile.rawSource;
        }

        return {
          script: this,
          inSourceMap: true,
          filename: sourceFile.rawPath,
          fileContents: rawContents
        };
      }
    }

    if (this.arePathsConverging(this.normalizedFilename, filename)) {
      return {
        script: this,
        inSourceMap: false,
        filename: this.filename,
        fileContents: this.getRawFileContents(this.filename)
      };
    }

    return null;
  }

  arePathsConverging(path1, path2) {
    // Find longest match
    let i = path1.length - 1;
    let j = path2.length - 1;

    while (i >= 0 && j >= 0 && path1[i] === path2[j]) {
      --i;
      --j;
    } // Check that at least one of the strings has ended and the other is at a directory boundary


    return i === -1 && path2[j] === path.sep || j === -1 && path1[i] === path.sep || i === -1 && j === -1;
  }

  getGeneratedPosition(filename, line, column) {
    const position = this.mapConsumer.generatedPositionFor({
      source: filename,
      line: line,
      column: column,
      bias: _sourceMap.SourceMapConsumer.LEAST_UPPER_BOUND
    }); // generatedPositionFor might return zeroed position instance upon failure and not null

    if (position !== null && position.line !== null) {
      return position;
    } else {
      throw new _exceptions.RookResolveSourceFailed(this.filename);
    }
  }

  getOriginalPosition(line, column) {
    return this.mapConsumer.originalPositionFor({
      line: line,
      column: column
    });
  }

  getRawFileContents(filename) {
    try {
      return fs.readFileSync(filename, 'utf8');
    } catch (e) {
      throw new _exceptions.RookSourceError(this.filename, e);
    }
  }

}

exports.default = ScriptWrapper;
//# sourceMappingURL=ScriptWrapper.js.map