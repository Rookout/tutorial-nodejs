'use strict';

var _utils = require("./utils");

var _exceptions = require("./exceptions");

const util = require('util');

const {
  RookMissingToken,
  RookUnsupportedNodeVersion,
  RookInvalidToken,
  RookInvalidOptions,
  RookOldServers,
  RookUnsupportedRuntime
} = require('./exceptions');

const trueValues = ['y', 'Y', 'yes', 'Yes', 'YES', 'true', 'True', 'TRUE', '1', true];

class Rook {
  constructor() {
    this.savedOptions = null;
  }

  startSync(timeout = 5000, options = {}) {
    if (typeof timeout === 'object') {
      options = timeout;
      timeout = 5000;
    }

    let deasync;

    try {
      deasync = require('deasync');
    } catch (e) {
      const message = "[Rookout] To use startSync, install deasync (npm install deasync)";

      if (options.throw_errors) {
        throw new Error(e);
      } else {
        console.error(message);
      }

      return;
    }

    if (deasync) {
      let ready = false;
      let connected = false;
      let error;
      this.start(options).then(() => {
        ready = true;
        connected = true;
      }).catch(e => {
        ready = true;
        connected = false;
        error = e;
      });
      let startTime = Date.now();
      deasync.loopWhile(() => {
        if (timeout === undefined) {
          return ready === false;
        } else {
          return ready === false && Date.now() <= startTime + timeout;
        }
      });

      if (!connected) {
        if (undefined === error) {
          error = new Error("[Rookout] Connection to Controller timed out");
        }

        if (options.throw_errors) {
          throw error;
        } else {
          console.log(error.message);
        }
      }
    } else {
      this.start(options);
    }
  }

  start(options = {}) {
    if (Object.keys(options).length === 0 && this.savedOptions !== null) {
      options = this.savedOptions;
    }

    let self = this;
    this.startAttempted = true;
    return new Promise((resolve, reject) => {
      try {
        if (self.singleton) resolve();
        self.debug = false;

        if (options.debug === undefined) {
          self.debug = trueValues.indexOf(process.env.ROOKOUT_DEBUG) !== -1;
        } else {
          self.debug = options.debug;
        }

        if (options.log_to_stderr === undefined && process.env.ROOKOUT_LOG_TO_STDERR !== undefined) {
          options.log_to_stderr = trueValues.indexOf(process.env.ROOKOUT_LOG_TO_STDERR) !== -1;
        }

        if (options.log_file === undefined && process.env.ROOKOUT_LOG_FILE !== undefined) {
          options.log_file = process.env.ROOKOUT_LOG_FILE;
        }

        if (process.env.LAMBDA_TASK_ROOT) {
          options.log_file = "";

          if (options.lambda_safe_start !== true) {
            throw new _exceptions.RookIllegalLambdaStart();
          }
        }

        options.log_level = options.log_level || process.env.ROOKOUT_LOG_LEVEL;
        self.throw_errors = false;

        if (options.throw_errors !== undefined) {
          self.throw_errors = options.throw_errors;
        }

        Rook.checkVersionSupported();

        const config = require('./config');

        Rook._verifyBoolean(self.throw_errors, 'Rook throw errors should be a boolean');

        if (options.log_to_stderr !== undefined) {
          Rook._verifyBoolean(options.log_to_stderr, 'Rook log to stderr should be a boolean');

          config.LoggingConfiguration.LOG_TO_STDERR = options.log_to_stderr;
        }

        if (options.log_level !== undefined) {
          Rook._verifyString(options.log_level, 'Rook log level should be a String');

          config.LoggingConfiguration.LOG_LEVEL = options.log_level;
        }

        if (options.log_file !== undefined) {
          Rook._verifyString(options.log_file, 'Rook log file should be a String');

          config.LoggingConfiguration.FILE_NAME = options.log_file;
        }

        if (options.tags === undefined) {
          let rawTags = process.env.ROOKOUT_ROOK_TAGS;

          if (rawTags !== undefined) {
            options.tags = [];

            for (let tag of rawTags.replace(/['"]/g, '').split(';')) {
              options.tags.push(_utils.StringUtils.trim(tag));
            }
          }
        } else {
          if (Array.isArray(options.tags)) {
            for (let tag of options.tags) {
              Rook._verifyString(tag, 'Rook tags should be array of strings');
            }
          } else {
            throw new RookInvalidOptions('Rook tags should be array of strings');
          }
        }

        if (options.labels === undefined) {
          let labels = process.env.ROOKOUT_LABELS;

          if (labels !== undefined) {
            options.labels = {};

            for (let label of labels.replace(/['"]/g, '').split(',')) {
              let kv = label.split(':');

              if (kv.length === 2) {
                let key = kv[0];
                let value = kv[1];

                if (key && value) {
                  options.labels[key] = value;
                }
              }
            }
          }
        } else {
          // Normalize the map to native dictionary
          if (options.labels instanceof Map) {
            let originalLabels = options.labels;
            options.labels = {};

            for (let [key, value] of originalLabels) {
              options.labels[key] = value;
            }
          }

          for (let label of Object.keys(options.labels)) {
            Rook._verifyString(label);

            Rook._verifyString(options.labels[label], 'Rook label should be a map of strings');

            Rook._verifyLabel(label);
          }
        }

        Rook._verifyBoolean(self.debug, 'Rook debug flag should be a boolean');

        if (self.debug) {
          config.LoggingConfiguration.LOG_LEVEL = 'DEBUG';
          config.LoggingConfiguration.LOG_TO_STDERR = true;
          config.LoggingConfiguration.DEBUG = true;
        }

        if (options.git_commit !== undefined) {
          Rook._verifyString(options.git_commit, 'Git commit should be a String');

          config.GitConfiguration.GIT_COMMIT = options.git_commit;
        }

        if (options.git_origin !== undefined) {
          Rook._verifyString(options.git_origin, 'Git origin should be a String');

          config.GitConfiguration.GIT_ORIGIN = options.git_origin;
        }

        let host = options.host || process.env.ROOKOUT_CONTROLLER_HOST || process.env.ROOKOUT_AGENT_HOST;
        let port = options.port || process.env.ROOKOUT_CONTROLLER_PORT || process.env.ROOKOUT_AGENT_PORT;
        let proxy = options.proxy || process.env.ROOKOUT_PROXY;
        let token = options.token || process.env.ROOKOUT_TOKEN;

        if (proxy !== undefined) {
          Rook._verifyString(proxy, 'proxy should be a string');
        }

        const {
          logger
        } = require('./logger');

        logger.debug(util.format('Rookout SDK [%s]:[%s] for NodeJS [%s]', config.VersionConfiguration.VERSION, config.VersionConfiguration.COMMIT, process.versions.node));

        if (host === undefined && token === undefined) {
          throw new RookMissingToken();
        } else {
          if (token !== undefined) {
            Rook._verifyToken(token);
          }
        }

        if (this.debug) {
          Rook._print_options({
            token: token !== undefined ? token.substring(0, 5) + "....." : undefined,
            host: host,
            port: port,
            proxy: proxy,
            throw_errors: self.throw_errors,
            log_level: options.log_level,
            log_to_stderr: options.log_to_stderr,
            log_file: options.log_file,
            git_commit: options.git_commit,
            git_origin: options.git_origin,
            tags: options.tags,
            labels: options.labels
          });
        }

        host = host || config.ControllerAddress.HOST;

        Rook._verifyString(host, 'Rook host should be String');

        if (host === "staging.cloud.agent.rookout.com" || host === "cloud.agent.rookout.com") {
          throw new RookOldServers();
        }

        port = port || config.ControllerAddress.PORT;

        if (!(typeof port === 'number' || typeof port === 'string')) {
          throw new RookInvalidOptions('Rook port should be a Number or a String');
        }

        this.savedOptions = options;
        self.singleton = require('./singleton').singleton;
        self.singleton.connect(token, host, port, proxy, options.tags, options.labels).catch(e => {
          if (self.throw_errors) {
            reject(e);
          } else {
            if (e instanceof RookInvalidToken || e instanceof RookOldServers || e instanceof _exceptions.RookIllegalLambdaStart) {
              console.log('[Rookout] ', e.message);
            } else {
              console.error('[Rookout] Failed to connect to the controller - will continue attempting in the background: ', e.message);
            }

            if (self.debug) {
              console.error(e.stack || e);
            }

            resolve(self);
          }
        }).then(() => resolve(self));
      } catch (e) {
        if (self.throw_errors) {
          reject(e);
        } else {
          console.error('[Rookout] Failed to start Rookout: ', e.message);

          if (self.debug) {
            console.error(e.stack || e);
          }

          resolve(self);
        }
      }
    });
  }

  async stop() {
    if (!this.singleton) return;

    try {
      const singleton = this.singleton;
      this.singleton = undefined;
      await singleton.close();
    } catch (e) {
      if (this.throw_errors) {
        throw e;
      }

      if (this.debug) {
        console.error(e.stack || e);
      }
    }
  }

  flush(callback) {
    if (!this.singleton) {
      if (callback !== undefined) {
        callback();
      }

      return;
    }

    try {
      this.singleton.flush(callback);
    } catch (e) {
      if (this.throw_errors) {
        throw e;
      }

      if (this.debug) {
        console.error(e.stack || e);
      }
    }
  }

  notifyLambdaActive(context) {
    this.singleton.notifyLambdaActive(context);
  }

  notifyLambdaInactive() {
    this.singleton.notifyLambdaInactive();
  }

  static _print_options(options = {}) {
    try {
      let config_string = "";

      for (let key in options) {
        if (options[key] !== undefined) {
          config_string = config_string + key + ": " + options[key] + ", ";
        }
      }

      console.log("RookOptions: " + config_string);
    } catch (e) {}
  }

  static _verifyBoolean(object, errorString) {
    if (!(typeof object === 'boolean')) {
      throw new RookInvalidOptions(errorString);
    }
  }

  static _verifyString(object, errorString) {
    if (!(typeof object === 'string' || object instanceof String)) {
      throw new RookInvalidOptions(errorString);
    }
  }

  static _verifyToken(object) {
    Rook._verifyString(object, 'Rookout token should be a String');

    if (object.length !== 64) {
      throw new RookInvalidOptions('Rookout token should be 64 characters');
    }

    if (/^[0-9a-zA-Z]+$/.test(object) === false) {
      throw new RookInvalidOptions('Rookout token must consist of only hexadecimal characters');
    }
  }

  static _verifyLabel(label) {
    if (label.startsWith("$")) {
      throw new _exceptions.RookInvalidLabel(label);
    }
  }

  static checkVersionSupported() {
    if (!process || !process.versions || !process.versions.node) {
      throw new RookUnsupportedRuntime();
    }

    if (process.versions.node.startsWith('8.9.1')) {
      throw new RookUnsupportedNodeVersion(process.versions.node);
    }
  }

}

module.exports = Rook;
//# sourceMappingURL=interface.js.map