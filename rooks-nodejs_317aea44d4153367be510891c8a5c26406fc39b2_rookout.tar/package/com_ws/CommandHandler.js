"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

class CommandHandler {
  constructor(agentCom, augManager) {
    this.agentCom = agentCom;
    this.augManager = augManager;
    this.agentCom.on("InitialAugsCommand", initialAugs => this._handleInitialAugs(initialAugs));
    this.agentCom.on("AddAugCommand", command => this._handleAddAug(command));
    this.agentCom.on("RemoveAugCommand", command => this._handleRemoveAug(command));
  }

  _handleInitialAugs(initialAugs) {
    let augs = [];

    for (const aug of initialAugs.getAugsList()) {
      let augConfig = JSON.parse(aug);
      augs.push(augConfig);
    }

    this.augManager.initializeAugs(augs);
  }

  _handleAddAug(command) {
    this.augManager.addAug(JSON.parse(command.getAugJson()));
  }

  _handleRemoveAug(command) {
    this.augManager.removeAug(command.getAugId());
  }

}

exports.default = CommandHandler;
//# sourceMappingURL=CommandHandler.js.map