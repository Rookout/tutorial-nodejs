#!/usr/bin/env node

/**
 * This wrapper file checks for any node flags and and spawns a new process with these flags
 * Since this process has no flags and the user might want to add them.
 * The new process will execute CircleCiOrbWrapperInternal.js that will change the command line and
 * will let the original command to run
 * this logic is very similar to babel-node
 */
"use strict";

const path = require("path");

let args = []; // trip the "node CircleCiOrbWrapper.js" arguments

let trimmedArguments = process.argv.slice(2); // if user accidentally used node as parameter - we trim it

if (trimmedArguments[0] !== undefined && trimmedArguments[0].endsWith("node")) {
  trimmedArguments = trimmedArguments.slice(1);
} // Look for the first argument that does not start with - which will be the users script


let scriptIndex = undefined;
let ignoreNext = false;
trimmedArguments.some(function (arg, index) {
  if (ignoreNext) {
    return;
  }

  if (arg[0] === "-") {
    args.push(arg);
  } else {
    if (scriptIndex === undefined) {
      scriptIndex = index;
    }

    ignoreNext = true;
  }
});

if (scriptIndex === undefined) {
  console.log("Bad command line - could not find script to run");
  process.exit(1);
} //args is holding all the node flags, lets add our second wrapper and the rest of the arguments


args.push(path.join(__dirname, "CircleCiOrbWrapperInternal.js"));
args = args.concat(trimmedArguments.slice(scriptIndex));

try {
  const kexec = require("kexec");

  kexec(process.argv[0], args);
} catch (err) {
  if (err.code !== "MODULE_NOT_FOUND") throw err;

  const child_process = require("child_process");

  const proc = child_process.spawn(process.argv[0], args, {
    stdio: "inherit"
  });
  proc.on("exit", function (code, signal) {
    process.on("exit", function () {
      if (signal) {
        process.kill(process.pid, signal);
      } else {
        process.exit(code);
      }
    });
  });
  process.on("SIGINT", () => {
    proc.kill("SIGINT");
    process.exit(1);
  });
}
//# sourceMappingURL=CircleCiOrbWrapper.js.map