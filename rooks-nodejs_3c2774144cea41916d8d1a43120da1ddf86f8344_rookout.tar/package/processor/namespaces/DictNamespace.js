"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _Namespace = _interopRequireDefault(require("./Namespace"));

var _JSObjectNamespace = _interopRequireDefault(require("./JSObjectNamespace"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/*
Javascript doesn't actually have dicts (or maps etc),
they are the same as JS objects. This class exists for
compatibility with parts of the API that require a dict.
*/
class DictNamespace extends _Namespace.default {
  constructor(obj) {
    super();
    this.dict = obj;
    this.commonType = DictNamespace.getCommonType(obj);
    this.originalSize = Object.keys(obj).length;
    this.originalType = typeof obj;
  }

  callMethod(name, args) {
    switch (name) {
      case "type":
        return new _JSObjectNamespace.default(this.originalType);

      case "size":
        return new _JSObjectNamespace.default(Object.keys(this.dict).length);

      case "original_size":
        return new _JSObjectNamespace.default(this.originalSize);

      default:
        return super.callMethod(name, args);
    }
  }

  static getCommonType(obj) {
    return "dict";
  }

  readKey(key) {
    return this.dict[key];
  }

}

exports.default = DictNamespace;
//# sourceMappingURL=DictNamespace.js.map