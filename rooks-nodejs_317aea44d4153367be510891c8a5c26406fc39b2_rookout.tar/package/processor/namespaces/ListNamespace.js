"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _Namespace = _interopRequireDefault(require("./Namespace"));

var _JSObjectNamespace = _interopRequireDefault(require("./JSObjectNamespace"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

class ListNamespace extends _Namespace.default {
  constructor(list) {
    super();
    this.list = list;
    this.commonType = ListNamespace.getCommonType(list);
    this.originalSize = list.length;
    this.originalType = typeof list;
  }

  callMethod(name, args) {
    switch (name) {
      case "type":
        return new _JSObjectNamespace.default(this.originalType);

      case "size":
        return new _JSObjectNamespace.default(this.list.length);

      case "original_size":
        return new _JSObjectNamespace.default(this.originalSize);

      default:
        return super.callMethod(name, args);
    }
  }

  static getCommonType(list) {
    return "array";
  }

  readKey(key) {
    return this.list[key];
  }

}

exports.default = ListNamespace;
//# sourceMappingURL=ListNamespace.js.map