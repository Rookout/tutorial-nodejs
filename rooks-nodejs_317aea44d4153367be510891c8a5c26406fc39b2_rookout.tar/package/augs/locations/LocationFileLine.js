"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _RookError = _interopRequireDefault(require("../../processor/RookError"));

var _crc = _interopRequireDefault(require("crc/lib/es6/crc32"));

var _logger = require("../../logger");

var _exceptions = require("../../exceptions");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const child_process = require('child_process');

const CryptoJS = require('crypto-js');

const SHA256 = require('crypto-js/sha256');

class LocationFileLine {
  constructor(configuration, factory) {
    this.filename = configuration.filename;

    if (!(typeof this.filename === 'string' || this.filename instanceof String)) {
      throw new _exceptions.RookAugInvalidKey('filename'.configuration);
    }

    this.lineno = configuration.lineno;

    if (!Number.isInteger(this.lineno)) {
      throw new _exceptions.RookAugInvalidKey('lineno'.configuration);
    }

    this.fileHash = configuration.sha256 || null;
    this.lineCrc32 = configuration.line_crc32_2 || null; // If missing, we assume line is not unique

    this.lineUnique = configuration.line_unique || false; // The default value for NodeJS is false

    this.includeExternals = configuration.includeExternals || false;
  }

  addAug(triggerServices, aug) {
    const self = this;
    let debuggerService = triggerServices.getService("DebuggerService");
    aug.setPending();
    debuggerService.registerNotification(aug, this.filename, this.fileHash, this.includeExternals, matchInfo => {
      if (null !== matchInfo.script && undefined !== matchInfo.script) {
        try {
          let updatedLineno = null;

          if (null !== matchInfo.fileContents) {
            updatedLineno = this.getUpdateLineNumber(aug, this.filename, matchInfo.fileContents);
          } else {
            aug.sendWarning(new _RookError.default(new _exceptions.RookSourceMissing(this.filename)));
            updatedLineno = this.lineno;
          }

          debuggerService.addAug(null, matchInfo, updatedLineno, null, aug);
        } catch (e) {
          const message = "Exception when adding aug";

          _logger.logger.exception(message, e);

          aug.setError(new _RookError.default(e, message));
        }
      }
    }, () => {
      aug.setRemoved();
    });
  }

  getUpdateLineNumber(aug, filename, fileContents) {
    fileContents = fileContents.replace(/(?:\r\n|\r|\n)/g, "\n");

    if (null != this.lineCrc32) {
      return this.updateLineUsingCrc(aug, filename, fileContents);
    }

    if (null != this.fileHash) {
      this.testFileHash(filename, fileContents);
      return this.lineno;
    }

    return this.lineno;
  }

  updateLineUsingCrc(aug, filename, fileContents) {
    const lines = fileContents.split("\n"); // If the line has not changed, we are good - return

    let lineCrc32;

    if (lines.length >= this.lineno) {
      lineCrc32 = (0, _crc.default)(lines[this.lineno - 1]).toString(16);
    }

    if (lineCrc32 === this.lineCrc32) {
      return this.lineno;
    } // If the line was unique in the original file, let's try to find it in this file


    if (this.lineUnique === true) {
      // If the line was unique in the original file and is still original here - send a warning and return
      const crc32s = lines.map(line => (0, _crc.default)(line).toString(16));
      const firstIndex = crc32s.indexOf(this.lineCrc32);
      const lastIndex = crc32s.lastIndexOf(this.lineCrc32);

      if (firstIndex !== -1 && firstIndex === lastIndex) {
        const updatedLine = firstIndex + 1;
        aug.sendWarning(new _RookError.default(new _exceptions.RookLineMoved(this.filename, this.lineno, updatedLine)));
        return updatedLine;
      }
    } // We failed to get a good match - throw an error


    const blobHash = this.getGitBlobHash(filename);
    throw new _exceptions.RookCrcMismatchException(filename, this.lineCrc32, lineCrc32, blobHash);
  }

  testFileHash(filename, fileContents) {
    const fileHash = SHA256(fileContents).toString(CryptoJS.enc.Hex);

    if (fileHash !== this.fileHash) {
      const blobHash = this.getGitBlobHash(filename);
      throw new _exceptions.RookHashMismatchException(filename, this.fileHash, fileHash, blobHash);
    }
  }

  getGitBlobHash(filename) {
    try {
      return child_process.spawnSync("git", ["hash-object", filename]).stdout.toString().trim();
    } catch (e) {
      return null;
    }
  }

}

exports.default = LocationFileLine;
LocationFileLine.jsonName = "file_line";
//# sourceMappingURL=LocationFileLine.js.map