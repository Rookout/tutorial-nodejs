"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.collect = collect;
exports.pack_agent_info = pack_agent_info;

var _logger = require("../logger");

var _git = _interopRequireDefault(require("../git"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const agent_info_pb = require("../protobuf/agent_info_pb");

const os = require("os");

const ip = require("ip");

const path = require("path");

const getos = require("getos");

const config = require('../config');

class Information {
  constructor() {
    if (this.constructor === Information) {
      throw new TypeError("Abstract class \"Information\" cannot be instantiated directly.");
    }

    this._collectors = this._getCollectors();
  } // Override this method without calling super.

  /* abstract */


  _getCollectors() {
    throw new TypeError("Inheriting classes must implement _getCollectors");
  }

  async collect() {
    let output = {};

    for (let key of Object.keys(this._collectors)) {
      let value = this._collectors[key];

      if (value instanceof Function) {
        value = value();
      }

      output[key] = await value;
    }

    return output;
  }

}

class SCMInformation extends Information {
  _getCollectors() {
    return {
      "commit": this._get_commit,
      "origin": this._get_origin
    };
  }

  _get_commit() {
    let userCommit = config.GitConfiguration.GIT_COMMIT || process.env.ROOKOUT_COMMIT || "";

    if (userCommit === "") {
      try {
        let gitRoot = this._get_git_root();

        if (gitRoot !== "") {
          if (userCommit === "") {
            userCommit = _git.default.getRevision(gitRoot);
          }

          return userCommit;
        }
      } catch (e) {
        _logger.logger.exception("Failed to get git commit");
      }

      return "";
    }

    return userCommit;
  }

  _get_git_root() {
    let gitRoot = process.env.ROOKOUT_GIT || "";

    if (gitRoot === "") {
      gitRoot = _git.default.findRoot(path.dirname(path.resolve(executable)));
    }

    return gitRoot;
  }

  _get_origin() {
    let userRemoteOrigin = config.GitConfiguration.GIT_ORIGIN || process.env.ROOKOUT_REMOTE_ORIGIN || "";

    if (userRemoteOrigin === "") {
      try {
        let gitRoot = this._get_git_root();

        if (gitRoot !== "") {
          if (userRemoteOrigin === "") {
            userRemoteOrigin = _git.default.getRemoteOrigin(gitRoot);
          }

          return userRemoteOrigin;
        }
      } catch (e) {
        _logger.logger.exception("Failed to get git remote origin");
      }

      return "";
    }

    return userRemoteOrigin;
  }

}

class PlatformInformation extends Information {
  _getCollectors() {
    return {
      "platform": "node",
      "version": process.version
    };
  }

}

class NetworkInformation extends Information {
  _getCollectors() {
    return {
      "ip_addr": ip.address,
      "network": os.hostname
    };
  }

}

class SystemInformation extends Information {
  _getCollectors() {
    return {
      "hostname": os.hostname,
      "os": os.platform,
      "os_version": os.release,
      "distro": this._getDistro,
      "arch": os.arch
    };
  }

  async _getDistro() {
    if (os.platform() !== "linux") {
      return "<NA>";
    }

    let distro = null;
    getos((e, os_info) => {
      if (e) {
        throw e;
      }

      distro = os_info.dist + " " + os_info.codename + " " + os_info.release;
      return distro;
    });
  }

}

class VersionInformation extends Information {
  _getCollectors() {
    return {
      "version": "0.1.105",
      "commit": "317aea44d4153367be510891c8a5c26406fc39b2"
    };
  }

}

class AgentInformation extends Information {
  _getCollectors() {
    return {
      "version": () => new VersionInformation().collect(),
      "network": () => new NetworkInformation().collect(),
      "system": () => new SystemInformation().collect(),
      "platform": () => new PlatformInformation().collect(),
      "scm": () => new SCMInformation().collect(),
      "executable": () => {
        if (process.mainModule !== undefined && process.mainModule.filename !== undefined) {
          return path.basename(process.mainModule.filename);
        } else {
          return path.basename(process.argv[0]);
        }
      },
      "command_arguments": process.argv,
      "process_id": process.pid
    };
  }

}

async function collect() {
  return new AgentInformation().collect();
}

function pack_agent_info(info) {
  let packed_info = new agent_info_pb.AgentInformation();
  packed_info.setAgentId(info.agent_id);
  let version_info = new agent_info_pb.VersionInformation();
  version_info.setVersion(info.version.version);
  version_info.setCommit(info.version.commit);
  packed_info.setVersion(version_info);
  let network_info = new agent_info_pb.NetworkInformation();
  network_info.setIpAddr(info.network.ip_addr);
  network_info.setNetwork(info.network.network);
  packed_info.setNetwork(network_info);
  let system_info = new agent_info_pb.SystemInformation();
  system_info.setHostname(info.system.hostname);
  system_info.setOs(info.system.os);
  system_info.setOsVersion(info.system.os_version);
  system_info.setDistro(info.system.distro);
  system_info.setArch(info.system.arch);
  packed_info.setSystem(system_info);
  let platform_info = new agent_info_pb.PlatformInformation();
  platform_info.setPlatform(info.platform.platform);
  platform_info.setVersion(info.platform.version);
  packed_info.setPlatform(platform_info);
  let scm_info = new agent_info_pb.SCMInformation();
  scm_info.setCommit(info.scm.commit);
  scm_info.setOrigin(info.scm.origin);
  packed_info.setScm(scm_info);
  packed_info.setExecutable(info.executable);
  packed_info.setCommandArgumentsList(info.command_arguments);
  packed_info.setProcessId(info.process_id);
  let labels_map = packed_info.getLabelsMap();
  Object.keys(info.labels).forEach(key => {
    labels_map.set(key, info.labels[key]);
  });
  packed_info.setTagsList(info.tags);
  return packed_info;
}
//# sourceMappingURL=information.js.map