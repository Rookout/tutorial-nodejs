"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _exceptions = require("../exceptions");

var _NamespaceSerializer = _interopRequireDefault(require("./NamespaceSerializer"));

var _JSObjectNamespace = _interopRequireDefault(require("./namespaces/JSObjectNamespace"));

var _DictNamespace = _interopRequireDefault(require("./namespaces/DictNamespace"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const variant_pb = require('../protobuf/variant_pb');

class RookError {
  constructor(error, message = "") {
    this.error = error;

    if (error instanceof _exceptions.ToolException) {
      this.type = error.__proto__.constructor.name;
      this.message = error.message;
      this.parameters = error.parameters;
    } else {
      this.type = "Unknown";
      this.message = message;
      this.parameters = null;
    } // FUTURE - advanced stack extraction


    this.stackTrace = error.stack;
  }

  dumps() {
    let error = new variant_pb.Error();

    try {
      error.setMessage(this.message);
    } catch (e) {}

    try {
      error.setType(this.type);
    } catch (e) {}

    try {
      error.setParameters(new _NamespaceSerializer.default().dumps(new _DictNamespace.default(this.parameters)));
    } catch (e) {}

    try {
      error.setExc(new _NamespaceSerializer.default().dumps(new _JSObjectNamespace.default(this.error)));
    } catch (e) {}

    try {
      error.setTraceback(new _NamespaceSerializer.default().dumps(new _JSObjectNamespace.default(this.stackTrace, _JSObjectNamespace.default.tailorDumpConfig(this.stackTrace))));
    } catch (e) {}

    return error;
  }

}

exports.default = RookError;
//# sourceMappingURL=RookError.js.map