#!/usr/bin/env node
"use strict";

console.log("[Rookout] Testing connection to Rookout Agent...");
let success = undefined;

try {
  const rook = require('./index');

  module.exports = rook;
  let r = rook.start({
    throw_errors: true
  });
  r.then(() => {
    success = true;
  }).catch(e => {
    success = false;
    console.log("[Rookout] Failed to connect: " + e);
  });
} catch (e) {
  console.log(e.stack || e);
  console.log("[Rookout] Failed to connect, please see error above");
  process.exit(1);
}

var count = 0;
setInterval(() => {
  if (success !== undefined) {
    if (success) {
      console.error("[Rookout] Connected successfully");
      process.exit(0);
    } else {
      console.log("[Rookout] Failed to connect, please see error above");
      process.exit(1);
    }
  }

  if (count > 10) {
    console.log("[Rookout] Failed to connect - Timeout");
    process.exit(2);
  }

  count = count + 1;
}, 1000);
//# sourceMappingURL=check.js.map