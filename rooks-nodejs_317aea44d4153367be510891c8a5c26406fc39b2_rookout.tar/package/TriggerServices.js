"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _DebuggerService = require("./services/DebuggerService");

var _logger = require("./logger");

class TriggerServices {
  constructor() {
    this.services = {};
    this.loadServices();
  }

  getService(name) {
    return this.services[name];
  }

  removeAug(augId) {
    for (let name in this.services) {
      this.services[name].removeAug(augId);
    }
  }

  clearAugs() {
    for (let name of Object.keys(this.services)) {
      this.services[name].clearAugs();
    }
  }

  start() {
    this.loadServices();
  }

  async close() {
    const servicesToClose = [...Object.values(this.services)];
    this.services = {};

    for (let service of servicesToClose) {
      await service.close();
    }
  }

  loadServices() {
    try {
      this.services['DebuggerService'] = new _DebuggerService.DebuggerService();
    } catch (e) {
      _logger.logger.exception("Error starting location based services", e);
    } // FUTURE - init logging service

  }

}

exports.default = TriggerServices;
//# sourceMappingURL=TriggerServices.js.map