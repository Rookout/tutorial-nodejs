"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _Processor = _interopRequireDefault(require("./Processor"));

var _Set = _interopRequireDefault(require("./operations/Set"));

var _ArithmeticPath = _interopRequireDefault(require("./paths/ArithmeticPath"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

class ProcessorFactory {
  constructor() {}

  getOperation(configuration) {
    return new _Set.default(configuration, this);
  }

  getPath(configuration) {
    return new _ArithmeticPath.default(configuration);
  }

  getProcessor(configuration) {
    return new _Processor.default(configuration, this);
  }

}

exports.default = ProcessorFactory;
//# sourceMappingURL=ProcessorFactory.js.map