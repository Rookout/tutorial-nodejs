"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _Namespace = _interopRequireDefault(require("./Namespace"));

var _exceptions = require("../../exceptions");

var _JSObjectNamespace = _interopRequireDefault(require("./JSObjectNamespace"));

var _DynamicInspectorObjectNamespace = _interopRequireDefault(require("./DynamicInspectorObjectNamespace"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

class InspectorObjectNamespace extends _Namespace.default {
  constructor(inspector, obj, dumpConfig = null) {
    super();
    this.inspector = inspector;
    this.obj = obj;

    if (dumpConfig === null) {
      this.dumpConfig = _JSObjectNamespace.default.defaultDumpConfig();
    } else {
      this.dumpConfig = dumpConfig;
    }
  }

  loadProperties() {
    if (this.properties === undefined) {
      this.properties = this.inspector.getProperties(this.obj);
    }
  }

  callMethod(name, args) {
    switch (name) {
      case "size":
        if (this.obj instanceof Array) {
          return new _JSObjectNamespace.default(this.obj.length);
        } else {
          return new _JSObjectNamespace.default(Object.keys(this.obj).length);
        }

      case "type":
        return new _JSObjectNamespace.default(this.obj.className);

      default:
        return super.callMethod(name, args);
    }
  }

  readAttribute(name) {
    this.loadProperties();

    for (let property of this.properties) {
      if (property.name === name) {
        // skip getter attributes, ex:
        // {
        //   get val() { return 0; }
        // }
        if (null === property.value || undefined === property.value) {
          if ('get' in property) {
            return new _DynamicInspectorObjectNamespace.default(this.inspector);
          }

          throw new RookInspectorUnknownProperty(property);
        } else {
          return InspectorObjectNamespace.getObject(this.inspector, property.value);
        }
      }
    }

    throw new _exceptions.RookAttributeNotFound(name);
  }

  readKey(key) {
    if (this.obj.className === 'Array') {
      if (Number.isInteger(key)) {
        return this.readAttribute(key.toString());
      }
    }

    return this.readAttribute(key);
  }

  static getObjectInternal(inspector, obj) {
    switch (obj.type) {
      case 'number':
      case 'string':
      case 'undefined':
      case 'boolean':
      case 'symbol':
        return obj.value;

      case 'object':
        if (null === obj.value) {
          return null;
        }

      case 'function':
        return new InspectorObjectNamespace(inspector, obj);

      default:
        throw new _exceptions.RookInspectorUnknownObject(obj);
    }
  }

  static getObject(inspector, obj) {
    switch (obj.type) {
      case 'number':
      case 'string':
      case 'undefined':
      case 'boolean':
      case 'symbol':
        return new _JSObjectNamespace.default(obj.value);

      case 'object':
        if (null === obj.value) {
          return new _JSObjectNamespace.default(null);
        }

      case 'function':
        return new InspectorObjectNamespace(inspector, obj);

      default:
        throw new _exceptions.RookInspectorUnknownObject(obj);
    }
  }

}

exports.default = InspectorObjectNamespace;
//# sourceMappingURL=InspectorObjectNamespace.js.map