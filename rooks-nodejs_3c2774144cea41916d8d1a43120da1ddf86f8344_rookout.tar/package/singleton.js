"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.singleton = void 0;

var _CommandHandler = _interopRequireDefault(require("./com_ws/CommandHandler"));

var _logger = require("./logger");

var _TriggerServices = _interopRequireDefault(require("./TriggerServices"));

var _AugManager = _interopRequireDefault(require("./augs/AugManager"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const uuid4 = require("uuid/v4");

const config = require('./config');

const Output = require("./com_ws/OutputWs").default;

class Singleton {
  constructor() {
    this.id = uuid4().replace(/\-/g, "");
    this.output = new Output(this.id);
    this.servicesStarted = false;
    this.triggerServices = null;
    this.augManager = null;
    this.agentCom = null;
  }

  async close() {
    _logger.logger.info("Shutting down");

    const agentCom = this.agentCom;
    this.agentCom = null;

    if (null !== agentCom) {
      await agentCom.close();
    }

    await this.stopServices();
  }

  flush(callback) {
    this.output.flushMessages(callback);
  }

  startServices() {
    if (this.servicesStarted) {
      return;
    }

    this.triggerServices = new _TriggerServices.default();
    this.augManager = new _AugManager.default(this.triggerServices, this.output);
    this.servicesStarted = true;
  }

  async stopServices() {
    if (!this.servicesStarted) {
      return;
    }

    this.augManager = null;
    const triggerSvc = this.triggerServices;
    this.triggerServices = null;
    await triggerSvc.close();
    this.servicesStarted = false;
  }

  notifyLambdaActive(context) {
    if (null !== this.agentCom) {
      this.agentCom.notifyLambdaActive(context);
    }
  }

  notifyLambdaInactive() {
    if (null !== this.agentCom) {
      this.agentCom.notifyLambdaInactive();
    }
  }

  connect(token, host, port, proxy, tags, labels) {
    this.startServices();

    _logger.logger.debug("Initiating AgentCom-\t%s:%d", host, port);

    const AgentCom = require("./com_ws/AgentComWs").default;

    this.agentCom = new AgentCom(this.id, host, port, proxy, token, labels, tags);
    this.commandHandler = new _CommandHandler.default(this.agentCom, this.augManager);
    this.output.setAgentCom(this.agentCom);
    return this.agentCom.connectToAgent(config.AgentComConfiguration.TIMEOUT * 1000);
  }

}

let singleton = new Singleton();
exports.singleton = singleton;
//# sourceMappingURL=singleton.js.map