"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _JSObjectNamespace = _interopRequireDefault(require("../namespaces/JSObjectNamespace"));

var _exceptions = require("../../exceptions");

var _ContainerNamespace = _interopRequireDefault(require("../namespaces/ContainerNamespace"));

var _InspectorObjectNamespace = _interopRequireDefault(require("../namespaces/InspectorObjectNamespace"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const exceptions = require('../../exceptions');

/*
Canopy is used to build and evaluate a tree of operations.
a .peg file (Rookout/canopy/ArithmeticPath.peg) is compiled into the various rooks languages.
Canopy is a PEG parser compiler - and i extend its goal to actually evaluate our arithmetic paths.
 */
const maps = require('./ArithmeticPathInternal');

const ops = new Map([["NE", "!="], ["=", "=="], ["EQ", "=="], ["LT", "<"], ["GT", ">"], ["GE", ">="], ["LE", "<="], ["AND", "&&"], ["OR", "||"]]);
const level1 = ["*", "/"];
const level2 = ["+", "-"];
const level3 = ["<=", ">=", "!=", "=", "==", ">", "<", "LT", "GT", "LE", "GE", "EQ", "NE", "lt", "gt", "le", "ge", "eq", "ne"];
const level4 = ["in", "IN"];
const level5 = ["or", "OR", "||", "and", "AND", "&&"];
const allLevels = [level1, level2, level3, level4, level5];

class Marker {}

class FunctionOperation extends Marker {
  constructor(funcName, funcArgs) {
    super();
    this.funcName = funcName;
    this.funcArgs = funcArgs;
  }

  read(namespace, create) {
    return namespace.callMethod(this.funcName, this.funcArgs);
  }

  write(namespace, value) {
    throw (0, _exceptions.RookOperationReadOnly)("FunctionOperation");
  }

}

class AttributeOperation extends Marker {
  constructor(name) {
    super();
    this.name = name;
  }

  read(namespace, create) {
    if (namespace === null) {
      throw new _exceptions.RookAttributeNotFound(this.name);
    }

    try {
      return namespace.readAttribute(this.name);
    } catch (e) {
      if (create && e instanceof _exceptions.RookAttributeNotFound) {
        namespace.writeAttribute(this.name, new _ContainerNamespace.default({}));
        return namespace.readAttribute(this.name);
      } else {
        throw e;
      }
    }
  }

  write(namespace, value) {
    return namespace.writeAttribute(this.name, value);
  }

}

class LookupOperation extends Marker {
  constructor(name) {
    super();

    if (name.length > 1 && name[0] === "'" && name[name.length - 1] === "'") {
      this.name = name.substring(1, name.length - 1);
    } else if (name.length > 1 && name[0] === '"' && name[name.length - 1] === '"') {
      this.name = name.substring(1, name.length - 1);
    } else {
      this.name = Number(name);
    }
  }

  read(namespace, create) {
    return namespace.readKey(this.name);
  }

  write(namespace, value) {
    throw (0, _exceptions.RookOperationReadOnly)("LookupOperation");
  }

}

class ToolException_ extends Marker {
  constructor(exc) {
    super();
    this.obj = exc;
  }

  toString() {
    return this.obj.toString();
  }

}

class NamespaceResult extends Marker {
  constructor(namespace) {
    super();
    this.obj = namespace;
    this.text = 'true';

    if (this.obj.obj !== undefined) {
      if (typeof this.obj.obj === "string") {
        this.text = "'" + this.obj.obj.toString() + "'";
      } else {
        if (this.obj.obj !== null) {
          this.text = this.obj.obj.toString();
        } else {
          this.text = "'null'";
        }
      }
    } else {
      this.text = "'undefined'";
    }
  }

  toString() {
    //assuming its JavaObjectNamespace
    return this.text;
  }

  rawString() {
    if (this.obj.obj === undefined) {
      return "'undefined'";
    }

    if (this.obj.obj === null) {
      return "'null'";
    }

    return this.obj.obj.toString();
  }

  get_obj() {
    return this.obj.obj;
  }

}

class NonPrimitiveNamespaceResult extends NamespaceResult {
  constructor(namespace, path) {
    super(namespace);
    this.path = path;
  }

  toString() {
    return 'NonPrimitiveNamespaceResult';
  }

}

class Text extends Marker {
  constructor(str) {
    super();
    this.obj = str;
    this.text = str;
  }

  toString() {
    return this.obj;
  }

  get_obj() {
    return this.obj;
  }

}

class TextResult extends Marker {
  constructor(str) {
    super();
    this.obj = str;
    this.text = str;
  }

  toString() {
    return this.text;
  }

  get_obj() {
    return this.obj;
  }

}

class Array_ extends Marker {
  constructor(list, str) {
    super();
    this.obj = list;
    this.text = str;
  }

  toString() {
    return this.text;
  }

  get_obj() {
    return this.obj;
  }

}

class FloatNumber extends Marker {
  constructor(number) {
    super();
    this.obj = parseFloat(number);
    this.text = number;
  }

  toString() {
    return this.obj.toString();
  }

  get_obj() {
    return this.obj;
  }

}

class Number_ extends Marker {
  constructor(number) {
    super();
    this.obj = parseInt(number, 10);
    this.text = number;
  }

  toString() {
    return this.obj.toString();
  }

  get_obj() {
    return this.obj;
  }

}

class Char extends Marker {
  constructor(chr) {
    super();
    this.obj = chr;
    this.text = "'" + chr + "'";
  }

  toString() {
    return this.obj;
  }

  get_obj() {
    return this.obj;
  }

}

class Bool extends Marker {
  constructor(bool) {
    super();
    this.obj = bool === 'true' || bool === 'True' || bool === true;
    this.text = bool;
  }

  toString() {
    return this.obj.toString();
  }

  get_obj() {
    return this.obj;
  }

}

class Null extends Marker {
  constructor() {
    super();
    this.obj = null;
    this.text = 'null';
  }

  toString() {
    return this.text;
  }

  get_obj() {
    return this.obj;
  }

}

class Undefined extends Marker {
  constructor() {
    super();
    this.obj = undefined;
    this.text = 'undefined';
  }

  toString() {
    return this.text;
  }

  get_obj() {
    return this.obj;
  }

}

const _opMap = new Map([["+", function (a, b) {
  return a + b;
}], ["-", function (a, b) {
  return a - b;
}], ["/", function (a, b) {
  return a / b;
}], ["*", function (a, b) {
  return a * b;
}], ["<", function (a, b) {
  return a < b;
}], ["<=", function (a, b) {
  return a <= b;
}], [">", function (a, b) {
  return a > b;
}], [">=", function (a, b) {
  return a >= b;
}], ["!=", function (a, b) {
  return a !== b;
}], ["!==", function (a, b) {
  return a !== b;
}], ["=", function (a, b) {
  return a === b;
}], ["==", function (a, b) {
  return a === b;
}], ["===", function (a, b) {
  return a === b;
}], //"in": function(a, b) { return a in b; },lambda a, b: a in b,  # should use this...
["&&", function (a, b) {
  return a && b;
}], ["||", function (a, b) {
  return a || b;
}]]);

class Opt extends Marker {
  constructor(opt) {
    super();
    this.opt = opt;
    this.level = null;
    let optUpperCase = opt.toUpperCase();

    for (let [key, value] of ops) {
      if (key === optUpperCase) {
        this.opt = value;
        break;
      }
    }

    let level = 0;
    let found = false;

    for (let value of allLevels) {
      for (let innerValue of value) {
        if (opt === innerValue) {
          this.level = level;
          found = true;
          break;
        }
      }

      if (found) {
        break;
      }

      level += 1;
    }

    if (!found) {
      throw new exceptions.RookInvalidArithmeticPath("Condition could not be resolved: " + opt);
    }
  }

  executeOperation(a, b) {
    switch (this.level) {
      case 0:
      case 1:
      case 2:
      case 4:
        let result = _opMap.get(this.opt)(a.get_obj(), b.get_obj());

        if (result.constructor === Boolean) {
          if (result === false) {
            if (a instanceof NonPrimitiveNamespaceResult) {
              if (!(b instanceof Undefined) && !(b instanceof Null)) {
                return new ToolException_(new _exceptions.RookNonPrimitiveObjectType(a.path));
              }
            }

            if (b instanceof NonPrimitiveNamespaceResult) {
              if (!(a instanceof Undefined) && !(a instanceof Null)) {
                return new ToolException_(new _exceptions.RookNonPrimitiveObjectType(b.path));
              }
            }
          }

          return new Bool(result);
        }

        if (result instanceof Bool) {
          return new Bool(result);
        }

        if (Number.isInteger(result)) {
          return new Number_(result);
        }

        return new TextResult(result);

      case 3:
        if (b instanceof NonPrimitiveNamespaceResult) {
          return new ToolException_(new _exceptions.RookNonPrimitiveObjectType(b.path));
        }

        if (!b instanceof Array && !b instanceof NamespaceResult && !b instanceof Text) {
          return new Bool(false);
        }

        if (b.obj instanceof _InspectorObjectNamespace.default) {
          if (b.obj.obj.subtype === 'array') {
            // loadProperties only if need to inspect the internal
            b.obj.loadProperties();

            for (let prop of b.obj.properties) {
              if (prop.name === 'length' || prop.name === '__proto__') {
                continue;
              } else {
                let val = prop.value.value;

                if (!actions.is_primitive(val)) {
                  return new NonPrimitiveNamespaceResult(b.obj, input.substr(start, end));
                }

                if (val.toString() === a.text) {
                  return new Bool(true);
                }
              }
            }
          } else {
            return new NonPrimitiveNamespaceResult(result, input.substr(start, end));
          }
        } else if (b.obj instanceof _JSObjectNamespace.default) {
          if (Array.isArray(b.obj.obj)) {
            for (let item of b.obj.obj) {
              if (item === a.obj) {
                return new Bool(true);
              }
            }
          }

          if (typeof b.obj.obj === 'string') {
            if (a instanceof Text) {
              return b.obj.obj.includes(a.obj) ? new Bool(true) : new Bool(false);
            } else {
              return b.obj.obj.includes(a.obj.obj) ? new Bool(true) : new Bool(false);
            }
          }

          return new Bool(false);
        } else {
          if (b instanceof Array_) {
            for (let itr of b.obj) {
              if (itr.text === a.text && itr.obj === a.obj) {
                return new Bool(true);
              }
            }
          } else {
            if (b instanceof Text) {
              if (a.obj.constructor === String) {
                if (b.text.includes(a.text)) {
                  return new Bool(true);
                }
              }
            } else {
              if (b instanceof NamespaceResult) {
                if (a.obj.constructor === String) {
                  if (b.rawString().includes(a.text)) {
                    return new Bool(true);
                  }
                } else {
                  if (a instanceof NamespaceResult) {
                    if (b.rawString().includes(a.rawString())) {
                      return new Bool(true);
                    }
                  }
                }
              }
            }
          }
        }

        return new Bool(false);
    }
  }

}

class TreeFlatter {
  constructor() {
    this.flattedTree = [];
  }

  run(currentElement) {
    if (currentElement instanceof Marker) {
      this.flattedTree.push(currentElement);
    }

    for (let e of currentElement.elements) {
      if (e instanceof Marker) {
        this.flattedTree.push(e);
      } else {
        this.run(e);
      }
    }

    return this.flattedTree;
  }

}

class actions {
  constructor(namespace) {
    this.namespace = null;
    this.operations = [];
    this.namespace = namespace;
  }

  make_lookup_operation(input, start, end, elements) {
    return new LookupOperation(input.substring(start + 1, end - 1));
  }

  make_function_operation(input, start, end, elements) {
    // To build the function name, we will merge the unicode_set and all the unicode_set_with_numbers
    // To build the args we will simply read the atom at index 3
    // which can be result of another operation; thus checking for exception
    // For further explanation, check ArithmeticPath.peg
    let functionName = elements[0].text + elements[1].text;

    if (elements[3] instanceof ToolException_) {
      throw elements[3];
    }

    let args = elements[3].text;
    return new FunctionOperation(functionName, args);
  }

  make_function_operation_access(input, start, end, elements) {
    // To build the function name, we will merge the unicode_set and all the unicode_set_with_numbers
    // To build the args we will simply read the atom at index 4
    // which can be result of another operation; thus checking for exception
    // For further explanation, check ArithmeticPath.peg
    let functionName = elements[1].text + elements[2].text;

    if (elements[4] instanceof ToolException_) {
      throw elements[4];
    }

    let args = elements[4].text;
    return new FunctionOperation(functionName, args);
  }

  make_attribute_operation(input, start, end, elements) {
    return new AttributeOperation(input.substring(start + 1, end));
  }

  make_attribute(input, start, end, elements) {
    return new AttributeOperation(input.substring(start, end));
  }

  static is_primitive(obj) {
    return !(obj !== undefined && obj !== null && obj.constructor !== Number && obj.constructor !== String && obj.constructor !== Boolean);
  }

  make_and_execute_namespace_operation(input, start, end, elements) {
    // Element 1 will not be null
    // Element 2 is a list of another elements (can be empty)
    // element1.(element2.element3.element4)
    // For further explanation, check ArithmeticPath.peg
    try {
      this.operations = [];
      this.operations.push(elements[1]);

      for (let nn of elements[2].elements) {
        this.operations.push(nn);
      } // Check if we have some exceptions in the operations chain - might happen if function parsing failed.


      for (let op of this.operations) {
        if (op instanceof ToolException_) {
          return op;
        }
      }

      let result = elements[1].read(this.namespace, false);

      for (let nn of elements[2].elements) {
        result = nn.read(result, false);
      }

      if (!actions.is_primitive(result.obj) && !Array.isArray(result.obj)) {
        return new NonPrimitiveNamespaceResult(result, input.substr(start, end));
      }

      return new NamespaceResult(result);
    } catch (e) {
      return new ToolException_(e);
    }
  }

  make_comp_exp_ex(input, start, end, elements) {
    // Element 2 is the actual expression
    // For further explanation, check ArithmeticPath.peg
    return elements[2];
  }

  make_comp_exp(input, start, end, elements) {
    // We can assume the following: atom ( opt_ atom )*
    // the first (which must be) will be simple atom
    // the second and so forth will always be pair <Opt, Atom>
    // Its important to remember that this execution will handle the inner brackets if exist
    // In order to handle priority (which i could not figure out if available with canopy library):
    // 1. lets make the tree flat
    // 2. handle priority ourselves - (atom opt1 atom) will be handled before (atom opt2 atom) and will return TreeNode with result
    // For further explanation, check ArithmeticPath.peg
    // handle case the size is 1
    if (elements[1].elements.length === 0) {
      return elements[0];
    }

    let flatElements = [];
    flatElements.push(elements[0]);

    for (let nn of elements[1].elements) {
      flatElements.push(nn.elements[0]);
      flatElements.push(nn.elements[1]);
    }

    while (flatElements.length > 1) {
      let shouldStop = false;

      for (let level = 0; level < allLevels.length && !shouldStop; level++) {
        for (let i = 1; i < flatElements.length; i += 2) {
          let currentOpt = flatElements[i];

          if (currentOpt.level === level) {
            let result = currentOpt.executeOperation(flatElements[i - 1], flatElements[i + 1]);
            flatElements.splice(i - 1, 3);
            flatElements.splice(i - 1, 0, result);
            shouldStop = true;
            break;
          }
        }
      }
    }

    return flatElements[0];
  }

  make_opt(input, start, end, elements) {
    return new Opt(elements[1].text);
  }

  make_apostrophe_string(input, start, end, elements) {
    return new Text(elements[2].text);
  }

  make_string(input, start, end, elements) {
    return new Text(elements[2].text);
  }

  make_list(input, start, end, elements) {
    let flatter = new TreeFlatter();
    let result = flatter.run(elements[3]);
    return new Array_(result, input.substr(start, end));
  }

  make_float(input, start, end, elements) {
    return new FloatNumber(input.substring(start, end).split(" ").join(""));
  }

  make_number(input, start, end, elements) {
    return new Number_(input.substring(start, end).split(" ").join(""));
  }

  make_char(input, start, end, elements) {
    return new Char(input.substring(start, end).split(" ").join(""));
  }

  make_bool(input, start, end, elements) {
    return new Bool(input.substring(start, end).split(" ").join(""));
  }

  make_null(input, start, end, elements) {
    return new Null();
  }

  make_undefined(input, start, end, elements) {
    return new Undefined();
  }

}

class ArithmeticPath {
  constructor(configuration) {
    this.negation = false;
    let string = null;

    if (typeof configuration === "string") {
      string = configuration;
    } else {
      string = configuration['path'];
    }

    if (string.startsWith("NOT(") && string.endsWith(")")) {
      string = string.substring("NOT(".length, string.length - 1);
      this.negation = true;
    }

    if (string === "") {
      throw new exceptions.RookInvalidArithmeticPath(string, null);
    }

    this.expression = string;
  }

  readFrom(rootNamespace) {
    let context = new actions(rootNamespace);

    try {
      let result = maps.parse(this.expression, {
        actions: context
      });
      return this.normalizeResult(result);
    } catch (e) {
      if (e instanceof ToolException_) {
        throw e.obj;
      }

      if (e instanceof _exceptions.ToolException) {
        throw e;
      }

      throw new exceptions.RookInvalidArithmeticPath(this.expression, e);
    }
  }

  writeTo(rootNamespace, value) {
    let context = new actions(rootNamespace);

    try {
      // initialize operations chain - by parsing the expression - ignore return value
      maps.parse(this.expression, {
        actions: context
      });
    } catch (e) {
      throw new exceptions.RookInvalidArithmeticPath(this.expression, e);
    } // execute the operation chain.


    let size = context.operations.length;

    if (size === 0) {
      throw new exceptions.RookInvalidArithmeticPath(this.expression, null);
    }

    let i = 0;
    let namespace = rootNamespace;

    for (; i < size - 1; i++) {
      namespace = context.operations[i].read(namespace, true);
    }

    context.operations[i].write(namespace, value);
  }

  normalizeResult(result) {
    if (result instanceof Array_) {
      let newArr = [];

      for (let el of result.obj) {
        newArr.push(el.obj);
      }

      return new _JSObjectNamespace.default(newArr);
    }

    if (result instanceof NamespaceResult) {
      return result.obj;
    }

    if (result instanceof ToolException_) {
      throw result.obj;
    }

    if (result instanceof NonPrimitiveNamespaceResult) {
      return result.obj;
    }

    let res = result.obj;

    if (typeof res === 'boolean' && this.negation) {
      res = !res;
    }

    return new _JSObjectNamespace.default(res);
  }

}

exports.default = ArithmeticPath;
//# sourceMappingURL=ArithmeticPath.js.map