"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _Namespace = _interopRequireDefault(require("./Namespace"));

var _JSObjectNamespace = _interopRequireDefault(require("./JSObjectNamespace"));

var _exceptions = require("../../exceptions");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

class JSUtilsNamespace extends _Namespace.default {
  constructor() {
    super();
  }

  callMethod(name, args) {
    switch (name) {
      case "exception":
      case "exception_string":
      case "exception_type":
        return new _JSObjectNamespace.default("Indirect exception access is not supported on Node!");

      case "module":
        try {
          return new _JSObjectNamespace.default(require(args));
        } catch (e) {
          throw new _exceptions.RookMethodFailed(name, args, e);
        }

      case "thread_id":
      case "thread_name":
      case "threads":
      case "thread_tracebacks":
        return new _JSObjectNamespace.default("Threads are not supported on Node!");

      case "env":
        return new _JSObjectNamespace.default(process.env[args]);

      default:
        super.callMethod(name, args);
    }
  }

}

exports.default = JSUtilsNamespace;
//# sourceMappingURL=JSUtilsNamespace.js.map