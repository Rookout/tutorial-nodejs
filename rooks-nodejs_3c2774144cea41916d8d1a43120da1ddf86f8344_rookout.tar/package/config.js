"use strict";

class Config {
  constructor() {
    this.loadDefaults();
  }

  loadDefaults() {
    this.LoggingConfiguration = {
      LOGGER_NAME: "rook",
      FILE_NAME: "rookout/node-rook.log",
      LOG_TO_STDERR: false,
      LOG_LEVEL: "INFO",
      PROPAGATE_LOGS: false,
      DEBUG: false
    };
    this.VersionConfiguration = {
      VERSION: "0.1.105",
      COMMIT: "3c2774144cea41916d8d1a43120da1ddf86f8344"
    };
    this.ControllerAddress = {
      HOST: "wss://control.rookout.com",
      PORT: 443
    };
    this.AgentComConfiguration = {
      BACK_OFF: 0.3,
      MAX_SLEEP: 60,
      MAX_MESSAGE_LENGTH: 100 * 1024 * 1024,
      TIMEOUT: 2,
      REQUEST_TIMEOUT_SECS: 30,
      CONNECT_TIMEOUT: 3,
      PING_TIMEOUT: 30,
      PING_INTERVAL: 10,
      RESET_BACKOFF_TIMEOUT: 3 * 60,
      MAX_QUEUED_MESSAGES: 100
    };
    this.OutputWsConfiguration = {
      BUCKET_REFRESH_RATE: 10,
      MAX_AUG_MESSAGES: 100,
      MAX_LOG_ITEMS: 200,
      MAX_STATUS_UPDATES: 200
    };
    this.InstrumentationConfig = {
      ENGINE: "auto",
      MIN_TIME_BETWEEN_HITS_MS: 100,
      MAX_AUG_TIME: 400
    };
    this.GitConfiguration = {
      GIT_COMMIT: null,
      GIT_ORIGIN: null
    };
    this.JSConfig = {
      SOURCE_MAP_SUPPORT: true
    };
  }

}

module.exports = new Config();
//# sourceMappingURL=config.js.map