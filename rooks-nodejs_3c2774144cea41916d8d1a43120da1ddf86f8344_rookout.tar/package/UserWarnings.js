"use strict"; // NOTE: There are no clean ways to implement thread local storage; so we are passing the reporter as a parameter

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

class UserWarnings {
  constructor(aug) {
    this.aug = aug;
  }

  sendWarning(error) {
    this.aug.sendWarning(error);
  }

}

exports.default = UserWarnings;
//# sourceMappingURL=UserWarnings.js.map