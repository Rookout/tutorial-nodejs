"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _InspectorObjectNamespace = _interopRequireDefault(require("./namespaces/InspectorObjectNamespace"));

var _logger = require("../logger");

var _RookError = _interopRequireDefault(require("./RookError"));

var _ContainerNamespace = _interopRequireDefault(require("./namespaces/ContainerNamespace"));

var _JSObjectNamespace = _interopRequireDefault(require("./namespaces/JSObjectNamespace"));

var _ListNamespace = _interopRequireDefault(require("./namespaces/ListNamespace"));

var _DynamicInspectorObjectNamespace = _interopRequireDefault(require("./namespaces/DynamicInspectorObjectNamespace"));

var _DictNamespace = _interopRequireDefault(require("./namespaces/DictNamespace"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const variant_pb = require('../protobuf/variant_pb');

const timestamp_pb = require('google-protobuf/google/protobuf/timestamp_pb');

// Copied from Python Google Protobuf
const INT32_MIN = -2147483648;
const INT32_MAX = 2147483647;
const INT64_MIN = -9223372036854775808;
const INT64_MAX = 9223372036854775807;

function isFloat(n) {
  try {
    // This seems to throw sometimes :(
    return n === +n && n !== (n | 0);
  } catch (e) {
    return false;
  }
}

class NamespaceSerializer {
  dumps(namespace, logErrors = true) {
    let variant = new variant_pb.Variant();
    this.dump(namespace, variant, logErrors);
    return variant;
  }

  dump(namespace, variant, logErrors = true) {
    try {
      if (namespace instanceof _ContainerNamespace.default) {
        this.dumpContainerNamespace(namespace, variant, logErrors);
      } else if (namespace instanceof _JSObjectNamespace.default) {
        this.dumpJSObjectNamespace(namespace, variant, logErrors);
      } else if (namespace instanceof _ListNamespace.default) {
        this.dumpListNamespace(namespace, variant, logErrors);
      } else if (namespace instanceof _DictNamespace.default) {
        this.dumpDictNamespace(namespace, variant, logErrors);
      } else if (namespace instanceof _InspectorObjectNamespace.default) {
        this.dumpInspectorObjectNamespace(namespace, variant, 0, namespace.dumpConfig, logErrors);
      } else if (namespace instanceof _DynamicInspectorObjectNamespace.default) {
        this.dumpDynamicInspectorObjectNamespace(variant);
      } else {
        throw new TypeError("Does not support serializing this type: " + typeof namespace);
      }
    } catch (e) {
      const message = "Failed to serialize namespace";
      this.clearVariant(variant);
      variant.setVariantType(variant_pb.Variant.Type.VARIANT_ERROR);

      if (logErrors) {
        variant.setErrorValue(new _RookError.default(e, message).dumps());

        _logger.logger.exception(message, e);
      }
    }
  }

  dumpContainerNamespace(namespace, variant, logErrors) {
    variant.setVariantType(variant_pb.Variant.Type.VARIANT_NAMESPACE);
    let result = new variant_pb.Variant.Namespace();

    for (let key of Object.keys(namespace.namespaces)) {
      let value = new variant_pb.Variant.NamedValue();
      value.setName(key);
      value.setValue(this.dumps(namespace.namespaces[key], logErrors));
      result.addAttributes(value);
    }

    variant.setNamespaceValue(result);
  }

  dumpJSObjectNamespace(namespace, variant, logErrors) {
    this.dumpJSObject(namespace.obj, variant, 0, namespace.dumpConfig, logErrors);
  }

  unsafeDumpJSObject(obj, variant, currentDepth, dumpConfig, logErrors) {
    if (currentDepth === dumpConfig.maxDepth) {
      this.dumpMaxDepth(obj, variant, currentDepth, dumpConfig);
    } else {
      this.dumpBaseObject(obj, variant, currentDepth, dumpConfig, logErrors);

      if (undefined === obj) {
        variant.setVariantType(variant_pb.Variant.Type.VARIANT_UNDEFINED);
        return;
      }

      if (null === obj) {
        variant.setVariantType(variant_pb.Variant.Type.VARIANT_NONE);
        return;
      }

      if (obj === true || obj === false) {
        variant.setVariantType(variant_pb.Variant.Type.VARIANT_INT);
        variant.setIntValue(obj ? 1 : 0);
        return;
      } // isFloat is not including int


      if (isFloat(obj) || Number.isInteger(obj)) {
        variant.setVariantType(variant_pb.Variant.Type.VARIANT_DOUBLE);
        variant.setDoubleValue(obj);
        return;
      }

      if (typeof obj === 'string' || obj instanceof String) {
        variant.setVariantType(variant_pb.Variant.Type.VARIANT_STRING);
        let string = new variant_pb.Variant.String();
        string.setOriginalSize(obj.length);

        if (obj.length > dumpConfig.maxString) {
          string.setValue(obj.substring(0, dumpConfig.maxString));
        } else {
          string.setValue(obj);
        }

        variant.setStringValue(string);
        return;
      }

      if (obj instanceof Date) {
        variant.setVariantType(variant_pb.Variant.Type.VARIANT_TIME);
        let date = new timestamp_pb.Timestamp();

        if (isNaN(obj.getTime())) {
          // date is not valid
          obj = new Date(0);
        }

        date.fromDate(obj);
        variant.setTimeValue(date);
        return;
      }

      if (Array.isArray(obj)) {
        this.dumpArray(obj, variant, currentDepth, dumpConfig, logErrors);
        return;
      }

      if (obj instanceof Error) {
        this.dumpException(obj, variant, currentDepth, dumpConfig, logErrors);
        return;
      }

      if (typeof obj === 'function') {
        variant.setVariantType(variant_pb.Variant.Type.VARIANT_CODE_OBJECT);
        let codeValue = new variant_pb.Variant.CodeObject();
        codeValue.setName(obj.name);
        variant.setCodeValue(codeValue);
        return;
      }

      this.dumpUserClass(obj, variant, currentDepth, dumpConfig, logErrors);
    }
  }

  dumpJSObject(obj, variant, currentDepth, dumpConfig, logErrors) {
    try {
      this.unsafeDumpJSObject(obj, variant, currentDepth, dumpConfig, logErrors);
    } catch (e) {
      const message = "Failed to serialize object";
      this.clearVariant(variant);
      variant.setVariantType(variant_pb.Variant.Type.VARIANT_ERROR);

      if (logErrors) {
        variant.setErrorValue(new _RookError.default(e, message).dumps());

        _logger.logger.exception(message, e);
      }
    }
  }

  dumpMaxDepth(obj, variant, currentDepth, dumpConfig) {
    variant.setVariantType(variant_pb.Variant.Type.VARIANT_MAX_DEPTH);
  }

  dumpBaseObject(obj, variant, currentDepth, dumpConfig) {
    // Try to get class name from prototype, if possible
    try {
      variant.setOriginalType(obj.__proto__.constructor.name);
    } catch (e) {
      variant.setOriginalType(typeof obj);
    }

    if (null === obj || undefined === obj) {
      return;
    } // Don't dump values of strings or arrays as they cause issues


    if (typeof obj === 'string' || obj instanceof String) {
      return;
    }

    for (let key of Object.keys(obj)) {
      // Protect against primitives pointing to themselves
      if (obj[key] === obj) {
        continue;
      } // If it's an Array, ignore it's index attributes


      if (Array.isArray(obj) && parseInt(key).toString() === key) {
        continue;
      }

      if (currentDepth + 1 < dumpConfig.maxDepth) {
        let value = new variant_pb.Variant();

        if ('get' in Object.getOwnPropertyDescriptor(obj, key)) {
          value.setVariantType(variant_pb.Variant.Type.VARIANT_DYNAMIC);
        } else {
          this.dumpJSObject(obj[key], value, currentDepth + 1, dumpConfig);
        }

        let attribute = new variant_pb.Variant.NamedValue();
        attribute.setName(key);
        attribute.setValue(value);
        variant.addAttributes(attribute);
      } else {
        variant.setMaxDepth(true);
        continue;
      }
    }

    let symbols = Object.getOwnPropertySymbols(obj);

    if (currentDepth + 1 < dumpConfig.maxDepth) {
      for (let index in symbols) {
        let symbol = symbols[index];
        let symbolName = symbol.toString();
        let value = new variant_pb.Variant();
        this.dumpJSObject(obj[symbol], value, currentDepth + 1, dumpConfig);
        let attribute = new variant_pb.Variant.NamedValue();
        attribute.setName(symbolName);
        attribute.setValue(value);
        variant.addAttributes(attribute);
      }
    } else if (symbols && symbols.length) {
      variant.setMaxDepth(true);
    }
  }

  dumpArray(obj, variant, currentDepth, dumpConfig, logErrors) {
    variant.setVariantType(variant_pb.Variant.Type.VARIANT_LIST);
    let list = new variant_pb.Variant.List();
    list.setType(_ListNamespace.default.getCommonType(list));
    list.setOriginalSize(obj.length);

    if (currentDepth < dumpConfig.maxCollectionDepth) {
      const maxItems = Math.min(obj.length, dumpConfig.maxWidth);

      for (let i = 0; i < maxItems; ++i) {
        let item = new variant_pb.Variant();
        this.dumpJSObject(obj[i], item, currentDepth + 1, dumpConfig, logErrors);
        list.addValues(item);
      }
    }

    variant.setListValue(list);
  }

  dumpException(obj, variant, currentDepth, dumpConfig, logErrors) {
    variant.setVariantType(variant_pb.Variant.Type.VARIANT_OBJECT);
    let messageValue = new variant_pb.Variant();
    this.dumpJSObject(obj.message, messageValue, currentDepth + 1, dumpConfig, logErrors);
    let messagePair = new variant_pb.Variant.NamedValue();
    messagePair.setName('message');
    messagePair.setValue(messageValue);
    variant.addAttributes(messagePair);
    let stackValue = new variant_pb.Variant();
    this.dumpJSObject(obj.stack, stackValue, currentDepth + 1, dumpConfig, logErrors);
    let stackPair = new variant_pb.Variant.NamedValue();
    stackPair.setName('stack');
    stackPair.setValue(stackValue);
    variant.addAttributes(stackPair);
  }

  dumpUserClass(obj, variant, currentDepth, dumpConfig) {
    variant.setVariantType(variant_pb.Variant.Type.VARIANT_OBJECT);
  }

  dumpListNamespace(namespace, variant, logErrors) {
    variant.setVariantType(variant_pb.Variant.Type.VARIANT_LIST);
    variant.setOriginalType(namespace.originalType);
    let listValue = new variant_pb.Variant.List();
    listValue.setType(namespace.commonType);
    listValue.setOriginalSize(namespace.originalSize);

    for (let item of namespace.list) {
      listValue.addValues(this.dumps(item, logErrors));
    }

    variant.setListValue(listValue);
  }

  dumpDictNamespace(namespace, variant, logErrors) {
    variant.setVariantType(variant_pb.Variant.Type.VARIANT_MAP);
    variant.setOriginalType(namespace.originalType);
    let dictValue = new variant_pb.Variant.Map();
    dictValue.setOriginalSize(namespace.originalSize);

    for (let key of Object.keys(namespace.dict)) {
      let pair = new variant_pb.Variant.Pair();
      pair.setFirst(this.dumps(new _JSObjectNamespace.default(key), logErrors));
      pair.setSecond(this.dumps(new _JSObjectNamespace.default(namespace.dict[key]), logErrors));
      dictValue.addPairs(pair);
    }

    variant.setMapValue(dictValue);
  }

  unsafeDumpInspectorObjectNamespace(namespace, variant, currentDepth, dumpConfig, logErrors) {
    if (currentDepth === dumpConfig.maxDepth) {
      this.dumpMaxDepth(namespace, variant, currentDepth, dumpConfig);
      return;
    }

    variant.setOriginalType(namespace.obj.className);

    if (namespace.obj.type === 'function') {
      variant.setVariantType(variant_pb.Variant.Type.VARIANT_CODE_OBJECT);
      let functionName = '';

      try {
        functionName = namespace.readAttribute('name').obj;
      } catch (e) {}

      let codeValue = new variant_pb.Variant.CodeObject();
      codeValue.setName(functionName);
      variant.setCodeValue(codeValue);
      return;
    }

    switch (namespace.obj.subtype) {
      case 'array':
        this.dumpInspectorArray(namespace, variant, currentDepth, dumpConfig);
        break;

      case 'date':
        this.dumpInspectorDate(namespace, variant, currentDepth, dumpConfig);
        break;

      default:
        variant.setVariantType(variant_pb.Variant.Type.VARIANT_OBJECT);
    }

    namespace.loadProperties();

    if (currentDepth + 1 < dumpConfig.maxDepth) {
      for (let property of namespace.properties) {
        // If it's an Array, ignore it's index attributes and the length method
        if (namespace.obj.subtype === 'array' && (parseInt(property.name).toString() === property.name || property.name === 'length')) {
          continue;
        } // We don't dump proto automatically as it leads to very large dumps


        if (property.name === '__proto__') {
          continue;
        }

        let item = new variant_pb.Variant();

        if (property.value === null || property.value === undefined) {
          if ('get' in property) {
            this.dumpDynamicInspectorObjectNamespace(item);
          } else {
            throw new RookInspectorUnknownProperty(property);
          }
        } else {
          let obj = _InspectorObjectNamespace.default.getObjectInternal(namespace.inspector, property.value);

          if (obj instanceof _InspectorObjectNamespace.default) {
            this.dumpInspectorObjectNamespace(obj, item, currentDepth + 1, dumpConfig, logErrors);
          } else {
            this.dumpJSObject(obj, item, currentDepth + 1, dumpConfig);
          }
        }

        let attribute = new variant_pb.Variant.NamedValue();
        attribute.setName(property.name);
        attribute.setValue(item);
        variant.addAttributes(attribute);
      }
    } else if (namespace.properties && namespace.properties.length) {
      variant.setMaxDepth(true);
    }
  }

  dumpDynamicInspectorObjectNamespace(variant) {
    variant.setVariantType(variant_pb.Variant.Type.VARIANT_DYNAMIC);
  }

  dumpInspectorObjectNamespace(namespace, variant, currentDepth, dumpConfig, logErrors) {
    try {
      this.unsafeDumpInspectorObjectNamespace(namespace, variant, currentDepth, dumpConfig, logErrors);
    } catch (e) {
      const message = "Failed to serialize namespace";
      variant.setVariantType(variant_pb.Variant.Type.VARIANT_ERROR);

      if (logErrors) {
        variant.setErrorValue(new _RookError.default(e, message).dumps());

        _logger.logger.exception(message, e);
      }
    }
  }

  dumpInspectorArray(namespace, variant, currentDepth, dumpConfig, logErrors) {
    variant.setVariantType(variant_pb.Variant.Type.VARIANT_LIST);
    const lengthString = namespace.obj.description.match(/\((\d+)\)/)[1];
    const length = parseInt(lengthString);
    let list = new variant_pb.Variant.List();
    list.setType(_ListNamespace.default.getCommonType(list));
    list.setOriginalSize(length);
    const maxItems = Math.min(length, dumpConfig.maxWidth);

    if (currentDepth < dumpConfig.maxCollectionDepth) {
      for (let i = 0; i < maxItems; ++i) {
        let obj = null; // Sparse arrays have missing objects as undefined

        try {
          obj = namespace.readAttribute(i.toString());
        } catch (e) {
          obj = new _JSObjectNamespace.default(undefined);
        }

        let item = new variant_pb.Variant();

        if (obj instanceof _InspectorObjectNamespace.default) {
          this.dumpInspectorObjectNamespace(obj, item, currentDepth + 1, dumpConfig, logErrors);
        } else {
          this.dumpJSObject(obj.obj, item, currentDepth + 1, dumpConfig, logErrors);
        }

        list.addValues(item);
      }
    }

    variant.setListValue(list);
  }

  dumpInspectorDate(namespace, variant, currentDepth, dumpConfig) {
    variant.setVariantType(variant_pb.Variant.Type.VARIANT_TIME);
    let date = new timestamp_pb.Timestamp();
    let timeValue = namespace.obj.description;

    if (isNaN(timeValue.getTime())) {
      // date is not valid
      timeValue = new Date(0);
    }

    date.fromDate(new Date(timeValue));
    variant.setTimeValue(date);
  }

  clearVariant(variant) {
    variant.setVariantType(undefined);
    variant.setOriginalType(undefined);
    variant.clearAttributesList();
    variant.clearIntValue();
    variant.clearLongValue();
    variant.clearDoubleValue();
    variant.clearStringValue();
    variant.clearListValue();
    variant.clearMapValue();
    variant.clearNamespaceValue();
    variant.clearErrorValue();
    variant.clearMessageValue();
    variant.clearTimeValue();
    variant.clearCodeValue();
    variant.clearLargeIntValue();
    variant.clearComplexValue();
  }

}

exports.default = NamespaceSerializer;
//# sourceMappingURL=NamespaceSerializer.js.map