"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _ArithmeticPath = _interopRequireDefault(require("../../processor/paths/ArithmeticPath"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

class Condition {
  constructor(conditionConfiguration) {
    this.path = new _ArithmeticPath.default(conditionConfiguration);
  }

  evaluate(namespace) {
    const result = this.path.readFrom(namespace);
    return result.obj === true;
  }

}

exports.default = Condition;
//# sourceMappingURL=Condition.js.map