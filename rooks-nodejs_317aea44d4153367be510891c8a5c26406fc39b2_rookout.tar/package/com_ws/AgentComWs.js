"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _ws = _interopRequireDefault(require("ws"));

var _httpsProxyAgent = _interopRequireDefault(require("https-proxy-agent"));

var _logger = require("../logger");

var information = _interopRequireWildcard(require("./information"));

var _exceptions = require("../exceptions");

var _RookError = _interopRequireDefault(require("../processor/RookError"));

function _getRequireWildcardCache() { if (typeof WeakMap !== "function") return null; var cache = new WeakMap(); _getRequireWildcardCache = function () { return cache; }; return cache; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const config = require("../config");

const messages_pb = require("../protobuf/messages_pb");

const envelope_pb = require("../protobuf/envelope_pb");

const timestamp_pb = require("google-protobuf/google/protobuf/timestamp_pb");

const any_pb = require("google-protobuf/google/protobuf/any_pb");

class MessageCallback {
  constructor(cb, persistent) {
    this.cb = cb;
    this.persistent = persistent;
  }

}

class AgentComWs {
  constructor(id, agentHost, agentPort, proxy = null, token = null, labels = null, tags = null) {
    this.id = id;
    this.host = agentHost.includes('://') ? agentHost : 'ws://' + agentHost;
    this.port = agentPort;
    this.proxy = proxy;
    this.labels = labels || {};
    this.tags = tags || [];
    this.token = token || '';
    this._lastSuccessfulConnection = 0;
    this._callbacks = {};
    this._connected = false;
    this._currentBackoff = config.AgentComConfiguration.BACK_OFF;
    this._retry = 0;
    this._stopping = false;
    this._connection = null;
    this._reconnectPromise = null;
    this._previousSendPromise = Promise.resolve();
    this._pendingMessages = [];
    this._currentlySendingMessagesUntilQueueIsEmpty = false; // Used to keep lambdas alive before we're finished.
    // Normally you would use the socket, but we might want to keep running when the socket doesn't exist
    // (e.g. after disconnection followed by a flush at the end of lambda execution)

    this._lambdaKeepAliveInterval = setInterval(() => {
      if (1) {}
    }, 60000).unref();
    this._connecting = false;
    this._lastSuccessfulPing = 0;
    this._connectionEstablishedCallbacks = []; // Used by waitForReconnect - don't use with anything else

    this._pingTimeout = null;
  }

  close() {
    this._stopping = true;

    if (this._connection) {
      this._connection.terminate();

      this._connection = null;
    }

    this._connected = false;
  }

  onConnectionEstablished(cb) {
    this._connectionEstablishedCallbacks.push(() => cb());
  }

  waitForReconnect() {
    if (this._reconnectPromise) {
      return this._reconnectPromise;
    }

    this._reconnectPromise = new Promise(resolve => {
      this.onConnectionEstablished(() => {
        this._reconnectPromise = null;
        resolve();
      });
    });
    return this._reconnectPromise;
  }

  ensureConnected(timeout = 30000) {
    let connectedPromise = Promise.resolve();

    if (this._connecting) {
      connectedPromise = this.waitForReconnect();
    } else {
      if (Date.now() - this._lastSuccessfulPing > config.AgentComConfiguration.WS_PING_TIMEOUT * 1000) {
        if (this._connection) {
          // The timeout could run after we terminate the connection, and terminate our reconnect.
          if (this._pingTimeout) {
            clearTimeout(this._pingTimeout);
            this._pingTimeout = null;
          }

          this._connection.terminate();

          this._connection = null;
        }

        connectedPromise = this.waitForReconnect();
      }
    }

    return Promise.race([connectedPromise, this.timeoutRejecter(timeout)]);
  }

  flushMessages() {
    // Returns a promise that is resolved or rejected once all messages up to this point have been
    // sent or failed to send.
    this.ensureConnected().catch(() => {});
    return new Promise(resolve => {
      let obj = {
        resolveWhenReady: resolve
      };

      this._pendingMessages.push(obj);

      this.sendQueuedMessages();
    });
  }

  sendQueuedMessages() {
    if (!this._currentlySendingMessagesUntilQueueIsEmpty && this.isConnected()) {
      this._currentlySendingMessagesUntilQueueIsEmpty = true;
      this.startSendingMessagesUntilQueueIsEmpty();
    }
  }

  startSendingMessagesUntilQueueIsEmpty() {
    // Sends all messages in queue until it's empty, if send function returns an error the function stops and pushes the message into the queue.
    let pendingMessage = this._pendingMessages.shift();

    if (pendingMessage === undefined) {
      this._currentlySendingMessagesUntilQueueIsEmpty = false;
      return;
    }

    if (pendingMessage.resolveWhenReady !== undefined) {
      pendingMessage.resolveWhenReady();
      return this.startSendingMessagesUntilQueueIsEmpty();
    }

    this.send(pendingMessage).then(() => this.startSendingMessagesUntilQueueIsEmpty()).catch(() => {
      this.addEnvelope(pendingMessage);
      this._currentlySendingMessagesUntilQueueIsEmpty = false;
    });
  }

  static getTypeName(command) {
    for (let k of Object.keys(proto.com.rookout)) {
      if (proto.com.rookout[k] === command.constructor) {
        return "com.rookout." + k;
      }
    }

    throw new _exceptions.ToolException();
  } // DON'T LOG HERE - THIS FUNCTION IS INDIRECTLY CALLED FROM WITHIN THE LOGGER
  // LOGGING HERE LEADS TO INFINITE RECURSION


  add(message) {
    let envelope = AgentComWs.wrapInEnvelope(message);
    this.addEnvelopeAndStartSending(envelope);
  } // DON'T LOG HERE - THIS FUNCTION IS INDIRECTLY CALLED FROM WITHIN THE LOGGER
  // LOGGING HERE LEADS TO INFINITE RECURSION


  addEnvelope(envelope) {
    if (this._pendingMessages.length >= config.AgentComConfiguration.MAX_QUEUED_MESSAGES) {
      return;
    }

    this._pendingMessages.push(envelope);
  } // DON'T LOG HERE - THIS FUNCTION IS INDIRECTLY CALLED FROM WITHIN THE LOGGER
  // LOGGING HERE LEADS TO INFINITE RECURSION


  addEnvelopeAndStartSending(envelope) {
    this.addEnvelope(envelope);
    this.sendQueuedMessages();
  }

  on(message_name, callback) {
    this._registerCallback(message_name, new MessageCallback(callback, true));
  }

  once(message_name, callback) {
    this._registerCallback(message_name, new MessageCallback(callback, false));
  }

  awaitMessage(message_name) {
    return new Promise(resolve => {
      this.once(message_name, resolve);
    });
  }

  _registerCallback(messageName, callback) {
    if (!this._callbacks.hasOwnProperty(messageName)) {
      this._callbacks[messageName] = [];
    }

    this._callbacks[messageName].push(callback);
  }

  timeoutRejecter(timeout) {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (!this._connection) {
          reject(new _exceptions.RookCommunicationException());
        }

        resolve();
      }, timeout).unref();
    });
  }

  isConnected() {
    return this._connected;
  }

  async _connectToAgentNoTimeout() {
    try {
      await this.startNewConnection();
      await this.registerAgent();
      const callbacks = this._connectionEstablishedCallbacks;
      this._connectionEstablishedCallbacks = [];

      for (const cb of callbacks) {
        cb();
      }

      this.sendQueuedMessages();
      return true;
    } catch (err) {
      if (err.hasOwnProperty("statusCode")) {
        if (err.statusCode === 403) {
          throw new _exceptions.RookInvalidToken(this.token);
        }

        throw new _RookError.default(err, `Got unexpected response from server with status code: ${err.statusCode}`);
      } else {
        throw err;
      }
    }
  }

  async connectToAgent(timeout) {
    let connectAndRegister = this._connectToAgentNoTimeout();

    if (!timeout) {
      return connectAndRegister;
    }

    return Promise.race([connectAndRegister, this.timeoutRejecter(timeout)]);
  }

  async registerAgent() {
    let info = await information.collect();
    info.agent_id = this.id;
    info.labels = this.labels;

    if (this.tags !== undefined) {
      info.tags = this.tags;
    }

    let m = new messages_pb.NewAgentMessage();
    m.setAgentInfo(information.pack_agent_info(info));
    let gotInitialAugsCommand = this.awaitMessage("InitialAugsCommand");
    await this.send(AgentComWs.wrapInEnvelope(m));
    this._lastSuccessfulConnection = Date.now();
    await gotInitialAugsCommand;
    this._connected = true;

    _logger.logger.info("Finished initialization");
  }

  notifyLambdaInactive() {
    this._lambdaKeepAliveInterval.unref();
  }

  notifyLambdaActive() {
    this._lambdaKeepAliveInterval.ref();
  }

  static wrapInEnvelope(message) {
    let envelope = new envelope_pb.Envelope();
    const time = new Date();
    let date = new timestamp_pb.Timestamp();
    date.fromDate(time);
    envelope.setTimestamp(date);
    let any = new any_pb.Any();
    any.pack(message.serializeBinary(), AgentComWs.getTypeName(message));
    envelope.setMsg(any);
    return envelope;
  } // DON'T LOG HERE - THIS FUNCTION IS INDIRECTLY CALLED FROM WITHIN THE LOGGER
  // LOGGING HERE LEADS TO INFINITE RECURSION


  send(message) {
    return new Promise((resolve, reject) => {
      let rookErr = null;

      if (this._connection) {
        this._connection.send(message.serializeBinary(), {
          binary: true
        }, err => {
          if (err) {
            rookErr = new _exceptions.RookSendFailedError();
          } else {
            resolve(); // send was successful
          }
        });
      } else {
        rookErr = new _exceptions.RookNotConnectedError();
      }

      if (rookErr !== null) {
        reject(rookErr);
      } else {
        resolve();
      }
    });
  }

  handleIncomingMessage(msg) {
    let envelope = envelope_pb.Envelope.deserializeBinary(msg);
    let typeName = envelope.getMsg().getTypeName();
    const partialTypeName = typeName.slice("com.rookout.".length);
    let type = proto.com.rookout[partialTypeName];
    let message = type.deserializeBinary(envelope.getMsg().getValue());
    const callbacks = this._callbacks[partialTypeName];

    if (callbacks !== undefined) {
      let remaining_callbacks = [];
      callbacks.forEach(callback => {
        try {
          callback.cb(message);
        } catch (err) {
          _logger.logger.debug(`Silenced error from callback: ${err}`);
        } finally {
          if (callback.persistent) {
            remaining_callbacks.push(callback);
          }
        }
      });
      this._callbacks[partialTypeName] = remaining_callbacks;
    }
  }

  buildProxy() {
    if (this.proxy === null) {
      return false;
    }

    _logger.logger.debug("Connecting via proxy: %s", this.proxy);

    if (this.proxy.startsWith("http")) {
      return (0, _httpsProxyAgent.default)(this.proxy);
    } else {
      return (0, _httpsProxyAgent.default)("http://" + this.proxy);
    }
  }

  startNewConnection() {
    return new Promise((resolve, reject) => {
      let proxy = this.buildProxy();

      try {
        // Initiate the connection.
        let ws = new _ws.default(`${this.host}:${this.port}/v1`, {
          headers: {
            "User-Agent": `RookoutAgent/${config.VersionConfiguration.VERSION}+${config.VersionConfiguration.COMMIT}`,
            "X-Rookout-Token": this.token
          },
          agent: proxy
        });
        this._connection = ws;
        this._connecting = true;
        this._pingTimeout = setTimeout(() => {
          _logger.logger.error("WS connect timeout, closing connection");

          try {
            if (this._connection) {
              this._connection.terminate();

              this._connection = null;
            }
          } catch (e) {}
        }, config.AgentComConfiguration.CONNECT_TIMEOUT * 1000);

        this._pingTimeout.unref(); // Send pings every WS_PING_INTERVAL.


        let pingInterval = setInterval(() => {
          ws.ping(() => {});
        }, config.AgentComConfiguration.PING_INTERVAL * 1000);
        pingInterval.unref();
        this._connection = ws;
        let gotError = false;

        let reconnect = (error, closed) => {
          if (this._stopping) {
            return;
          } // already reconnecting


          if (this._connecting) {
            return;
          }

          this._connecting = true;
          clearTimeout(this._pingTimeout);
          clearInterval(pingInterval);

          if (this._connected && Date.now() >= this._lastSuccessfulConnection + config.AgentComConfiguration.RESET_BACKOFF_TIMEOUT) {
            this._retry = 0;
            this._currentBackoff = config.AgentComConfiguration.BACK_OFF;
          }

          this._connected = false;
          this._previousSendPromise = Promise.resolve();
          this._retry += 1;
          this._currentBackoff = Math.min(this._currentBackoff * 2, config.AgentComConfiguration.MAX_SLEEP);
          let reason = "N/A";

          if (closed) {
            reason = "Connection closed";
          } else if (error) {
            reason = error;
          } // Report the error and start a timer for reconnection.


          _logger.logger.info("Connection failed; reason = %s, retry = #%d, waiting %fs", reason, this._retry, this._currentBackoff);

          setTimeout(() => this.connectToAgent().then(r => resolve(r)).catch(e => reject(e)), this._currentBackoff * 1000).unref();
        }; // Heartbeat runs on every pong, as well as once on a new connection.


        let heartbeat = () => {
          this._lastSuccessfulPing = Date.now();
          clearTimeout(this._pingTimeout);
          this._pingTimeout = setTimeout(() => {
            try {
              if (this._connection) {
                this._connection.terminate();

                this._connection = null;
              }
            } catch (e) {}
          }, config.AgentComConfiguration.PING_TIMEOUT * 1000);

          this._pingTimeout.unref();
        };

        ws.on("open", () => {
          _logger.logger.debug("Connection established");

          heartbeat();
          this._connecting = false; // The socket does not exist before this point except internally - we can't access it.
          // Upon a connection timeout (currently 2 seconds), the socket will be terminated.

          ws._socket.unref();

          resolve(ws);
        });
        ws.on("pong", () => heartbeat());
        ws.on("close", () => {
          // in the case of an error, this callback is called as well as on("error")
          if (!gotError) {
            this._connecting = false;
            reconnect(null, true);
          } // intentionally no reject here - the error is handled by reconnect

        });
        ws.on("message", msg => this.handleIncomingMessage(msg)); // Connection errors (e.g. abrupt termination)
        // Connection errors (e.g. abrupt termination)

        ws.on("error", err => {
          this._connecting = false;
          gotError = true;
          reconnect(err); // intentionally no reject here - the error is handled by reconnect
        }); // Unexpected HTTP responses

        ws.on("unexpected-response", (req, resp) => {
          reconnect(resp.statusCode);
          reject({
            statusCode: resp.statusCode
          });
        });
      } catch (err) {
        reject(err);
      }
    });
  }

}

exports.default = AgentComWs;
//# sourceMappingURL=AgentComWs.js.map