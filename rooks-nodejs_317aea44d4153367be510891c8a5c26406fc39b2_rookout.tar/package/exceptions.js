"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ToolException = ToolException;
exports.setExceptionPrototype = setExceptionPrototype;
exports.RookInvalidArithmeticPath = RookInvalidArithmeticPath;
exports.RookOperationReadOnly = RookOperationReadOnly;
exports.RookAttributeNotFound = RookAttributeNotFound;
exports.RookKeyNotFound = RookKeyNotFound;
exports.RookMethodNotFound = RookMethodNotFound;
exports.RookInvalidMethodArguments = RookInvalidMethodArguments;
exports.RookMethodFailed = RookMethodFailed;
exports.RookWriteAttributeNotSupported = RookWriteAttributeNotSupported;
exports.RookAugInvalidKey = RookAugInvalidKey;
exports.RookCommunicationException = RookCommunicationException;
exports.RookSetBreakpointFailed = RookSetBreakpointFailed;
exports.RookInspectorSetBreakpointFailed = RookInspectorSetBreakpointFailed;
exports.RookInspectorConnectFailed = RookInspectorConnectFailed;
exports.RookInspectorUnknownProperty = RookInspectorUnknownProperty;
exports.RookInspectorUnknownObject = RookInspectorUnknownObject;
exports.RookInspectorFailedToGetObject = RookInspectorFailedToGetObject;
exports.RookResolveSourceFailed = RookResolveSourceFailed;
exports.RookHashMismatchException = RookHashMismatchException;
exports.RookCrcMismatchException = RookCrcMismatchException;
exports.RookLineMoved = RookLineMoved;
exports.RookUnsupportedNodeVersion = RookUnsupportedNodeVersion;
exports.RookUnsupportedRuntime = RookUnsupportedRuntime;
exports.RookUnsupportedNotLTS = RookUnsupportedNotLTS;
exports.RookUnsupportedEngineSelection = RookUnsupportedEngineSelection;
exports.RookSourceError = RookSourceError;
exports.RookElectronInspectFlagNotSet = RookElectronInspectFlagNotSet;
exports.RookOtherDebuggerConnected = RookOtherDebuggerConnected;
exports.RookRuleRateLimited = RookRuleRateLimited;
exports.RookRuleMaxExecutionTimeReached = RookRuleMaxExecutionTimeReached;
exports.RookUnsupportedLocation = RookUnsupportedLocation;
exports.RookSourceMissing = RookSourceMissing;
exports.RookMissingToken = RookMissingToken;
exports.RookOldServers = RookOldServers;
exports.RookInvalidOptions = RookInvalidOptions;
exports.RookInvalidToken = RookInvalidToken;
exports.RookDependencyError = RookDependencyError;
exports.RookInvalidLabel = RookInvalidLabel;
exports.RookNonPrimitiveObjectType = RookNonPrimitiveObjectType;
exports.RookSendFailedError = RookSendFailedError;
exports.RookNotConnectedError = RookNotConnectedError;
exports.RookIllegalLambdaStart = RookIllegalLambdaStart;
exports.RookSourceFilePathSuggestion = RookSourceFilePathSuggestion;

var util = _interopRequireWildcard(require("util"));

function _getRequireWildcardCache() { if (typeof WeakMap !== "function") return null; var cache = new WeakMap(); _getRequireWildcardCache = function () { return cache; }; return cache; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function ToolException(message, parameters) {
  Error.call(this);
  this.message = message;
  this.parameters = parameters;
}

ToolException.prototype = Object.create(Error.prototype);
ToolException.prototype.constructor = ToolException;

ToolException.prototype.getType = function () {
  return typeof this;
};

ToolException.prototype.getMessage = function () {
  return this.message;
};

ToolException.prototype.getParameters = function () {
  return this.parameters;
};

function setExceptionPrototype(exception) {
  exception.prototype = Object.create(ToolException.prototype);
  exception.prototype.constructor = exception;
}

function RookInvalidArithmeticPath(configuration, e = null) {
  ToolException.call(this, util.format('Invalid arithmetic path configuration. configuration: %s, innerException: %s', configuration, e), {
    configuration: configuration,
    exception: e
  });
}

setExceptionPrototype(RookInvalidArithmeticPath);

function RookOperationReadOnly(operationType) {
  RookOperationReadOnly.call(this, util.format('Operation \'%s\' does not support write', operationType), {
    operation: operationType
  });
}

setExceptionPrototype(RookOperationReadOnly);

function RookAttributeNotFound(attribute) {
  ToolException.call(this, util.format('Failed to get attribute %s', attribute), {
    attribute: attribute
  });
}

setExceptionPrototype(RookAttributeNotFound);

function RookKeyNotFound(key) {
  ToolException.call(this, util.format('Failed to get key %s', key), {
    key: key
  });
}

setExceptionPrototype(RookKeyNotFound);

function RookMethodNotFound(namespaceType, method) {
  ToolException.call(this, util.format('Namespace method %s not found in namespace %s', method, namespaceType), {
    namespace: namespaceType,
    method: method
  });
}

setExceptionPrototype(RookMethodNotFound);

function RookInvalidMethodArguments(method, args) {
  ToolException.call(this, util.format('Bad method arguments: method: %s, args %s', method, args), {
    method: method,
    arguments: args
  });
}

setExceptionPrototype(RookInvalidMethodArguments);

function RookMethodFailed(method, args, e) {
  ToolException.call(this, util.format('Namespace method \'%s\' failed with args %s', method, args), {
    method: method,
    arguments: args,
    exception: e
  });
}

setExceptionPrototype(RookMethodFailed);

function RookWriteAttributeNotSupported(namespaceType, attribute) {
  ToolException.call(this, util.format('Namespace %s does not support write', namespaceType), {
    namespace: namespaceType,
    attribute: attribute
  });
}

setExceptionPrototype(RookWriteAttributeNotSupported);

function RookAugInvalidKey(keyName, configuration) {
  ToolException.call(this, util.format('Failed to get key %s from configuration %s', keyName, configuration), {
    key: keyName,
    configuration: configuration
  });
}

setExceptionPrototype(RookAugInvalidKey);

function RookCommunicationException() {
  ToolException.call(this, 'Failed to connect to the controller');
}

setExceptionPrototype(RookCommunicationException);

function RookSetBreakpointFailed() {
  ToolException.call(this, 'Failed to set breakpoint using v8 debugger');
}

setExceptionPrototype(RookSetBreakpointFailed);

function RookInspectorSetBreakpointFailed(error) {
  ToolException.call(this, 'Failed to set breakpoint using inspector debugger', {
    error: error
  });
}

setExceptionPrototype(RookInspectorSetBreakpointFailed);

function RookInspectorConnectFailed(error) {
  ToolException.call(this, 'Failed to connect to Node', {
    error: error
  });
}

setExceptionPrototype(RookInspectorConnectFailed);

function RookInspectorUnknownProperty(object) {
  ToolException.call(this, 'Failed to get property value', {
    object: object
  });
}

setExceptionPrototype(RookInspectorUnknownProperty);

function RookInspectorUnknownObject(object) {
  ToolException.call(this, 'Failed to identify object type', {
    object: object
  });
}

setExceptionPrototype(RookInspectorUnknownObject);

function RookInspectorFailedToGetObject(object) {
  ToolException.call(this, 'Failed to get object properties', {
    object: object
  });
}

setExceptionPrototype(RookInspectorFailedToGetObject);

function RookResolveSourceFailed(filename) {
  ToolException.call(this, 'Failed to resolve generated position in file', {
    filename: filename
  });
}

setExceptionPrototype(RookResolveSourceFailed);

function RookHashMismatchException(filepath, expected, calculated, gitBlobHash = null) {
  ToolException.call(this, util.format("File hashes do not match! path: %s, expected: %s, calculated: %s", filepath, expected, calculated), {
    filepath: filepath,
    expected: expected,
    calculated: calculated,
    gitBlob: gitBlobHash
  });
}

setExceptionPrototype(RookHashMismatchException);

function RookCrcMismatchException(filepath, expected, calculated, gitBlobHash = null) {
  ToolException.call(this, util.format("Line CRCs do not match! path: %s, expected: %s, calculated: %s", filepath, expected, calculated), {
    filepath: filepath,
    expected: expected,
    calculated: calculated,
    gitBlob: gitBlobHash
  });
}

setExceptionPrototype(RookCrcMismatchException);

function RookLineMoved(filepath, oldLineNo, newLineNo) {
  ToolException.call(this, util.format("Line has moved! path: %s, original line no: %s, new line no: %s", filepath, oldLineNo, newLineNo), {
    filepath: filepath,
    old_line_no: oldLineNo,
    new_line_no: newLineNo
  });
}

setExceptionPrototype(RookLineMoved);

function RookUnsupportedNodeVersion(version) {
  ToolException.call(this, util.format("Unsupported Node version %s", version), {
    version: version
  });
}

setExceptionPrototype(RookUnsupportedNodeVersion);

function RookUnsupportedRuntime() {
  ToolException.call(this, util.format("Rookout for JavaScript only supports the Node runtime!", {}));
}

setExceptionPrototype(RookUnsupportedRuntime);

function RookUnsupportedNotLTS(version) {
  ToolException.call(this, "Rookout only supports Node LTS versions", {
    version: version
  });
}

setExceptionPrototype(RookUnsupportedNotLTS);

function RookUnsupportedEngineSelection(engine) {
  ToolException.call(this, "Unsupported engine string!", {
    engine: engine
  });
}

setExceptionPrototype(RookUnsupportedEngineSelection);

function RookSourceError(filepath, error) {
  ToolException.call(this, util.format("Error occurred while reading source file: %s", filepath), {
    filepath: filepath,
    exception: error
  });
}

setExceptionPrototype(RookSourceError);

function RookElectronInspectFlagNotSet() {
  ToolException.call(this, '--inspect flag is not specified');
}

setExceptionPrototype(RookElectronInspectFlagNotSet);

function RookOtherDebuggerConnected() {
  ToolException.call(this, 'Other debugger already connected - Rookout under node.js cannot run');
}

setExceptionPrototype(RookOtherDebuggerConnected);

function RookRuleRateLimited() {
  ToolException.call(this, 'Breakpoint was rate limited. For more information: https://docs.rookout.com/docs/breakpoints-tasks.html#rate-limiting');
}

setExceptionPrototype(RookRuleRateLimited);

function RookRuleMaxExecutionTimeReached() {
  ToolException.call(this, 'Breakpoint was disabled because it has reached its maximum execution time');
}

setExceptionPrototype(RookRuleMaxExecutionTimeReached);

function RookUnsupportedLocation(locationName) {
  ToolException.call(this, util.format('Unsupported aug location was specified: %s', locationName), {
    location: locationName
  });
}

setExceptionPrototype(RookUnsupportedLocation);

function RookSourceMissing(filename) {
  ToolException.call(this, util.format('Original source not found for file: %s', filename), {
    filename: filename
  });
}

setExceptionPrototype(RookSourceMissing);

function RookMissingToken() {
  ToolException.call(this, 'No Rookout token was supplied. Make sure to pass the Rookout Token when starting the rook');
}

setExceptionPrototype(RookMissingToken);

function RookOldServers() {
  ToolException.call(this, 'Old Rookout servers are not supported in this version');
}

setExceptionPrototype(RookOldServers);

function RookInvalidOptions(description) {
  ToolException.call(this, description);
}

setExceptionPrototype(RookInvalidOptions);

function RookInvalidToken(token) {
  ToolException.call(this, util.format('The Rookout token supplied (%s...) is not valid; please check the token and try again', token.substring(0, 6)));
}

setExceptionPrototype(RookInvalidToken);

function RookDependencyError(err) {
  ToolException.call(this, err.message + ", Make sure to run 'npm install' on the same platform/architecture. " + "For more information: https://docs.rookout.com/docs/sdk-setup.html#building-1");
}

setExceptionPrototype(RookDependencyError);

function RookInvalidLabel(label) {
  ToolException.call(this, 'Invalid label: must not start with the \'$\' character', {
    label: label
  });
}

setExceptionPrototype(RookInvalidLabel);

function RookNonPrimitiveObjectType(path) {
  ToolException.call(this, util.format('Object \'%s\' must be primitive type, such as: string, int, long etc', path), {
    path: path
  });
}

setExceptionPrototype(RookNonPrimitiveObjectType);

function RookSendFailedError() {
  ToolException.call(this);
}

setExceptionPrototype(RookSendFailedError);

function RookNotConnectedError() {
  ToolException.call(this);
}

setExceptionPrototype(RookNotConnectedError);

function RookIllegalLambdaStart() {
  ToolException.call(this, 'For AWS Lambda, call rookout/lambda:wrap on your entry function');
}

setExceptionPrototype(RookIllegalLambdaStart);

function RookSourceFilePathSuggestion(wanted_path, matching_path) {
  ToolException.call(this, util.format("Rookout found alternative file path: %s", matching_path), {
    wanted_path: wanted_path,
    matching_path: matching_path
  });
}

setExceptionPrototype(RookSourceFilePathSuggestion);
//# sourceMappingURL=exceptions.js.map