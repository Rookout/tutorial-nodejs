"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.dumpConfigs = exports.default = exports.UNLIMITED_COLLECTION_WIDTH = exports.UNLIMITED_STRING = exports.TOLERANT_MAX_STRING = exports.TOLERANT_MAX_COLLECTION_DEPTH = exports.TOLERANT_MAX_WIDTH = exports.TOLERANT_MAX_DEPTH = exports.DEFAULT_MAX_STRING = exports.DEFAULT_MAX_COLLECTION_DEPTH = exports.DEFAULT_MAX_WIDTH = exports.DEFAULT_MAX_DEPTH = exports.STRICT_MAX_STRING = exports.STRICT_MAX_COLLECTION_DEPTH = exports.STRICT_MAX_WIDTH = exports.STRICT_MAX_DEPTH = void 0;

var _Namespace = _interopRequireDefault(require("./Namespace"));

var _exceptions = require("../../exceptions");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const STRICT_MAX_DEPTH = 2;
exports.STRICT_MAX_DEPTH = STRICT_MAX_DEPTH;
const STRICT_MAX_WIDTH = 5;
exports.STRICT_MAX_WIDTH = STRICT_MAX_WIDTH;
const STRICT_MAX_COLLECTION_DEPTH = 1;
exports.STRICT_MAX_COLLECTION_DEPTH = STRICT_MAX_COLLECTION_DEPTH;
const STRICT_MAX_STRING = 128;
exports.STRICT_MAX_STRING = STRICT_MAX_STRING;
const DEFAULT_MAX_DEPTH = 3;
exports.DEFAULT_MAX_DEPTH = DEFAULT_MAX_DEPTH;
const DEFAULT_MAX_WIDTH = 10;
exports.DEFAULT_MAX_WIDTH = DEFAULT_MAX_WIDTH;
const DEFAULT_MAX_COLLECTION_DEPTH = 2;
exports.DEFAULT_MAX_COLLECTION_DEPTH = DEFAULT_MAX_COLLECTION_DEPTH;
const DEFAULT_MAX_STRING = 512;
exports.DEFAULT_MAX_STRING = DEFAULT_MAX_STRING;
const TOLERANT_MAX_DEPTH = 5;
exports.TOLERANT_MAX_DEPTH = TOLERANT_MAX_DEPTH;
const TOLERANT_MAX_WIDTH = 50;
exports.TOLERANT_MAX_WIDTH = TOLERANT_MAX_WIDTH;
const TOLERANT_MAX_COLLECTION_DEPTH = 4;
exports.TOLERANT_MAX_COLLECTION_DEPTH = TOLERANT_MAX_COLLECTION_DEPTH;
const TOLERANT_MAX_STRING = 4 * 1024;
exports.TOLERANT_MAX_STRING = TOLERANT_MAX_STRING;
const UNLIMITED_STRING = 64 * 1024;
exports.UNLIMITED_STRING = UNLIMITED_STRING;
const UNLIMITED_COLLECTION_WIDTH = 100;
exports.UNLIMITED_COLLECTION_WIDTH = UNLIMITED_COLLECTION_WIDTH;

class JSObjectNamespace extends _Namespace.default {
  constructor(object, dumpConfig = null) {
    super();
    this.obj = object;

    if (dumpConfig === null) {
      this.dumpConfig = JSObjectNamespace.defaultDumpConfig();
    } else {
      this.dumpConfig = dumpConfig;
    }
  }

  callMethod(name, args) {
    switch (name) {
      case "type":
        return new JSObjectNamespace(typeof this.obj);

      case "size":
        if (this.obj instanceof Array) {
          return new JSObjectNamespace(this.obj.length);
        } else {
          return new JSObjectNamespace(Object.keys(this.obj).length);
        }

      case "depth":
        this.dumpConfig.depth = parseInt(args);

        if (isNaN(this.dumpConfig.depth)) {
          throw new _exceptions.RookInvalidMethodArguments('depth()', args);
        }

        return this;

      case "width":
        this.dumpConfig.width = parseInt(args);

        if (isNaN(this.dumpConfig.width)) {
          throw new _exceptions.RookInvalidMethodArguments('width()', args);
        }

        return this;

      case "collection_dump":
        this.dumpConfig.maxCollectionDepth = parseInt(args);

        if (isNaN(this.dumpConfig.maxCollectionDepth)) {
          throw new _exceptions.RookInvalidMethodArguments('collection_dump()', args);
        }

        return this;

      case "string":
        this.dumpConfig.maxString = parseInt(args);

        if (isNaN(this.dumpConfig.maxString)) {
          throw new _exceptions.RookInvalidMethodArguments('string()', args);
        }

        return this;

      case "limit":
        this.dumpConfig = dumpConfigs[args.toLowerCase()];

        if (this.dumpConfig === undefined) {
          throw new _exceptions.RookInvalidMethodArguments('limit()', args);
        }

        return this;

      default:
        return super.callMethod(name, args);
    }
  }

  readAttribute(name) {
    let obj = new JSObjectNamespace(this.obj[name]);
    obj.dumpConfig = this.dumpConfig;
    return obj;
  }

  readKey(key) {
    return this.readAttribute(key);
  }

  isDefaultDumpConfig() {
    return this.dumpConfig.maxDepth === DEFAULT_MAX_DEPTH && this.dumpConfig.maxWidth === DEFAULT_MAX_WIDTH && this.dumpConfig.maxCollectionDepth === DEFAULT_MAX_COLLECTION_DEPTH && this.dumpConfig.maxString === DEFAULT_MAX_STRING;
  }

  static strictDumpConfig() {
    return {
      maxDepth: STRICT_MAX_DEPTH,
      maxWidth: STRICT_MAX_WIDTH,
      maxCollectionDepth: STRICT_MAX_COLLECTION_DEPTH,
      maxString: STRICT_MAX_STRING
    };
  }

  static defaultDumpConfig() {
    return {
      maxDepth: DEFAULT_MAX_DEPTH,
      maxWidth: DEFAULT_MAX_WIDTH,
      maxCollectionDepth: DEFAULT_MAX_COLLECTION_DEPTH,
      maxString: DEFAULT_MAX_STRING
    };
  }

  static tolerantDumpConfig() {
    return {
      maxDepth: TOLERANT_MAX_DEPTH,
      maxWidth: TOLERANT_MAX_WIDTH,
      maxCollectionDepth: TOLERANT_MAX_COLLECTION_DEPTH,
      maxString: TOLERANT_MAX_STRING
    };
  }

  static tailorDumpConfig(obj) {
    if (typeof obj === 'string' || obj instanceof String) {
      return {
        maxDepth: 1,
        maxWidth: 0,
        maxCollectionDepth: 0,
        maxString: UNLIMITED_STRING
      };
    } else if (obj instanceof Array) {
      return {
        maxDepth: DEFAULT_MAX_DEPTH,
        maxWidth: UNLIMITED_COLLECTION_WIDTH,
        maxCollectionDepth: DEFAULT_MAX_COLLECTION_DEPTH,
        maxString: DEFAULT_MAX_STRING
      };
    } else {
      return JSObjectNamespace.defaultDumpConfig();
    }
  }

}

exports.default = JSObjectNamespace;
const dumpConfigs = {
  '': JSObjectNamespace.defaultDumpConfig(),
  'strict': JSObjectNamespace.strictDumpConfig(),
  'default': JSObjectNamespace.defaultDumpConfig(),
  'tolerant': JSObjectNamespace.tolerantDumpConfig()
};
exports.dumpConfigs = dumpConfigs;
//# sourceMappingURL=JSObjectNamespace.js.map