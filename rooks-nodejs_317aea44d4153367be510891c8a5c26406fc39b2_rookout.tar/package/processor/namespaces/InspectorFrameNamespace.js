"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _Namespace = _interopRequireDefault(require("./Namespace"));

var _JSObjectNamespace = _interopRequireWildcard(require("./JSObjectNamespace"));

var _exceptions = require("../../exceptions");

var _ContainerNamespace = _interopRequireDefault(require("./ContainerNamespace"));

function _getRequireWildcardCache() { if (typeof WeakMap !== "function") return null; var cache = new WeakMap(); _getRequireWildcardCache = function () { return cache; }; return cache; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const path = require("path");

const extractor = `
    function copy(index) {
      let scopes = process.__rookout_backchannel.get(index).scopes;
      scopes[scopes.length - 1].object = this;
     }
`;

class InspectorFrameNamespace extends _Namespace.default {
  constructor(inspector, frame) {
    super();
    this.inspector = inspector;
    this.frame = frame;
    this.scopes = null;
    this.this = undefined;
    this.rawPosition = null;
    this.position = null;
  }

  readAttribute(name) {
    this.populateScopes();

    if (name === 'this') {
      return new _JSObjectNamespace.default(this.this);
    }

    for (let scope of this.scopes) {
      if (Object.keys(scope.object).includes(name)) {
        return new _JSObjectNamespace.default(scope.object[name]);
      }
    }

    throw new _exceptions.RookAttributeNotFound(name);
  }

  callMethod(name, args) {
    switch (name) {
      case "filename":
      case "module":
        return this.filename();

      case "line":
        return this.line();

      case "function":
      case "method":
        return this.function();

      case "locals":
        return this.locals(args);

      case "dump":
        return this.dump(args);

      default:
        return super.callMethod(name, args);
    }
  }

  filename() {
    return new _JSObjectNamespace.default(this.getPosition().filename);
  }

  module() {
    return this.filename();
  }

  line() {
    return new _JSObjectNamespace.default(this.getPosition().line);
  }

  function() {
    return new _JSObjectNamespace.default(this.getPosition().function);
  }

  locals(args) {
    this.populateScopes();
    let result = {};
    let depth = null;
    let dumpConfig = null;

    if (null != args && '' !== args) {
      depth = parseInt(args);

      if (isNaN(depth)) {
        depth = null;
        dumpConfig = _JSObjectNamespace.dumpConfigs[args.toLowerCase()];

        if (dumpConfig === undefined) {
          throw new _exceptions.RookInvalidMethodArguments('locals()', args);
        }
      }
    }

    for (let i = this.scopes.length - 1; i >= 0; i--) {
      for (let k of Object.keys(this.scopes[i].object)) {
        result[k] = new _JSObjectNamespace.default(this.scopes[i].object[k], dumpConfig);

        if (depth !== null && dumpConfig == null) {
          result[k].dumpConfig.maxDepth = depth;
        }
      }
    }

    result.this = new _JSObjectNamespace.default(this.this);
    return new _ContainerNamespace.default(result);
  }

  dump(args) {
    return new _ContainerNamespace.default({
      locals: this.locals(args),
      module: this.module(),
      filename: this.filename(),
      line: this.line(),
      function: this.function()
    });
  }

  getPosition() {
    if (this.position !== null) {
      return this.position;
    }

    const script = this.inspector.getScript(this.frame.location.scriptId);
    let rawFilename = null;

    if (script !== null) {
      rawFilename = script.filename;
    } else {
      if (this.frame.url !== undefined) {
        rawFilename = path.basename(this.frame.url);
      }
    }

    this.rawPosition = {
      filename: rawFilename,
      line: this.frame.location.lineNumber + 1,
      column: this.frame.location.columnNumber,
      function: this.frame.functionName
    };

    if (null !== script && null !== script.mapConsumer) {
      let originalPosition = script.getOriginalPosition(this.rawPosition.line, this.rawPosition.column);

      if (null != originalPosition) {
        // In case of bad mapping we skip the resolve.
        if (originalPosition.line === null) {
          originalPosition = this.rawPosition;
        }

        this.position = {
          filename: originalPosition.source,
          line: originalPosition.line,
          column: originalPosition.column,
          function: this.rawPosition.function
        };

        if (this.position.function === '' && (typeof originalPosition.name === 'string' || originalPosition.name instanceof String)) {
          this.position.function = originalPosition.name;
        }
      }
    } // If we have been unable to get original position, just use raw position


    if (null == this.position) {
      this.position = this.rawPosition;
    }

    if (this.position.function === '') {
      this.position.function = 'anonymous';
    }

    return this.position;
  }

  populateScopes() {
    if (this.scopes !== null) {
      return this.scopes;
    }

    let scopes = [];
    let session = this.inspector;

    let index = process.__rookout_backchannel.add();

    try {
      let context = process.__rookout_backchannel.get(index);

      let scopeChain = this.frame.scopeChain;
      context.scopes = [];

      for (let scopeId = 0; scopeId < scopeChain.length; scopeId++) {
        let remoteScope = scopeChain[scopeId];
        let nextRemoteScope = scopeChain[scopeId + 1];
        let active = remoteScope.type === 'local' || remoteScope.type === 'catch' || remoteScope.type === 'block' || remoteScope.type === 'closure' && (nextRemoteScope === undefined || nextRemoteScope.type !== 'global');
        if (!active) continue;
        let scope = {};
        scope.type = remoteScope.type;
        scope.object = {};
        context.scopes.push(scope);
        let error = null;
        session.post('Runtime.callFunctionOn', {
          objectId: remoteScope.object.objectId,
          functionDeclaration: extractor,
          arguments: [{
            value: index
          }]
        }, e => {
          error = e;
        });

        if (error !== null) {
          throw error;
        }

        scopes = context.scopes;
      }

      session.post('Runtime.callFunctionOn', {
        objectId: this.frame.this.objectId,
        functionDeclaration: `
                        function copy() {
                          process.__rookout_backchannel.get(${index}).this = this;
                         }
                        `
      });

      let _this = process.__rookout_backchannel.get(index).this;

      if (_this === global) {
        _this = undefined;
      }

      this.this = _this;
    } finally {
      process.__rookout_backchannel.delete(index);

      this.scopes = scopes;
    }

    return this.scopes;
  }

}

exports.default = InspectorFrameNamespace;
//# sourceMappingURL=InspectorFrameNamespace.js.map