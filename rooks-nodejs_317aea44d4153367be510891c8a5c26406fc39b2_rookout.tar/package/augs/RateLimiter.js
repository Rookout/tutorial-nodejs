'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

class RateLimiter {
  constructor(quota, window_size) {
    this.quota = quota;
    this.window_size = window_size;
    this.windows = new Map();
  }

  calculateWindowKey(time) {
    return Math.floor(time / this.window_size) * this.window_size;
  }

  allow(now) {
    if (this.window_size === undefined) {
      return 0;
    }

    this.cleanup(now);
    let current_window_key = this.calculateWindowKey(now);
    let prev_window_key = current_window_key - this.window_size;
    let current_window_usage = this.windows.get(current_window_key);

    if (current_window_usage === undefined) {
      current_window_usage = 0;
      this.windows.set(current_window_key, current_window_usage);
    }

    let previous_window_usage = this.windows.get(prev_window_key);

    if (previous_window_usage === undefined) {
      if (current_window_usage > this.quota) {
        return null;
      }
    } else {
      let prev_weight = 1 - (now - current_window_key) / this.window_size;
      let weighted_usage = previous_window_usage * prev_weight + current_window_usage;

      if (weighted_usage > this.quota) {
        return null;
      }
    }

    return current_window_key;
  }

  record(start_time, duration) {
    if (this.window_size === undefined) {
      return;
    }

    let key = this.calculateWindowKey(start_time);
    this.windows.set(key, this.windows.get(key) + duration);
  }

  cleanup(now) {
    if (this.windows.size > 10) {
      for (let key of this.windows) {
        if (key < now - this.window_size * 5) {
          this.windows.delete(key);
        }
      }
    }
  }

}

exports.default = RateLimiter;
//# sourceMappingURL=RateLimiter.js.map