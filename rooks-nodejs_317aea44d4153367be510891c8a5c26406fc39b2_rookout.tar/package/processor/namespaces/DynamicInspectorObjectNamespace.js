"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _Namespace = _interopRequireDefault(require("./Namespace"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

class DynamicInspectorObjectNamespace extends _Namespace.default {
  constructor() {
    super();
  }

}

exports.default = DynamicInspectorObjectNamespace;
//# sourceMappingURL=DynamicInspectorObjectNamespace.js.map