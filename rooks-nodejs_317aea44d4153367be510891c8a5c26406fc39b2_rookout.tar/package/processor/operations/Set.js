"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _JSObjectNamespace = _interopRequireDefault(require("../namespaces/JSObjectNamespace"));

var _logger = require("../../logger");

var _RookError = _interopRequireDefault(require("../RookError"));

var _exceptions = require("../../exceptions");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

class Set_ {
  constructor(configuration, factory) {
    this.paths = [];
    const paths = configuration['paths'];

    if (paths === undefined) {
      throw new _exceptions.RookAugInvalidKey('paths', configuration);
    }

    for (let key of Object.keys(paths)) {
      let destPath = "";
      let srcPath = "";

      try {
        destPath = factory.getPath(key);
        srcPath = factory.getPath(paths[key]);
        this.paths.push([destPath, srcPath]);
      } catch (e) {
        // NOTE: we do not report warnings as there are no clean thread local storage implementations for Node
        _logger.logger.exception("Failed to load dest:source path pair", e);
      }
    }
  }

  execute(namespace, userWarnings) {
    for (let command of this.paths) {
      try {
        let value = command[1].readFrom(namespace);

        if (value instanceof _JSObjectNamespace.default && value.isDefaultDumpConfig()) {
          value.dumpConfig = _JSObjectNamespace.default.tailorDumpConfig(value.obj);
        }

        command[0].writeTo(namespace, value);
      } catch (e) {
        var msg = "Failed to execute dest:source path pair";

        _logger.logger.exception(msg, e);

        if (userWarnings != null) {
          userWarnings.sendWarning(new _RookError.default(e, msg));
        }
      }
    }
  }

}

exports.default = Set_;
//# sourceMappingURL=Set.js.map