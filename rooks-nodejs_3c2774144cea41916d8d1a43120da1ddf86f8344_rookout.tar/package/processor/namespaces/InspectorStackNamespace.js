"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _Namespace = _interopRequireDefault(require("./Namespace"));

var _ContainerNamespace = _interopRequireDefault(require("./ContainerNamespace"));

var _ListNamespace = _interopRequireDefault(require("./ListNamespace"));

var _InspectorFrameNamespace = _interopRequireDefault(require("./InspectorFrameNamespace"));

var _V8StackNamespace = require("./V8StackNamespace");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// Note - this is a serious duplication of the V8StackNamespace
class InspectorStackNamespace extends _Namespace.default {
  constructor(inspector, callFrames) {
    super();
    this.inspector = inspector;
    this.callFrames = callFrames;
  }

  readKey(key) {
    return new _InspectorFrameNamespace.default(this.inspector, this.callFrames[key]);
  }

  callMethod(name, args) {
    switch (name) {
      case "traceback":
        return this.traceback(args);

      case "frames":
        return this.frames(args);

      default:
        return super.callMethod(name, args);
    }
  }

  traceback(args) {
    // Decide on dump depth
    let depth = _V8StackNamespace.DEFAULT_TRACEBACK_LIMIT;

    if (null != args && '' !== args) {
      depth = parseInt(args);
    }

    if (depth > this.callFrames.length) {
      depth = this.callFrames.length;
    }

    let result = [];

    for (let i = 0; i < depth; ++i) {
      let frame = new _InspectorFrameNamespace.default(this.inspector, this.callFrames[i]);
      result.push(new _ContainerNamespace.default({
        module: frame.module(),
        filename: frame.filename(),
        line: frame.line(),
        function: frame.function()
      }));
    }

    return new _ListNamespace.default(result);
  }

  frames(args) {
    // Decide on dump depth
    let depth = _V8StackNamespace.DEFAULT_FRAMES_LIMIT;

    if (null != args && '' !== args) {
      depth = parseInt(args);
    }

    if (depth > this.callFrames.length) {
      depth = this.callFrames.length;
    }

    let result = [];

    for (let i = 0; i < depth; ++i) {
      let frame = new _InspectorFrameNamespace.default(this.inspector, this.callFrames[i]);
      result.push(frame.callMethod('dump'));
    }

    return new _ListNamespace.default(result);
  }

}

exports.default = InspectorStackNamespace;
//# sourceMappingURL=InspectorStackNamespace.js.map